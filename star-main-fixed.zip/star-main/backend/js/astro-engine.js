/**
 * 🌟 虹靈御所占星主角生成系統 - 占星計算引擎
 * 根據完整架構實現精確的角色屬性計算
 */

class AstroEngine {
    constructor() {
        this.initializeData();
    }

    initializeData() {
        // 星座基礎數據
        this.zodiacData = {
            aries: { 
                name: '牡羊座', element: '火', mode: '開創', polarity: '陽', 
                ruler: 'mars', deity: '雅典娜', traits: ['勇敢', '衝動', '領導力']
            },
            taurus: { 
                name: '金牛座', element: '土', mode: '固定', polarity: '陰', 
                ruler: 'venus', deity: '蓋亞', traits: ['穩定', '享受', '務實']
            },
            gemini: { 
                name: '雙子座', element: '風', mode: '變動', polarity: '陽', 
                ruler: 'mercury', deity: '赫米斯', traits: ['靈活', '好奇', '溝通']
            },
            cancer: { 
                name: '巨蟹座', element: '水', mode: '開創', polarity: '陰', 
                ruler: 'moon', deity: '赫拉', traits: ['敏感', '保護', '直覺']
            },
            leo: { 
                name: '獅子座', element: '火', mode: '固定', polarity: '陽', 
                ruler: 'sun', deity: '阿波羅', traits: ['自信', '慷慨', '創造力']
            },
            virgo: { 
                name: '處女座', element: '土', mode: '變動', polarity: '陰', 
                ruler: 'mercury', deity: '狄蜜特', traits: ['分析', '完美主義', '服務']
            },
            libra: { 
                name: '天秤座', element: '風', mode: '開創', polarity: '陽', 
                ruler: 'venus', deity: '忒彌斯', traits: ['和諧', '公正', '優雅']
            },
            scorpio: { 
                name: '天蠍座', element: '水', mode: '固定', polarity: '陰', 
                ruler: 'pluto', deity: '黑帝斯', traits: ['深刻', '神秘', '轉化']
            },
            sagittarius: { 
                name: '射手座', element: '火', mode: '變動', polarity: '陽', 
                ruler: 'jupiter', deity: '宙斯', traits: ['樂觀', '冒險', '哲學']
            },
            capricorn: { 
                name: '摩羯座', element: '土', mode: '開創', polarity: '陰', 
                ruler: 'saturn', deity: '克洛諾斯', traits: ['野心', '紀律', '責任']
            },
            aquarius: { 
                name: '水瓶座', element: '風', mode: '固定', polarity: '陽', 
                ruler: 'uranus', deity: '普羅米修斯', traits: ['創新', '獨立', '人道']
            },
            pisces: { 
                name: '雙魚座', element: '水', mode: '變動', polarity: '陰', 
                ruler: 'neptune', deity: '波賽頓', traits: ['同理心', '想像力', '靈性']
            }
        };

        // 行星對應技能和屬性
        this.planetSkills = {
            sun: { skill: '外顯個性', attribute: 'charisma', baseValue: 18 },
            moon: { skill: '內在情感', attribute: 'perception', baseValue: 18 },
            mercury: { skill: '溝通能力', attribute: 'intelligence', baseValue: 18 },
            venus: { skill: '技術與藝術', attribute: 'dexterity', baseValue: 18 },
            mars: { skill: '行動執行力', attribute: 'strength', baseValue: 18 },
            jupiter: { skill: '幸運潛能', attribute: 'constitution', baseValue: 18 },
            saturn: { skill: '紀律挑戰', attribute: ['strength', 'constitution'], baseValue: 18 },
            uranus: { skill: '創新突破', attribute: ['intelligence', 'perception'], baseValue: 18 },
            neptune: { skill: '靈感直覺', attribute: 'perception', baseValue: 18 },
            pluto: { skill: '深層轉化', attribute: 'strength', baseValue: 18 }
        };

        // 小行星特殊加成規則
        this.asteroidRules = {
            chiron: {
                name: '凱龍星',
                specialCases: {
                    'gemini_1': { charisma: 2, intelligence: 2 },
                    'leo_4': { charisma: 2, perception: 1 },
                    'cancer_2': { perception: 3 },
                    'scorpio_6': { strength: 2, perception: 1 },
                    'sagittarius_7': { constitution: 2, intelligence: 1 }
                },
                defaultRules: {
                    fire: { strength: 2 },
                    earth: { constitution: 2 },
                    air: { intelligence: 2 },
                    water: { perception: 2 }
                }
            },
            ceres: {
                name: '穀神星',
                specialCases: {
                    'leo_4': { charisma: 2, perception: 1 }
                },
                defaultRules: {
                    earth: { constitution: 2 },
                    water: { perception: 2 }
                }
            },
            pallas: {
                name: '智神星',
                specialCases: {
                    'cancer_2': { perception: 3 }
                },
                defaultRules: {
                    air: { intelligence: 2 },
                    water: { perception: 2 }
                }
            },
            juno: {
                name: '婚神星',
                specialCases: {
                    'scorpio_6': { strength: 2, perception: 1 }
                },
                defaultRules: {
                    water: { perception: 2 },
                    earth: { constitution: 1 }
                }
            },
            vesta: {
                name: '灶神星',
                specialCases: {
                    'sagittarius_7': { constitution: 2, intelligence: 1 }
                },
                defaultRules: {
                    fire: { strength: 1, constitution: 1 },
                    earth: { constitution: 2 }
                }
            }
        };

        // 相位規則
        this.aspectRules = {
            conjunction: { orb: 10, effect: 3, name: '合相' },
            trine: { orb: 8, effect: 2, name: '三分相' },
            sextile: { orb: 6, effect: 1, name: '六分相' },
            opposition: { orb: 10, effect: -1, perception: 2, name: '對分相' },
            square: { orb: 8, effect: -2, strength: 2, name: '刑相' },
            t_square: { orb: 8, effect: -2, intelligence: 3, name: 'T三角' },
            grand_trine: { orb: 8, effect: 3, name: '大三角' }
        };
    }

    /**
     * 計算完整的角色屬性
     */
    calculateCharacterStats(inputData) {
        // 初始化屬性
        let stats = {
            charisma: 10,
            perception: 10,
            intelligence: 10,
            dexterity: 10,
            strength: 10,
            constitution: 10
        };

        let breakdown = {
            charisma: [],
            perception: [],
            intelligence: [],
            dexterity: [],
            strength: [],
            constitution: []
        };

        // 計算主要行星屬性
        this.calculatePlanetaryStats(inputData, stats, breakdown);

        // 計算小行星加成
        this.calculateAsteroidBonuses(inputData, stats, breakdown);

        // 計算相位加成
        this.calculateAspectBonuses(inputData, stats, breakdown);

        return { stats, breakdown };
    }

    /**
     * 計算主要行星屬性
     */
    calculatePlanetaryStats(inputData, stats, breakdown) {
        const planets = ['sun', 'moon', 'mercury', 'venus', 'mars', 'jupiter', 'saturn', 'uranus', 'neptune', 'pluto'];

        planets.forEach(planet => {
            const planetSign = inputData[planet];
            const planetHouse = inputData[planet + 'House'];
            
            if (!planetSign) return;

            const planetData = this.planetSkills[planet];
            const signData = this.zodiacData[planetSign];
            
            if (!planetData || !signData) return;

            // 基礎值
            const baseValue = planetData.baseValue;
            const attributes = Array.isArray(planetData.attribute) ? planetData.attribute : [planetData.attribute];

            attributes.forEach(attr => {
                // 主神基礎值
                stats[attr] += baseValue;
                breakdown[attr].push(`${signData.deity}(${signData.name}) +${baseValue}`);

                // 模式加成
                stats[attr] += 2;
                breakdown[attr].push(`${signData.mode}模式 +2`);

                // 陰陽性加成
                if ((signData.polarity === '陽' && ['charisma', 'intelligence', 'strength'].includes(attr)) ||
                    (signData.polarity === '陰' && ['perception', 'dexterity', 'constitution'].includes(attr))) {
                    stats[attr] += 2;
                    breakdown[attr].push(`${signData.polarity}性 +2`);
                }

                // 輔助神加成（守護星所在星座）
                const rulerPlanet = signData.ruler;
                const rulerSign = inputData[rulerPlanet];
                if (rulerSign && this.zodiacData[rulerSign]) {
                    stats[attr] += 2;
                    breakdown[attr].push(`${this.zodiacData[rulerSign].deity}輔助 +2`);
                }

                // 飛入領域加成（宮位相關）
                if (planetHouse) {
                    const houseBonus = this.calculateHouseBonus(planetHouse, attr);
                    if (houseBonus > 0) {
                        stats[attr] += houseBonus;
                        breakdown[attr].push(`第${planetHouse}宮飛入 +${houseBonus}`);
                    }
                }
            });
        });
    }

    /**
     * 計算宮位加成
     */
    calculateHouseBonus(house, attribute) {
        const houseEffects = {
            1: { charisma: 3, strength: 2 },
            2: { constitution: 3, dexterity: 2 },
            3: { intelligence: 3, dexterity: 2 },
            4: { perception: 3, constitution: 2 },
            5: { charisma: 3, strength: 2 },
            6: { constitution: 3, intelligence: 2 },
            7: { charisma: 3, dexterity: 2 },
            8: { strength: 3, perception: 2 },
            9: { intelligence: 3, perception: 2 },
            10: { charisma: 3, strength: 2 },
            11: { intelligence: 3, charisma: 2 },
            12: { perception: 3, constitution: 2 }
        };

        const effects = houseEffects[parseInt(house)];
        return effects && effects[attribute] ? effects[attribute] : 0;
    }

    /**
     * 計算小行星加成
     */
    calculateAsteroidBonuses(inputData, stats, breakdown) {
        Object.keys(this.asteroidRules).forEach(asteroid => {
            const asteroidSign = inputData[asteroid + 'Sign'];
            const asteroidHouse = inputData[asteroid + 'House'];
            
            if (!asteroidSign || !asteroidHouse) return;

            const rule = this.asteroidRules[asteroid];
            const signData = this.zodiacData[asteroidSign];
            
            if (!signData) return;

            // 檢查特殊情況
            const specialKey = `${asteroidSign}_${asteroidHouse}`;
            if (rule.specialCases[specialKey]) {
                const bonuses = rule.specialCases[specialKey];
                Object.keys(bonuses).forEach(attr => {
                    stats[attr] += bonuses[attr];
                    breakdown[attr].push(`${rule.name}(${signData.name}${asteroidHouse}宮) +${bonuses[attr]}`);
                });
            } else {
                // 應用默認規則
                const elementRule = rule.defaultRules[signData.element.toLowerCase()];
                if (elementRule) {
                    Object.keys(elementRule).forEach(attr => {
                        stats[attr] += elementRule[attr];
                        breakdown[attr].push(`${rule.name}(${signData.name}) +${elementRule[attr]}`);
                    });
                }
            }
        });
    }

    /**
     * 計算相位加成
     */
    calculateAspectBonuses(inputData, stats, breakdown) {
        // 這裡需要實現相位計算邏輯
        // 由於相位計算較為複雜，這裡先實現基本框架
        
        const aspects = inputData.aspects || [];
        
        aspects.forEach(aspect => {
            const rule = this.aspectRules[aspect.type];
            if (!rule) return;

            const planet1 = aspect.planet1;
            const planet2 = aspect.planet2;
            
            // 獲取相關屬性
            const attr1 = this.planetSkills[planet1]?.attribute;
            const attr2 = this.planetSkills[planet2]?.attribute;
            
            if (attr1) {
                const attributes1 = Array.isArray(attr1) ? attr1 : [attr1];
                attributes1.forEach(attr => {
                    stats[attr] += rule.effect;
                    breakdown[attr].push(`${rule.name}(${planet1}-${planet2}) ${rule.effect > 0 ? '+' : ''}${rule.effect}`);
                    
                    // 特殊加成
                    if (rule.perception && attr === 'perception') {
                        stats.perception += rule.perception;
                        breakdown.perception.push(`${rule.name}感知加成 +${rule.perception}`);
                    }
                    if (rule.strength && attr === 'strength') {
                        stats.strength += rule.strength;
                        breakdown.strength.push(`${rule.name}力量加成 +${rule.strength}`);
                    }
                    if (rule.intelligence && attr === 'intelligence') {
                        stats.intelligence += rule.intelligence;
                        breakdown.intelligence.push(`${rule.name}智力加成 +${rule.intelligence}`);
                    }
                });
            }
        });
    }

    /**
     * 生成角色描述
     */
    generateCharacterDescription(inputData, stats) {
        const sunSign = inputData.sun;
        const moonSign = inputData.moon;
        
        if (!sunSign) return '請輸入完整的星盤資料';

        const sunData = this.zodiacData[sunSign];
        const moonData = moonSign ? this.zodiacData[moonSign] : null;

        // 找出最高屬性
        const maxStat = Object.keys(stats).reduce((a, b) => stats[a] > stats[b] ? a : b);
        const maxValue = stats[maxStat];

        const statNames = {
            charisma: '魅力',
            perception: '感知',
            intelligence: '智力',
            dexterity: '敏捷',
            strength: '力量',
            constitution: '體質'
        };

        let description = `以${sunData.name}為主導的${sunData.deity}守護者，`;
        
        if (moonData) {
            description += `內在具有${moonData.name}的${moonData.traits[0]}特質，`;
        }
        
        description += `在${statNames[maxStat]}方面表現卓越（${maxValue}點），`;
        description += `適合在需要${this.getStatDescription(maxStat)}的場合發揮所長。`;

        return description;
    }

    /**
     * 獲取屬性描述
     */
    getStatDescription(stat) {
        const descriptions = {
            charisma: '領導力和社交能力',
            perception: '直覺和洞察力',
            intelligence: '分析和學習能力',
            dexterity: '靈活性和技巧',
            strength: '行動力和意志力',
            constitution: '耐力和穩定性'
        };
        return descriptions[stat] || '綜合能力';
    }

    /**
     * 驗證輸入數據
     */
    validateInput(inputData) {
        const errors = [];
        
        // 檢查必要的行星
        const requiredPlanets = ['sun', 'moon', 'mercury', 'venus', 'mars', 'jupiter'];
        requiredPlanets.forEach(planet => {
            if (!inputData[planet]) {
                errors.push(`請選擇${this.planetSkills[planet]?.skill || planet}星座`);
            }
        });

        // 檢查星座有效性
        Object.keys(inputData).forEach(key => {
            if (key.endsWith('Sign') || ['sun', 'moon', 'mercury', 'venus', 'mars', 'jupiter', 'saturn', 'uranus', 'neptune', 'pluto'].includes(key)) {
                const value = inputData[key];
                if (value && !this.zodiacData[value]) {
                    errors.push(`無效的星座：${value}`);
                }
            }
        });

        return errors;
    }
}

// 導出模塊
if (typeof module !== 'undefined' && module.exports) {
    module.exports = AstroEngine;
} else if (typeof window !== 'undefined') {
    window.AstroEngine = AstroEngine;
}


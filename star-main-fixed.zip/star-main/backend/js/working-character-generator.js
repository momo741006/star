// 可工作的角色生成器
class WorkingCharacterGenerator {
    constructor() {
        this.signTraits = {
            aries: { strength: 8, intelligence: 6, agility: 9, wisdom: 5, charisma: 7, constitution: 8 },
            taurus: { strength: 9, intelligence: 6, agility: 4, wisdom: 8, charisma: 6, constitution: 9 },
            gemini: { strength: 5, intelligence: 9, agility: 8, wisdom: 6, charisma: 9, constitution: 5 },
            cancer: { strength: 6, intelligence: 7, agility: 5, wisdom: 9, charisma: 7, constitution: 8 },
            leo: { strength: 8, intelligence: 7, agility: 7, wisdom: 6, charisma: 9, constitution: 7 },
            virgo: { strength: 6, intelligence: 9, agility: 6, wisdom: 8, charisma: 6, constitution: 7 },
            libra: { strength: 6, intelligence: 8, agility: 7, wisdom: 7, charisma: 9, constitution: 6 },
            scorpio: { strength: 7, intelligence: 8, agility: 8, wisdom: 9, charisma: 7, constitution: 8 },
            sagittarius: { strength: 7, intelligence: 7, agility: 9, wisdom: 8, charisma: 8, constitution: 7 },
            capricorn: { strength: 8, intelligence: 8, agility: 5, wisdom: 9, charisma: 6, constitution: 9 },
            aquarius: { strength: 6, intelligence: 9, agility: 7, wisdom: 8, charisma: 8, constitution: 6 },
            pisces: { strength: 5, intelligence: 8, agility: 6, wisdom: 9, charisma: 8, constitution: 7 }
        };

        this.classes = [
            { name: '戰士', nameEn: 'Fighter', description: '勇敢的近戰專家，擅長使用各種武器和防具' },
            { name: '法師', nameEn: 'Wizard', description: '精通奧術魔法的學者，能夠操控元素力量' },
            { name: '盜賊', nameEn: 'Rogue', description: '敏捷的潛行者，擅長偷襲和解除陷阱' },
            { name: '牧師', nameEn: 'Cleric', description: '神聖的治療者，能夠使用神術和治療法術' },
            { name: '遊俠', nameEn: 'Ranger', description: '自然的守護者，精通弓箭和野外生存' },
            { name: '聖騎士', nameEn: 'Paladin', description: '正義的化身，結合戰鬥技巧和神聖力量' }
        ];

        this.grades = ['D', 'C', 'B', 'A', 'S', 'SS'];
    }

    generateCharacter(chart) {
        try {
            console.log('Working character generator: Starting generation with chart:', chart);
            
            // 計算基礎屬性
            const baseStats = this.calculateBaseStats(chart);
            console.log('Base stats calculated:', baseStats);
            
            // 選擇職業
            const characterClass = this.selectClass(baseStats);
            console.log('Class selected:', characterClass);
            
            // 計算最終屬性
            const finalStats = this.applyClassModifiers(baseStats, characterClass);
            console.log('Final stats:', finalStats);
            
            // 計算評級
            const grade = this.calculateGrade(finalStats);
            console.log('Grade calculated:', grade);
            
            // 生成技能
            const skills = this.generateSkills(chart, characterClass);
            console.log('Skills generated:', skills);
            
            const character = {
                name: chart.name || '未命名冒險者',
                class: characterClass,
                stats: finalStats,
                grade: grade,
                skills: skills,
                chart: chart,
                description: this.generateDescription(characterClass, chart),
                fantasyElements: this.generateFantasyElements(chart)
            };
            
            console.log('Character generation completed:', character);
            return character;
            
        } catch (error) {
            console.error('Working character generator error:', error);
            return this.generateFallbackCharacter(chart);
        }
    }

    calculateBaseStats(chart) {
        const stats = { strength: 5, intelligence: 5, agility: 5, wisdom: 5, charisma: 5, constitution: 5 };
        
        // 根據星座計算屬性
        if (chart.sun && this.signTraits[chart.sun.sign]) {
            const sunTraits = this.signTraits[chart.sun.sign];
            Object.keys(stats).forEach(stat => {
                stats[stat] += Math.floor(sunTraits[stat] * 0.4);
            });
        }
        
        if (chart.moon && this.signTraits[chart.moon.sign]) {
            const moonTraits = this.signTraits[chart.moon.sign];
            Object.keys(stats).forEach(stat => {
                stats[stat] += Math.floor(moonTraits[stat] * 0.3);
            });
        }
        
        if (chart.mercury && this.signTraits[chart.mercury.sign]) {
            stats.intelligence += 2;
            stats.charisma += 1;
        }
        
        if (chart.venus && this.signTraits[chart.venus.sign]) {
            stats.charisma += 2;
            stats.wisdom += 1;
        }
        
        if (chart.mars && this.signTraits[chart.mars.sign]) {
            stats.strength += 2;
            stats.agility += 1;
        }
        
        if (chart.jupiter && this.signTraits[chart.jupiter.sign]) {
            stats.wisdom += 2;
            stats.constitution += 1;
        }
        
        return stats;
    }

    selectClass(stats) {
        // 根據最高屬性選擇職業
        const maxStat = Object.keys(stats).reduce((a, b) => stats[a] > stats[b] ? a : b);
        
        switch (maxStat) {
            case 'strength':
                return this.classes[0]; // 戰士
            case 'intelligence':
                return this.classes[1]; // 法師
            case 'agility':
                return this.classes[2]; // 盜賊
            case 'wisdom':
                return this.classes[3]; // 牧師
            case 'charisma':
                return this.classes[4]; // 遊俠
            case 'constitution':
                return this.classes[5]; // 聖騎士
            default:
                return this.classes[0]; // 默認戰士
        }
    }

    applyClassModifiers(baseStats, characterClass) {
        const stats = { ...baseStats };
        
        // 根據職業調整屬性
        switch (characterClass.nameEn) {
            case 'Fighter':
                stats.strength += 3;
                stats.constitution += 2;
                break;
            case 'Wizard':
                stats.intelligence += 3;
                stats.wisdom += 2;
                break;
            case 'Rogue':
                stats.agility += 3;
                stats.charisma += 2;
                break;
            case 'Cleric':
                stats.wisdom += 3;
                stats.constitution += 2;
                break;
            case 'Ranger':
                stats.agility += 2;
                stats.wisdom += 2;
                stats.constitution += 1;
                break;
            case 'Paladin':
                stats.strength += 2;
                stats.charisma += 2;
                stats.constitution += 1;
                break;
        }
        
        return stats;
    }

    calculateGrade(stats) {
        const total = Object.values(stats).reduce((sum, val) => sum + val, 0);
        const average = total / 6;
        
        if (average >= 12) return 'SS';
        if (average >= 10) return 'S';
        if (average >= 8) return 'A';
        if (average >= 6) return 'B';
        if (average >= 4) return 'C';
        return 'D';
    }

    generateSkills(chart, characterClass) {
        const skills = [];
        
        // 根據職業添加技能
        switch (characterClass.nameEn) {
            case 'Fighter':
                skills.push('劍術精通', '盾牌防禦', '戰術指揮');
                break;
            case 'Wizard':
                skills.push('元素掌控', '奧術知識', '法術研究');
                break;
            case 'Rogue':
                skills.push('潛行術', '開鎖技巧', '致命一擊');
                break;
            case 'Cleric':
                skills.push('神聖治療', '驅邪術', '祝福儀式');
                break;
            case 'Ranger':
                skills.push('精準射擊', '野外生存', '動物溝通');
                break;
            case 'Paladin':
                skills.push('聖光術', '正義審判', '神聖守護');
                break;
        }
        
        // 根據星座添加特殊技能
        if (chart.sun) {
            switch (chart.sun.sign) {
                case 'aries':
                    skills.push('衝鋒陷陣');
                    break;
                case 'leo':
                    skills.push('領導魅力');
                    break;
                case 'scorpio':
                    skills.push('洞察人心');
                    break;
            }
        }
        
        return skills;
    }

    generateDescription(characterClass, chart) {
        const descriptions = [
            `一位${characterClass.name}，${characterClass.description}`,
            `在星辰的指引下，展現出獨特的天賦和能力。`,
            `擁有堅定的意志和不屈的精神，是冒險隊伍中不可或缺的成員。`
        ];
        
        return descriptions.join(' ');
    }

    generateFantasyElements(chart) {
        const elements = [];
        
        if (chart.sun) {
            elements.push(`太陽之力：${chart.sun.sign}座的光輝照耀著前進的道路`);
        }
        
        if (chart.moon) {
            elements.push(`月亮之影：${chart.moon.sign}座的神秘力量守護著內心`);
        }
        
        elements.push('星辰祝福：獲得來自宇宙的神秘加護');
        elements.push('命運之線：與宿命緊密相連的特殊能力');
        
        return elements;
    }

    generateFallbackCharacter(chart) {
        console.log('Generating fallback character');
        return {
            name: chart.name || '神秘冒險者',
            class: this.classes[0],
            stats: { strength: 7, intelligence: 7, agility: 7, wisdom: 7, charisma: 7, constitution: 7 },
            grade: 'B',
            skills: ['基礎戰鬥', '生存技能', '團隊合作'],
            chart: chart,
            description: '一位充滿潛力的冒險者，正在探索自己的命運之路。',
            fantasyElements: ['新手的幸運', '未知的潛能']
        };
    }
}

// 確保全局可用
window.WorkingCharacterGenerator = WorkingCharacterGenerator;
console.log('Working character generator loaded successfully');


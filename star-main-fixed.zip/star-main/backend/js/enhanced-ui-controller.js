/**
 * 🌟 虹靈御所占星主角生成系統 - 增強版UI控制器
 * 整合自動排盤、逆行計算和詳細報告功能
 */

class EnhancedUIController {
    constructor() {
        this.enhancedGenerator = new EnhancedCharacterGenerator();
        this.currentCharacter = null;
        this.currentMode = 'manual';
        
        this.initializeEventListeners();
        this.initializeStarField();
    }

    /**
     * 初始化事件監聽器
     */
    initializeEventListeners() {
        // 模式切換
        document.getElementById('manualModeBtn').addEventListener('click', () => {
            this.switchMode('manual');
        });
        
        document.getElementById('autoModeBtn').addEventListener('click', () => {
            this.switchMode('auto');
        });

        // 生成按鈕
        document.getElementById('generateBtn').addEventListener('click', () => {
            this.generateCharacterManual();
        });
        
        document.getElementById('autoGenerateBtn').addEventListener('click', () => {
            this.generateCharacterAuto();
        });

        // 結果區域按鈕
        document.getElementById('exportReportBtn').addEventListener('click', () => {
            this.exportDetailedReport();
        });
        
        document.getElementById('shareBtn').addEventListener('click', () => {
            this.shareCharacter();
        });
        
        document.getElementById('resetBtn').addEventListener('click', () => {
            this.resetForm();
        });

        // 出生地點變更時自動更新時區
        document.getElementById('birthLocation').addEventListener('change', (e) => {
            this.updateTimezone(e.target.value);
        });
    }

    /**
     * 切換輸入模式
     * @param {string} mode - 模式 ('manual' 或 'auto')
     */
    switchMode(mode) {
        this.currentMode = mode;
        
        // 更新按鈕狀態
        document.getElementById('manualModeBtn').classList.toggle('active', mode === 'manual');
        document.getElementById('autoModeBtn').classList.toggle('active', mode === 'auto');
        
        // 切換顯示區域
        document.getElementById('manualMode').style.display = mode === 'manual' ? 'block' : 'none';
        document.getElementById('autoMode').style.display = mode === 'auto' ? 'block' : 'none';
        
        // 隱藏結果區域
        document.getElementById('resultSection').style.display = 'none';
    }

    /**
     * 手動模式生成角色
     */
    async generateCharacterManual() {
        try {
            this.showLoading('正在分析星座配置...');
            
            // 收集手動輸入數據
            const inputData = this.collectManualInputData();
            
            // 驗證輸入
            if (!this.validateManualInput(inputData)) {
                this.hideLoading();
                return;
            }
            
            // 使用原有生成器生成基礎角色
            const originalGenerator = new CharacterGenerator();
            const result = originalGenerator.generateCharacter(inputData);
            
            if (!result.success) {
                throw new Error(result.errors.join(', '));
            }
            
            this.currentCharacter = result.character;
            this.displayCharacter(this.currentCharacter);
            
        } catch (error) {
            console.error('手動生成角色錯誤:', error);
            this.showError('生成角色時發生錯誤：' + error.message);
        } finally {
            this.hideLoading();
        }
    }

    /**
     * 自動模式生成角色
     */
    async generateCharacterAuto() {
        try {
            this.showLoading('正在自動排盤計算...');
            
            // 收集出生信息
            const birthData = this.collectBirthData();
            
            // 驗證出生信息
            if (!this.validateBirthData(birthData)) {
                this.hideLoading();
                return;
            }
            
            // 使用增強生成器
            const result = await this.enhancedGenerator.generateEnhancedCharacter(
                birthData, 
                birthData.characterName
            );
            
            if (!result.success) {
                throw new Error(result.error);
            }
            
            this.currentCharacter = result.character;
            this.displayEnhancedCharacter(this.currentCharacter, result.retrogradeEffects);
            
        } catch (error) {
            console.error('自動生成角色錯誤:', error);
            this.showError('自動排盤生成角色時發生錯誤：' + error.message);
        } finally {
            this.hideLoading();
        }
    }

    /**
     * 收集手動輸入數據
     * @returns {Object} 輸入數據
     */
    collectManualInputData() {
        return {
            name: document.getElementById('characterName').value || '神秘冒險者',
            sun: document.getElementById('sun').value,
            moon: document.getElementById('moon').value,
            mercury: document.getElementById('mercury').value,
            venus: document.getElementById('venus').value,
            mars: document.getElementById('mars').value,
            jupiter: document.getElementById('jupiter').value
        };
    }

    /**
     * 收集出生信息
     * @returns {Object} 出生數據
     */
    collectBirthData() {
        return {
            characterName: document.getElementById('autoCharacterName').value || '神秘冒險者',
            date: document.getElementById('birthDate').value,
            time: document.getElementById('birthTime').value,
            location: document.getElementById('birthLocation').value,
            timezone: document.getElementById('timezone').value
        };
    }

    /**
     * 驗證手動輸入
     * @param {Object} inputData - 輸入數據
     * @returns {boolean} 是否有效
     */
    validateManualInput(inputData) {
        if (!inputData.sun) {
            this.showError('請至少選擇太陽星座');
            return false;
        }
        return true;
    }

    /**
     * 驗證出生信息
     * @param {Object} birthData - 出生數據
     * @returns {boolean} 是否有效
     */
    validateBirthData(birthData) {
        if (!birthData.date) {
            this.showError('請選擇出生日期');
            return false;
        }
        if (!birthData.time) {
            this.showError('請選擇出生時間');
            return false;
        }
        if (!birthData.location) {
            this.showError('請選擇出生地點');
            return false;
        }
        return true;
    }

    /**
     * 顯示基礎角色
     * @param {Object} character - 角色數據
     */
    displayCharacter(character) {
        // 顯示結果區域
        document.getElementById('resultSection').style.display = 'block';
        
        // 基本信息
        document.getElementById('characterNameDisplay').textContent = character.name;
        document.getElementById('characterClassDisplay').textContent = character.class.primary;
        document.getElementById('characterGradeDisplay').textContent = `評級: ${character.totalScore.grade}`;
        
        // 屬性
        this.displayStats(character.stats);
        
        // 技能
        this.displaySkills(character.skills);
        
        // 描述
        this.displayDescription(character.description);
        
        // 隱藏增強功能
        document.getElementById('retrogradeEffects').style.display = 'none';
        document.getElementById('fantasyElements').style.display = 'none';
        
        // 滾動到結果
        document.getElementById('resultSection').scrollIntoView({ behavior: 'smooth' });
    }

    /**
     * 顯示增強角色
     * @param {Object} character - 角色數據
     * @param {Object} retrogradeEffects - 逆行影響
     */
    displayEnhancedCharacter(character, retrogradeEffects) {
        // 顯示結果區域
        document.getElementById('resultSection').style.display = 'block';
        
        // 基本信息
        document.getElementById('characterNameDisplay').textContent = character.name;
        document.getElementById('characterClassDisplay').textContent = 
            `${character.class.name} (${character.class.type === 'enhanced' ? '增強版' : '特殊版'})`;
        document.getElementById('characterGradeDisplay').textContent = 
            `評級: ${character.totalScore.grade} | 稀有度: ${character.totalScore.rarity}`;
        
        // 屬性
        this.displayStats(character.stats);
        
        // 技能
        this.displayEnhancedSkills(character.skills);
        
        // 逆行影響
        if (retrogradeEffects && retrogradeEffects.retrogradeCount > 0) {
            this.displayRetrogradeEffects(retrogradeEffects);
        }
        
        // 描述
        this.displayEnhancedDescription(character.description);
        
        // 奇幻元素
        if (character.fantasyElements) {
            this.displayFantasyElements(character.fantasyElements);
        }
        
        // 滾動到結果
        document.getElementById('resultSection').scrollIntoView({ behavior: 'smooth' });
    }

    /**
     * 顯示屬性
     * @param {Object} stats - 屬性數據
     */
    displayStats(stats) {
        const statsGrid = document.getElementById('statsGrid');
        statsGrid.innerHTML = '';
        
        const statNames = {
            charisma: '魅力',
            perception: '感知',
            intelligence: '智力',
            dexterity: '敏捷',
            strength: '力量',
            constitution: '體質',
            wisdom: '智慧',
            willpower: '意志力',
            intuition: '直覺'
        };
        
        for (const [key, value] of Object.entries(stats)) {
            if (statNames[key]) {
                const statItem = document.createElement('div');
                statItem.className = 'stat-item';
                statItem.innerHTML = `
                    <div class="stat-name">${statNames[key]}</div>
                    <div class="stat-value">${Math.round(value)}</div>
                `;
                statsGrid.appendChild(statItem);
            }
        }
    }

    /**
     * 顯示技能
     * @param {Array} skills - 技能數據
     */
    displaySkills(skills) {
        const skillsList = document.getElementById('skillsList');
        skillsList.innerHTML = '';
        
        skills.forEach(skill => {
            const skillItem = document.createElement('div');
            skillItem.className = 'skill-item';
            skillItem.innerHTML = `
                <div class="skill-header">
                    <span class="skill-name">${skill.name}</span>
                    <span class="skill-type">${skill.type}</span>
                </div>
                <div class="skill-description">${skill.description}</div>
            `;
            skillsList.appendChild(skillItem);
        });
    }

    /**
     * 顯示增強技能
     * @param {Array} skills - 技能數據
     */
    displayEnhancedSkills(skills) {
        const skillsList = document.getElementById('skillsList');
        skillsList.innerHTML = '';
        
        skills.forEach(skill => {
            const skillItem = document.createElement('div');
            skillItem.className = 'skill-item';
            
            let rarityClass = '';
            if (skill.rarity === 'legendary') rarityClass = 'legendary';
            else if (skill.rarity === 'epic') rarityClass = 'epic';
            
            skillItem.innerHTML = `
                <div class="skill-header">
                    <span class="skill-name ${rarityClass}">
                        ${skill.icon || ''} ${skill.name}
                    </span>
                    <span class="skill-type">${skill.type}</span>
                </div>
                <div class="skill-description">${skill.description}</div>
            `;
            skillsList.appendChild(skillItem);
        });
    }

    /**
     * 顯示逆行影響
     * @param {Object} retrogradeEffects - 逆行影響數據
     */
    displayRetrogradeEffects(retrogradeEffects) {
        const retrogradeSection = document.getElementById('retrogradeEffects');
        const retrogradeContent = document.getElementById('retrogradeContent');
        
        retrogradeSection.style.display = 'block';
        
        let content = `<p><strong>逆行行星數量：</strong>${retrogradeEffects.retrogradeCount}</p>`;
        content += `<p>${retrogradeEffects.retrogradeDescription}</p>`;
        
        if (retrogradeEffects.bonusSkills.length > 0) {
            content += '<h5>🌟 逆行特殊技能：</h5><ul>';
            retrogradeEffects.bonusSkills.forEach(skill => {
                content += `<li><strong>${skill.name}：</strong>${skill.description}</li>`;
            });
            content += '</ul>';
        }
        
        retrogradeContent.innerHTML = content;
    }

    /**
     * 顯示描述
     * @param {Object} description - 描述數據
     */
    displayDescription(description) {
        const descriptionContent = document.getElementById('descriptionContent');
        
        if (typeof description === 'string') {
            descriptionContent.innerHTML = `<p>${description}</p>`;
        } else {
            let content = `<p><strong>總結：</strong>${description.summary}</p>`;
            content += `<p><strong>性格：</strong>${description.personality}</p>`;
            
            if (description.strengths && description.strengths.length > 0) {
                content += '<h5>💪 優勢：</h5><ul>';
                description.strengths.forEach(strength => {
                    content += `<li>${strength}</li>`;
                });
                content += '</ul>';
            }
            
            descriptionContent.innerHTML = content;
        }
    }

    /**
     * 顯示增強描述
     * @param {Object} description - 描述數據
     */
    displayEnhancedDescription(description) {
        const descriptionContent = document.getElementById('descriptionContent');
        
        let content = '';
        
        if (description.summary) {
            content += `<p><strong>角色總結：</strong>${description.summary}</p>`;
        }
        
        if (description.personality) {
            content += `<p><strong>性格特質：</strong>${description.personality}</p>`;
        }
        
        if (description.classEvolution) {
            content += `<p><strong>職業進化：</strong>${description.classEvolution}</p>`;
        }
        
        if (description.cosmicSignature) {
            content += `<p><strong>宇宙印記：</strong>${description.cosmicSignature}</p>`;
        }
        
        if (description.destinyPath) {
            content += `<p><strong>命運之路：</strong>${description.destinyPath}</p>`;
        }
        
        descriptionContent.innerHTML = content;
    }

    /**
     * 顯示奇幻元素
     * @param {Object} fantasyElements - 奇幻元素數據
     */
    displayFantasyElements(fantasyElements) {
        const fantasySection = document.getElementById('fantasyElements');
        const fantasyContent = document.getElementById('fantasyContent');
        
        fantasySection.style.display = 'block';
        
        let content = '';
        
        if (fantasyElements.aura) {
            content += `<p><strong>🌟 光環：</strong>${fantasyElements.aura.color}光環，${fantasyElements.aura.effect}效果</p>`;
        }
        
        if (fantasyElements.constellation) {
            content += `<p><strong>⭐ 守護星座：</strong>${fantasyElements.constellation}</p>`;
        }
        
        if (fantasyElements.companionSpirit) {
            const spirit = fantasyElements.companionSpirit;
            content += `<p><strong>🐾 守護靈：</strong>${spirit.name}（${spirit.type}），特殊能力：${spirit.ability}</p>`;
        }
        
        if (fantasyElements.magicalItems && fantasyElements.magicalItems.length > 0) {
            content += '<h5>🔮 魔法物品：</h5><ul>';
            fantasyElements.magicalItems.forEach(item => {
                content += `<li><strong>${item.name}（${item.type}）：</strong>${item.effect}</li>`;
            });
            content += '</ul>';
        }
        
        fantasyContent.innerHTML = content;
    }

    /**
     * 導出詳細報告
     */
    async exportDetailedReport() {
        if (!this.currentCharacter) {
            this.showError('沒有角色數據可以導出');
            return;
        }
        
        try {
            this.showLoading('正在生成詳細報告...');
            
            const reportGenerator = new DetailedReportGenerator();
            const reportContent = reportGenerator.generateReport(this.currentCharacter);
            
            // 創建並下載文件
            const blob = new Blob([reportContent], { type: 'text/html;charset=utf-8' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `${this.currentCharacter.name}_角色報告.html`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            
            this.showSuccess('報告已成功導出！');
            
        } catch (error) {
            console.error('導出報告錯誤:', error);
            this.showError('導出報告時發生錯誤：' + error.message);
        } finally {
            this.hideLoading();
        }
    }

    /**
     * 分享角色
     */
    shareCharacter() {
        if (!this.currentCharacter) {
            this.showError('沒有角色數據可以分享');
            return;
        }
        
        const shareText = `我在虹靈御所占星系統中生成了一個${this.currentCharacter.class.name || this.currentCharacter.class.primary}角色：${this.currentCharacter.name}！快來試試看吧！`;
        
        if (navigator.share) {
            navigator.share({
                title: '虹靈御所占星角色',
                text: shareText,
                url: window.location.href
            });
        } else {
            // 複製到剪貼板
            navigator.clipboard.writeText(shareText).then(() => {
                this.showSuccess('角色信息已複製到剪貼板！');
            }).catch(() => {
                this.showError('無法複製到剪貼板');
            });
        }
    }

    /**
     * 重置表單
     */
    resetForm() {
        // 清空所有輸入
        document.getElementById('characterName').value = '';
        document.getElementById('autoCharacterName').value = '';
        document.getElementById('birthDate').value = '';
        document.getElementById('birthTime').value = '';
        document.getElementById('birthLocation').value = '';
        
        // 重置所有選擇框
        const selects = document.querySelectorAll('select');
        selects.forEach(select => select.value = '');
        
        // 隱藏結果區域
        document.getElementById('resultSection').style.display = 'none';
        
        // 重置當前角色
        this.currentCharacter = null;
        
        // 滾動到頂部
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    /**
     * 根據地點更新時區
     * @param {string} location - 地點
     */
    updateTimezone(location) {
        const timezoneMap = {
            '台北': 'Asia/Taipei',
            '台中': 'Asia/Taipei',
            '高雄': 'Asia/Taipei',
            '香港': 'Asia/Hong_Kong',
            '澳門': 'Asia/Hong_Kong',
            '北京': 'Asia/Shanghai',
            '上海': 'Asia/Shanghai',
            '廣州': 'Asia/Shanghai',
            '深圳': 'Asia/Shanghai',
            '東京': 'Asia/Tokyo',
            '大阪': 'Asia/Tokyo',
            '首爾': 'Asia/Seoul',
            '釜山': 'Asia/Seoul',
            '新加坡': 'Asia/Singapore',
            '曼谷': 'Asia/Bangkok',
            '紐約': 'America/New_York',
            '洛杉磯': 'America/Los_Angeles',
            '倫敦': 'Europe/London',
            '巴黎': 'Europe/Paris',
            '雪梨': 'Australia/Sydney'
        };
        
        const timezone = timezoneMap[location];
        if (timezone) {
            document.getElementById('timezone').value = timezone;
        }
    }

    /**
     * 初始化星空效果
     */
    initializeStarField() {
        const starsContainer = document.getElementById('stars');
        const particlesContainer = document.getElementById('cosmicParticles');
        
        // 添加隨機星星
        for (let i = 0; i < 100; i++) {
            const star = document.createElement('div');
            star.style.position = 'absolute';
            star.style.width = Math.random() * 3 + 'px';
            star.style.height = star.style.width;
            star.style.background = '#fff';
            star.style.borderRadius = '50%';
            star.style.left = Math.random() * 100 + '%';
            star.style.top = Math.random() * 100 + '%';
            star.style.opacity = Math.random();
            star.style.animation = `sparkle ${Math.random() * 3 + 2}s linear infinite`;
            starsContainer.appendChild(star);
        }
    }

    /**
     * 顯示載入動畫
     * @param {string} message - 載入訊息
     */
    showLoading(message = '載入中...') {
        const overlay = document.getElementById('loadingOverlay');
        const text = overlay.querySelector('.loading-text');
        text.textContent = message;
        overlay.style.display = 'flex';
    }

    /**
     * 隱藏載入動畫
     */
    hideLoading() {
        document.getElementById('loadingOverlay').style.display = 'none';
    }

    /**
     * 顯示錯誤訊息
     * @param {string} message - 錯誤訊息
     */
    showError(message) {
        alert('❌ ' + message);
    }

    /**
     * 顯示成功訊息
     * @param {string} message - 成功訊息
     */
    showSuccess(message) {
        alert('✅ ' + message);
    }
}

/**
 * 詳細報告生成器
 */
class DetailedReportGenerator {
    generateReport(character) {
        return `
<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${character.name} - 角色詳細報告</title>
    <style>
        body {
            font-family: 'Microsoft JhengHei', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: #333;
            margin: 0;
            padding: 20px;
        }
        .report-container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
        }
        .header {
            text-align: center;
            margin-bottom: 40px;
            border-bottom: 3px solid #667eea;
            padding-bottom: 20px;
        }
        .character-name {
            font-size: 2.5rem;
            color: #667eea;
            margin-bottom: 10px;
        }
        .character-class {
            font-size: 1.5rem;
            color: #764ba2;
            margin-bottom: 10px;
        }
        .section {
            margin-bottom: 30px;
        }
        .section-title {
            font-size: 1.5rem;
            color: #667eea;
            border-left: 4px solid #667eea;
            padding-left: 15px;
            margin-bottom: 15px;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }
        .stat-item {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 10px;
            text-align: center;
            border: 2px solid #e9ecef;
        }
        .stat-name {
            font-weight: bold;
            color: #667eea;
            margin-bottom: 5px;
        }
        .stat-value {
            font-size: 1.5rem;
            color: #764ba2;
            font-weight: bold;
        }
        .skill-item {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 15px;
            border-left: 4px solid #667eea;
        }
        .skill-name {
            font-weight: bold;
            color: #667eea;
            margin-bottom: 5px;
        }
        .description {
            line-height: 1.6;
            color: #555;
        }
        .footer {
            text-align: center;
            margin-top: 40px;
            padding-top: 20px;
            border-top: 2px solid #e9ecef;
            color: #888;
        }
    </style>
</head>
<body>
    <div class="report-container">
        <div class="header">
            <h1 class="character-name">${character.name}</h1>
            <div class="character-class">${character.class.name || character.class.primary}</div>
            <div>評級: ${character.totalScore.grade}</div>
            ${character.totalScore.rarity ? `<div>稀有度: ${character.totalScore.rarity}</div>` : ''}
        </div>

        <div class="section">
            <h2 class="section-title">屬性數值</h2>
            <div class="stats-grid">
                ${this.generateStatsHTML(character.stats)}
            </div>
        </div>

        <div class="section">
            <h2 class="section-title">技能能力</h2>
            ${this.generateSkillsHTML(character.skills)}
        </div>

        ${character.retrogradeEffects ? this.generateRetrogradeHTML(character.retrogradeEffects) : ''}

        <div class="section">
            <h2 class="section-title">角色描述</h2>
            <div class="description">
                ${this.generateDescriptionHTML(character.description)}
            </div>
        </div>

        ${character.fantasyElements ? this.generateFantasyHTML(character.fantasyElements) : ''}

        <div class="footer">
            <p>由虹靈御所占星主角生成系統生成</p>
            <p>生成時間: ${new Date().toLocaleString('zh-TW')}</p>
        </div>
    </div>
</body>
</html>`;
    }

    generateStatsHTML(stats) {
        const statNames = {
            charisma: '魅力',
            perception: '感知',
            intelligence: '智力',
            dexterity: '敏捷',
            strength: '力量',
            constitution: '體質',
            wisdom: '智慧',
            willpower: '意志力',
            intuition: '直覺'
        };

        return Object.entries(stats)
            .filter(([key]) => statNames[key])
            .map(([key, value]) => `
                <div class="stat-item">
                    <div class="stat-name">${statNames[key]}</div>
                    <div class="stat-value">${Math.round(value)}</div>
                </div>
            `).join('');
    }

    generateSkillsHTML(skills) {
        return skills.map(skill => `
            <div class="skill-item">
                <div class="skill-name">${skill.icon || ''} ${skill.name}</div>
                <div>${skill.description}</div>
            </div>
        `).join('');
    }

    generateRetrogradeHTML(retrogradeEffects) {
        if (!retrogradeEffects || retrogradeEffects.retrogradeCount === 0) return '';
        
        return `
            <div class="section">
                <h2 class="section-title">⚡ 逆行影響</h2>
                <div class="description">
                    <p><strong>逆行行星數量：</strong>${retrogradeEffects.retrogradeCount}</p>
                    <p>${retrogradeEffects.retrogradeDescription}</p>
                    ${retrogradeEffects.bonusSkills.length > 0 ? `
                        <h4>特殊技能：</h4>
                        ${retrogradeEffects.bonusSkills.map(skill => `
                            <div class="skill-item">
                                <div class="skill-name">${skill.name}</div>
                                <div>${skill.description}</div>
                            </div>
                        `).join('')}
                    ` : ''}
                </div>
            </div>
        `;
    }

    generateDescriptionHTML(description) {
        if (typeof description === 'string') {
            return `<p>${description}</p>`;
        }

        let html = '';
        if (description.summary) html += `<p><strong>總結：</strong>${description.summary}</p>`;
        if (description.personality) html += `<p><strong>性格：</strong>${description.personality}</p>`;
        if (description.classEvolution) html += `<p><strong>職業進化：</strong>${description.classEvolution}</p>`;
        if (description.cosmicSignature) html += `<p><strong>宇宙印記：</strong>${description.cosmicSignature}</p>`;
        if (description.destinyPath) html += `<p><strong>命運之路：</strong>${description.destinyPath}</p>`;
        
        return html;
    }

    generateFantasyHTML(fantasyElements) {
        return `
            <div class="section">
                <h2 class="section-title">✨ 奇幻元素</h2>
                <div class="description">
                    ${fantasyElements.aura ? `<p><strong>光環：</strong>${fantasyElements.aura.color}光環，${fantasyElements.aura.effect}效果</p>` : ''}
                    ${fantasyElements.constellation ? `<p><strong>守護星座：</strong>${fantasyElements.constellation}</p>` : ''}
                    ${fantasyElements.companionSpirit ? `<p><strong>守護靈：</strong>${fantasyElements.companionSpirit.name}（${fantasyElements.companionSpirit.type}），特殊能力：${fantasyElements.companionSpirit.ability}</p>` : ''}
                    ${fantasyElements.magicalItems && fantasyElements.magicalItems.length > 0 ? `
                        <h4>魔法物品：</h4>
                        ${fantasyElements.magicalItems.map(item => `<p><strong>${item.name}：</strong>${item.effect}</p>`).join('')}
                    ` : ''}
                </div>
            </div>
        `;
    }
}

// 初始化應用
document.addEventListener('DOMContentLoaded', () => {
    new EnhancedUIController();
});


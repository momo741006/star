// 完整角色生成器 - 支持10大行星和12宮位
class CompleteCharacterGenerator {
    constructor() {
        this.professions = [
            {
                name: '星辰戰士',
                requirements: { strength: 14, constitution: 12 },
                description: '以星辰之力戰鬥的勇士，擁有強大的物理戰鬥能力和不屈的意志',
                skills: ['星辰劍術', '護盾防禦', '戰鬥直覺', '領導統御', '勇氣激發'],
                element: 'fire',
                rarity: 'rare'
            },
            {
                name: '宇宙法師',
                requirements: { intelligence: 14, wisdom: 12 },
                description: '操控宇宙能量的魔法師，精通各種神秘法術和星象魔法',
                skills: ['星象魔法', '元素操控', '預言術', '魔法研究', '能量護盾'],
                element: 'air',
                rarity: 'rare'
            },
            {
                name: '星影遊俠',
                requirements: { agility: 14, wisdom: 12 },
                description: '穿梭於星影之間的敏捷戰士，擅長遠程攻擊和野外生存',
                skills: ['精準射擊', '隱身術', '野外生存', '追蹤技巧', '動物溝通'],
                element: 'earth',
                rarity: 'rare'
            },
            {
                name: '聖光牧師',
                requirements: { wisdom: 14, charisma: 12 },
                description: '傳播聖光的神職人員，擁有治療和祝福的神聖能力',
                skills: ['神聖治療', '祝福術', '驅邪', '靈性指導', '群體治療'],
                element: 'water',
                rarity: 'rare'
            },
            {
                name: '星空吟遊詩人',
                requirements: { charisma: 14, intelligence: 12 },
                description: '用音樂和故事傳播星空智慧的藝術家，能激勵盟友並迷惑敵人',
                skills: ['魅惑歌聲', '激勵盟友', '古老傳說', '社交魅力', '心靈安撫'],
                element: 'air',
                rarity: 'uncommon'
            },
            {
                name: '暗影刺客',
                requirements: { agility: 14, intelligence: 12 },
                description: '隱藏在暗影中的致命殺手，擅長暗殺和潛行作戰',
                skills: ['暗殺技巧', '毒藥製作', '鎖定技術', '隱匿行動', '致命一擊'],
                element: 'water',
                rarity: 'uncommon'
            },
            {
                name: '時空守護者',
                requirements: { wisdom: 16, intelligence: 14 },
                description: '掌控時空力量的神秘守護者，能操縱時間和空間的流動',
                skills: ['時間操控', '空間傳送', '預知未來', '時空護盾', '維度行走'],
                element: 'air',
                rarity: 'legendary'
            },
            {
                name: '元素領主',
                requirements: { intelligence: 16, charisma: 14 },
                description: '統御四大元素的強大存在，能召喚和控制自然的原始力量',
                skills: ['元素召喚', '自然操控', '元素融合', '災難召喚', '生命賦予'],
                element: 'earth',
                rarity: 'legendary'
            },
            {
                name: '星界行者',
                requirements: { agility: 16, wisdom: 14 },
                description: '能在不同星界間自由穿行的神秘旅者，掌握跨維度的秘密',
                skills: ['星界穿越', '靈魂視覺', '維度感知', '星界戰鬥', '能量吸收'],
                element: 'water',
                rarity: 'legendary'
            },
            {
                name: '混沌之子',
                requirements: { strength: 16, constitution: 16 },
                description: '擁抱混沌力量的強大戰士，能將破壞轉化為創造的力量',
                skills: ['混沌爆發', '破壞重生', '狂暴模式', '混沌護甲', '毀滅新生'],
                element: 'fire',
                rarity: 'legendary'
            }
        ];

        this.houseThemes = {
            1: { theme: '自我認知', bonus: { charisma: 2, strength: 1 } },
            2: { theme: '物質掌控', bonus: { constitution: 2, wisdom: 1 } },
            3: { theme: '溝通學習', bonus: { intelligence: 2, agility: 1 } },
            4: { theme: '情感根基', bonus: { wisdom: 2, constitution: 1 } },
            5: { theme: '創造表達', bonus: { charisma: 3, strength: 1 } },
            6: { theme: '服務完善', bonus: { constitution: 3, agility: 1 } },
            7: { theme: '關係合作', bonus: { charisma: 2, wisdom: 1 } },
            8: { theme: '轉化重生', bonus: { strength: 2, wisdom: 2 } },
            9: { theme: '智慧探索', bonus: { wisdom: 3, intelligence: 1 } },
            10: { theme: '成就聲望', bonus: { charisma: 2, strength: 2 } },
            11: { theme: '友誼理想', bonus: { charisma: 2, agility: 1 } },
            12: { theme: '靈性犧牲', bonus: { wisdom: 2, intelligence: 1 } }
        };
    }

    // 生成完整角色
    generateCharacter(chartData, characterName) {
        console.log('[CompleteCharacterGenerator] 開始生成角色：', characterName);
        console.log('[CompleteCharacterGenerator] 星盤數據：', chartData);

        try {
            // 使用增強占星系統計算基礎屬性
            const astroResult = window.enhancedAstroSystem.generateCharacterFromChart(chartData);
            
            // 計算宮位加成
            const houseBonus = this.calculateHouseBonus(chartData);
            
            // 應用宮位加成
            const finalAttributes = this.applyHouseBonus(astroResult.attributes, houseBonus);
            
            // 重新計算職業（基於最終屬性）
            const profession = this.determineProfession(finalAttributes);
            
            // 計算最終評級
            const grade = this.calculateGrade(finalAttributes, profession);
            
            // 生成特殊能力
            const specialAbilities = this.generateSpecialAbilities(chartData, profession);
            
            // 生成詳細描述
            const description = this.generateDescription(profession, finalAttributes, astroResult.planetaryPowers);

            const result = {
                name: characterName,
                attributes: finalAttributes,
                profession: profession,
                grade: grade,
                planetaryPowers: astroResult.planetaryPowers,
                specialAbilities: specialAbilities,
                description: description,
                houseInfluences: houseBonus,
                totalScore: Object.values(finalAttributes).reduce((sum, val) => sum + val, 0)
            };

            console.log('[CompleteCharacterGenerator] 角色生成完成：', result);
            return result;

        } catch (error) {
            console.error('[CompleteCharacterGenerator] 角色生成失敗：', error);
            throw new Error('角色生成失敗：' + error.message);
        }
    }

    // 計算宮位加成
    calculateHouseBonus(chartData) {
        const houseBonus = {
            strength: 0, intelligence: 0, agility: 0,
            wisdom: 0, charisma: 0, constitution: 0
        };

        // 根據太陽星座確定主要宮位
        if (chartData.planets.sun) {
            const sunHouse = this.getSunHouse(chartData.planets.sun);
            const houseTheme = this.houseThemes[sunHouse];
            
            if (houseTheme) {
                for (let attr in houseTheme.bonus) {
                    houseBonus[attr] += houseTheme.bonus[attr];
                }
            }
        }

        // 根據其他重要行星添加額外宮位影響
        const importantPlanets = ['moon', 'mercury', 'venus', 'mars'];
        importantPlanets.forEach((planet, index) => {
            if (chartData.planets[planet]) {
                const house = ((this.getSunHouse(chartData.planets[planet]) + index) % 12) + 1;
                const houseTheme = this.houseThemes[house];
                
                if (houseTheme) {
                    for (let attr in houseTheme.bonus) {
                        houseBonus[attr] += Math.floor(houseTheme.bonus[attr] * 0.5);
                    }
                }
            }
        });

        return houseBonus;
    }

    // 應用宮位加成
    applyHouseBonus(baseAttributes, houseBonus) {
        const finalAttributes = { ...baseAttributes };
        
        for (let attr in houseBonus) {
            finalAttributes[attr] += houseBonus[attr];
            // 確保屬性在合理範圍內
            finalAttributes[attr] = Math.max(8, Math.min(20, finalAttributes[attr]));
        }

        return finalAttributes;
    }

    // 根據太陽星座確定主要宮位
    getSunHouse(sunSign) {
        const houseMapping = {
            aries: 1, taurus: 2, gemini: 3, cancer: 4,
            leo: 5, virgo: 6, libra: 7, scorpio: 8,
            sagittarius: 9, capricorn: 10, aquarius: 11, pisces: 12
        };
        return houseMapping[sunSign] || 1;
    }

    // 決定職業
    determineProfession(attributes) {
        // 按稀有度排序，優先檢查傳說級職業
        const sortedProfessions = [...this.professions].sort((a, b) => {
            const rarityOrder = { legendary: 3, rare: 2, uncommon: 1, common: 0 };
            return rarityOrder[b.rarity] - rarityOrder[a.rarity];
        });

        for (let profession of sortedProfessions) {
            let qualified = true;
            let overqualified = 0;

            for (let attr in profession.requirements) {
                if (attributes[attr] < profession.requirements[attr]) {
                    qualified = false;
                    break;
                } else if (attributes[attr] >= profession.requirements[attr] + 2) {
                    overqualified++;
                }
            }

            if (qualified) {
                // 如果大幅超過要求，有機會獲得更高級職業
                if (overqualified >= 2 && profession.rarity !== 'legendary') {
                    continue; // 繼續尋找更高級的職業
                }
                return profession;
            }
        }

        // 如果沒有符合條件的，返回基礎職業
        return {
            name: '星空學徒',
            description: '剛踏入星空世界的新手冒險者，擁有無限的成長潛力',
            skills: ['基礎戰鬥', '基礎魔法', '學習能力', '適應力', '星空感知'],
            element: 'neutral',
            rarity: 'common'
        };
    }

    // 計算評級
    calculateGrade(attributes, profession) {
        const totalScore = Object.values(attributes).reduce((sum, val) => sum + val, 0);
        const averageScore = totalScore / 6;
        
        // 基礎評級
        let baseGrade = 'D';
        if (averageScore >= 18) baseGrade = 'SS';
        else if (averageScore >= 16) baseGrade = 'S';
        else if (averageScore >= 14) baseGrade = 'A';
        else if (averageScore >= 12) baseGrade = 'B';
        else if (averageScore >= 10) baseGrade = 'C';

        // 職業稀有度加成
        if (profession.rarity === 'legendary' && baseGrade !== 'SS') {
            const gradeOrder = ['D', 'C', 'B', 'A', 'S', 'SS'];
            const currentIndex = gradeOrder.indexOf(baseGrade);
            if (currentIndex < gradeOrder.length - 1) {
                baseGrade = gradeOrder[currentIndex + 1];
            }
        }

        return baseGrade;
    }

    // 生成特殊能力
    generateSpecialAbilities(chartData, profession) {
        const abilities = [];

        // 基於職業的特殊能力
        if (profession.rarity === 'legendary') {
            abilities.push('傳說級天賦');
        } else if (profession.rarity === 'rare') {
            abilities.push('稀有級天賦');
        }

        // 基於行星配置的特殊能力
        const planetCount = Object.values(chartData.planets).filter(sign => sign && sign !== '').length;
        if (planetCount >= 8) {
            abilities.push('完整星盤加成');
        } else if (planetCount >= 6) {
            abilities.push('豐富星象影響');
        }

        // 基於元素分布的特殊能力
        const elementCount = this.countElements(chartData);
        const dominantElement = this.getDominantElement(elementCount);
        if (dominantElement) {
            abilities.push(`${dominantElement}元素親和`);
        }

        return abilities.length > 0 ? abilities : ['星空親和力'];
    }

    // 計算元素分布
    countElements(chartData) {
        const elementCount = { fire: 0, earth: 0, air: 0, water: 0 };
        const signElements = {
            aries: 'fire', leo: 'fire', sagittarius: 'fire',
            taurus: 'earth', virgo: 'earth', capricorn: 'earth',
            gemini: 'air', libra: 'air', aquarius: 'air',
            cancer: 'water', scorpio: 'water', pisces: 'water'
        };

        for (let planet in chartData.planets) {
            const sign = chartData.planets[planet];
            if (sign && signElements[sign]) {
                elementCount[signElements[sign]]++;
            }
        }

        return elementCount;
    }

    // 獲取主導元素
    getDominantElement(elementCount) {
        let maxCount = 0;
        let dominantElement = null;

        for (let element in elementCount) {
            if (elementCount[element] > maxCount) {
                maxCount = elementCount[element];
                dominantElement = element;
            }
        }

        const elementNames = {
            fire: '火',
            earth: '土',
            air: '風',
            water: '水'
        };

        return maxCount >= 3 ? elementNames[dominantElement] : null;
    }

    // 生成詳細描述
    generateDescription(profession, attributes, planetaryPowers) {
        const descriptions = [];
        
        descriptions.push(`這位${profession.name}展現出了${profession.description}`);
        
        // 基於最高屬性的描述
        const maxAttr = Object.keys(attributes).reduce((a, b) => 
            attributes[a] > attributes[b] ? a : b
        );
        
        const attrDescriptions = {
            strength: '擁有驚人的力量，能在戰鬥中發揮強大的物理威力',
            intelligence: '智慧超群，能夠理解複雜的魔法理論和戰術策略',
            agility: '身手敏捷，動作如風，擅長快速移動和精準攻擊',
            wisdom: '洞察力深刻，能感知他人無法察覺的細微變化',
            charisma: '魅力非凡，天生具有領導氣質和感染他人的能力',
            constitution: '體質強健，擁有超乎常人的耐力和恢復能力'
        };

        if (attrDescriptions[maxAttr]) {
            descriptions.push(attrDescriptions[maxAttr]);
        }

        // 基於行星力量的描述
        if (planetaryPowers.length > 0) {
            const strongPowers = planetaryPowers.filter(p => p.power === '強勢');
            if (strongPowers.length > 0) {
                descriptions.push(`受到${strongPowers[0].planet}在${strongPowers[0].sign}的強勢影響，展現出獨特的天賦`);
            }
        }

        return descriptions.join('。') + '。';
    }
}

// 全局實例
window.completeCharacterGenerator = new CompleteCharacterGenerator();
console.log('[CompleteCharacterGenerator] 完整角色生成器已初始化');


#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
虹靈御所占星主角生成系統 - 簡化版API
不依賴kerykeion，使用模擬數據進行演示
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
import random
import json
from datetime import datetime

app = Flask(__name__)
CORS(app)

# 星座列表
ZODIAC_SIGNS = [
    "牡羊座", "金牛座", "雙子座", "巨蟹座", "獅子座", "處女座",
    "天秤座", "天蠍座", "射手座", "摩羯座", "水瓶座", "雙魚座"
]

# 行星列表
PLANETS = {
    "sun": "太陽",
    "moon": "月亮", 
    "mercury": "水星",
    "venus": "金星",
    "mars": "火星",
    "jupiter": "木星",
    "saturn": "土星",
    "uranus": "天王星",
    "neptune": "海王星",
    "pluto": "冥王星"
}

# D&D職業列表
DND_CLASSES = [
    {"name": "聖騎士", "description": "正義的戰士，以神聖力量守護弱者"},
    {"name": "法師", "description": "掌握奧術魔法的智者"},
    {"name": "盜賊", "description": "靈活敏捷的暗影行者"},
    {"name": "戰士", "description": "勇敢的近戰專家"},
    {"name": "牧師", "description": "神聖的治療者和引導者"},
    {"name": "遊俠", "description": "自然的守護者和追蹤專家"},
    {"name": "野蠻人", "description": "原始力量的化身"},
    {"name": "吟遊詩人", "description": "魅力四射的表演者和魔法使用者"},
    {"name": "術士", "description": "天生的魔法天才"},
    {"name": "邪術師", "description": "與異界存在締結契約的魔法使用者"}
]

def generate_mock_birth_chart(birth_data):
    """生成模擬星盤數據"""
    planets = {}
    
    # 根據出生月份確定太陽星座
    month = birth_data.get('month', 1)
    sun_sign_index = (month - 1) % 12
    
    for planet_key, planet_name in PLANETS.items():
        if planet_key == 'sun':
            sign = ZODIAC_SIGNS[sun_sign_index]
        else:
            sign = random.choice(ZODIAC_SIGNS)
        
        planets[planet_key] = {
            "name": planet_name,
            "sign": sign,
            "position": round(random.uniform(0, 30), 2),
            "house": random.randint(1, 12),
            "retrograde": random.choice([True, False]) if planet_key not in ['sun', 'moon'] else False
        }
    
    return {
        "planets": planets,
        "houses": {f"house_{i}": random.choice(ZODIAC_SIGNS) for i in range(1, 13)}
    }

def generate_dnd_character(birth_chart, name):
    """根據星盤生成D&D角色"""
    
    # 基於太陽星座選擇職業
    sun_sign = birth_chart["planets"]["sun"]["sign"]
    class_choice = random.choice(DND_CLASSES)
    
    # 生成屬性 (3d6 + 3 = 6-21)
    stats = {
        "strength": random.randint(8, 18),
        "dexterity": random.randint(8, 18),
        "constitution": random.randint(8, 18),
        "intelligence": random.randint(8, 18),
        "wisdom": random.randint(8, 18),
        "charisma": random.randint(8, 18)
    }
    
    # 計算評級
    total_stats = sum(stats.values())
    if total_stats >= 100:
        rating = "SS"
    elif total_stats >= 90:
        rating = "S"
    elif total_stats >= 80:
        rating = "A"
    elif total_stats >= 70:
        rating = "B"
    elif total_stats >= 60:
        rating = "C"
    else:
        rating = "D"
    
    # 生成技能
    skills = random.sample([
        "運動", "欺瞞", "歷史", "洞察", "威嚇", "調查",
        "醫療", "自然", "察覺", "表演", "說服", "宗教",
        "巧手", "隱匿", "求生", "動物馴養", "奧秘", "特技"
    ], k=random.randint(3, 6))
    
    # 生成背景故事
    backgrounds = [
        f"{name}是一位{class_choice['name']}，{class_choice['description']}。",
        f"出生在{sun_sign}的影響下，{name}展現出獨特的個性特質。",
        f"從小就對冒險充滿渴望，{name}踏上了成為英雄的道路。",
        f"憑藉著{random.choice(['勇氣', '智慧', '魅力', '堅韌'])}，{name}在各種挑戰中脫穎而出。",
        f"如今，{name}已經成為一位經驗豐富的冒險者，準備面對更大的挑戰。"
    ]
    
    background = "".join(backgrounds)
    
    return {
        "name": name,
        "class": class_choice,
        "stats": stats,
        "rating": rating,
        "skills": skills,
        "background": background
    }

@app.route('/api/health', methods=['GET'])
def health_check():
    """健康檢查端點"""
    return jsonify({
        "status": "healthy",
        "service": "虹靈御所占星系統",
        "version": "1.0.0",
        "timestamp": datetime.now().isoformat()
    })

@app.route('/api/calculate_chart', methods=['POST'])
def calculate_chart():
    """計算星盤並生成D&D角色"""
    try:
        data = request.get_json()
        
        # 驗證必要欄位
        required_fields = ['name', 'year', 'month', 'day', 'hour', 'minute']
        for field in required_fields:
            if field not in data:
                return jsonify({
                    "success": False,
                    "error": f"缺少必要欄位: {field}"
                }), 400
        
        # 生成星盤
        birth_chart = generate_mock_birth_chart(data)
        
        # 生成D&D角色
        dnd_character = generate_dnd_character(birth_chart, data['name'])
        
        return jsonify({
            "success": True,
            "data": {
                "birth_chart": birth_chart,
                "dnd_character": dnd_character,
                "birth_info": {
                    "name": data['name'],
                    "birth_date": f"{data['year']}-{data['month']:02d}-{data['day']:02d}",
                    "birth_time": f"{data['hour']:02d}:{data['minute']:02d}",
                    "location": data.get('city', '未指定')
                }
            }
        })
        
    except Exception as e:
        return jsonify({
            "success": False,
            "error": f"計算失敗: {str(e)}"
        }), 500

@app.route('/', methods=['GET'])
def index():
    """首頁"""
    return jsonify({
        "service": "虹靈御所占星主角生成系統",
        "description": "基於占星學的D&D角色生成API",
        "endpoints": {
            "health": "/api/health",
            "calculate": "/api/calculate_chart"
        }
    })

if __name__ == '__main__':
    print("🌟 啟動虹靈御所占星系統 API (簡化版)...")
    print("📍 API文檔: http://localhost:5000")
    print("🔍 健康檢查: http://localhost:5000/api/health")
    app.run(host='0.0.0.0', port=5000, debug=True)


/**
 * 自動排盤API模塊
 * 整合Free Astrology API進行自動星盤計算
 */

class AutoChartAPI {
    constructor() {
        // 注意：在實際使用中需要註冊並獲取API密鑰
        this.apiKey = 'demo-key'; // 演示用密鑰
        this.baseUrl = 'https://api.freeastrologyapi.com';
        this.isDemo = true; // 演示模式，使用模擬數據
    }

    /**
     * 根據出生信息自動計算星盤
     * @param {Object} birthData - 出生信息
     * @param {string} birthData.date - 出生日期 (YYYY-MM-DD)
     * @param {string} birthData.time - 出生時間 (HH:MM)
     * @param {string} birthData.location - 出生地點
     * @param {number} birthData.latitude - 緯度
     * @param {number} birthData.longitude - 經度
     * @param {string} birthData.timezone - 時區
     * @returns {Promise<Object>} 星盤數據
     */
    async calculateChart(birthData) {
        if (this.isDemo) {
            // 演示模式：返回模擬數據
            return this.generateDemoChart(birthData);
        }

        try {
            const response = await fetch(`${this.baseUrl}/western-chart`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${this.apiKey}`
                },
                body: JSON.stringify({
                    date: birthData.date,
                    time: birthData.time,
                    location: birthData.location,
                    latitude: birthData.latitude,
                    longitude: birthData.longitude,
                    timezone: birthData.timezone
                })
            });

            if (!response.ok) {
                throw new Error(`API請求失敗: ${response.status}`);
            }

            const data = await response.json();
            return this.processChartData(data);
        } catch (error) {
            console.error('自動排盤API錯誤:', error);
            // 發生錯誤時返回演示數據
            return this.generateDemoChart(birthData);
        }
    }

    /**
     * 生成演示星盤數據
     * @param {Object} birthData - 出生信息
     * @returns {Object} 模擬星盤數據
     */
    generateDemoChart(birthData) {
        // 基於出生日期生成相對固定的模擬數據
        const dateHash = this.hashDate(birthData.date);
        
        return {
            planets: {
                sun: {
                    sign: this.getSignFromHash(dateHash, 0),
                    house: this.getHouseFromHash(dateHash, 0),
                    degree: (dateHash % 30) + Math.random() * 30,
                    retrograde: false // 太陽永不逆行
                },
                moon: {
                    sign: this.getSignFromHash(dateHash, 1),
                    house: this.getHouseFromHash(dateHash, 1),
                    degree: (dateHash % 30) + Math.random() * 30,
                    retrograde: false // 月亮永不逆行
                },
                mercury: {
                    sign: this.getSignFromHash(dateHash, 2),
                    house: this.getHouseFromHash(dateHash, 2),
                    degree: (dateHash % 30) + Math.random() * 30,
                    retrograde: Math.random() < 0.2 // 20%機率逆行
                },
                venus: {
                    sign: this.getSignFromHash(dateHash, 3),
                    house: this.getHouseFromHash(dateHash, 3),
                    degree: (dateHash % 30) + Math.random() * 30,
                    retrograde: Math.random() < 0.08 // 8%機率逆行
                },
                mars: {
                    sign: this.getSignFromHash(dateHash, 4),
                    house: this.getHouseFromHash(dateHash, 4),
                    degree: (dateHash % 30) + Math.random() * 30,
                    retrograde: Math.random() < 0.1 // 10%機率逆行
                },
                jupiter: {
                    sign: this.getSignFromHash(dateHash, 5),
                    house: this.getHouseFromHash(dateHash, 5),
                    degree: (dateHash % 30) + Math.random() * 30,
                    retrograde: Math.random() < 0.3 // 30%機率逆行
                },
                saturn: {
                    sign: this.getSignFromHash(dateHash, 6),
                    house: this.getHouseFromHash(dateHash, 6),
                    degree: (dateHash % 30) + Math.random() * 30,
                    retrograde: Math.random() < 0.35 // 35%機率逆行
                },
                uranus: {
                    sign: this.getSignFromHash(dateHash, 7),
                    house: this.getHouseFromHash(dateHash, 7),
                    degree: (dateHash % 30) + Math.random() * 30,
                    retrograde: Math.random() < 0.4 // 40%機率逆行
                },
                neptune: {
                    sign: this.getSignFromHash(dateHash, 8),
                    house: this.getHouseFromHash(dateHash, 8),
                    degree: (dateHash % 30) + Math.random() * 30,
                    retrograde: Math.random() < 0.4 // 40%機率逆行
                },
                pluto: {
                    sign: this.getSignFromHash(dateHash, 9),
                    house: this.getHouseFromHash(dateHash, 9),
                    degree: (dateHash % 30) + Math.random() * 30,
                    retrograde: Math.random() < 0.4 // 40%機率逆行
                },
                chiron: {
                    sign: this.getSignFromHash(dateHash, 10),
                    house: this.getHouseFromHash(dateHash, 10),
                    degree: (dateHash % 30) + Math.random() * 30,
                    retrograde: Math.random() < 0.3 // 30%機率逆行
                },
                ceres: {
                    sign: this.getSignFromHash(dateHash, 11),
                    house: this.getHouseFromHash(dateHash, 11),
                    degree: (dateHash % 30) + Math.random() * 30,
                    retrograde: Math.random() < 0.25 // 25%機率逆行
                }
            },
            birthInfo: birthData,
            calculatedAt: new Date().toISOString()
        };
    }

    /**
     * 處理API返回的星盤數據
     * @param {Object} apiData - API返回的原始數據
     * @returns {Object} 處理後的星盤數據
     */
    processChartData(apiData) {
        // 將API數據轉換為我們系統使用的格式
        return {
            planets: this.extractPlanetData(apiData),
            houses: this.extractHouseData(apiData),
            aspects: this.extractAspectData(apiData),
            birthInfo: apiData.birthInfo,
            calculatedAt: new Date().toISOString()
        };
    }

    /**
     * 從日期生成哈希值
     * @param {string} date - 日期字符串
     * @returns {number} 哈希值
     */
    hashDate(date) {
        let hash = 0;
        for (let i = 0; i < date.length; i++) {
            const char = date.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash = hash & hash; // 轉換為32位整數
        }
        return Math.abs(hash);
    }

    /**
     * 根據哈希值獲取星座
     * @param {number} hash - 哈希值
     * @param {number} offset - 偏移量
     * @returns {string} 星座名稱
     */
    getSignFromHash(hash, offset) {
        const signs = [
            'aries', 'taurus', 'gemini', 'cancer', 'leo', 'virgo',
            'libra', 'scorpio', 'sagittarius', 'capricorn', 'aquarius', 'pisces'
        ];
        return signs[(hash + offset) % 12];
    }

    /**
     * 根據哈希值獲取宮位
     * @param {number} hash - 哈希值
     * @param {number} offset - 偏移量
     * @returns {number} 宮位編號
     */
    getHouseFromHash(hash, offset) {
        return ((hash + offset) % 12) + 1;
    }

    /**
     * 獲取地理位置信息
     * @param {string} location - 地點名稱
     * @returns {Promise<Object>} 地理位置數據
     */
    async getLocationData(location) {
        // 演示模式：返回模擬地理數據
        const mockLocations = {
            '台北': { latitude: 25.0330, longitude: 121.5654, timezone: 'Asia/Taipei' },
            '台中': { latitude: 24.1477, longitude: 120.6736, timezone: 'Asia/Taipei' },
            '高雄': { latitude: 22.6273, longitude: 120.3014, timezone: 'Asia/Taipei' },
            '紐約': { latitude: 40.7128, longitude: -74.0060, timezone: 'America/New_York' },
            '倫敦': { latitude: 51.5074, longitude: -0.1278, timezone: 'Europe/London' },
            '東京': { latitude: 35.6762, longitude: 139.6503, timezone: 'Asia/Tokyo' }
        };

        return mockLocations[location] || mockLocations['台北'];
    }

    /**
     * 驗證出生信息
     * @param {Object} birthData - 出生信息
     * @returns {boolean} 是否有效
     */
    validateBirthData(birthData) {
        const required = ['date', 'time', 'location'];
        return required.every(field => birthData[field] && birthData[field].trim() !== '');
    }
}

// 導出模塊
window.AutoChartAPI = AutoChartAPI;


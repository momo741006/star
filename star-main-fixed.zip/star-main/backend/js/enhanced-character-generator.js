/**
 * 🌟 虹靈御所占星主角生成系統 - 增強版角色生成器
 * 整合自動排盤、逆行計算和詳細報告生成功能
 */

class EnhancedCharacterGenerator {
    constructor() {
        this.astroEngine = new AstroEngine();
        this.retrogradeCalculator = new RetrogradeCalculator();
        this.autoChartAPI = new AutoChartAPI();
        this.originalGenerator = new CharacterGenerator();
        
        this.initializeEnhancedData();
    }

    initializeEnhancedData() {
        // 增強職業系統
        this.enhancedClasses = {
            'cosmic_warrior': {
                name: '星界戰士',
                englishName: 'Cosmic Warrior',
                description: '融合星辰力量的戰士，能夠運用宇宙能量進行戰鬥',
                element: 'fire',
                primaryAttributes: ['strength', 'constitution'],
                requirements: { strength: 25, constitution: 20 },
                specialAbilities: ['星辰之力', '宇宙護盾', '恆星爆發'],
                retrogradeBonus: { mars: 5, saturn: 3 }
            },
            'astral_mage': {
                name: '星界法師',
                englishName: 'Astral Mage',
                description: '掌握星界魔法的法師，能夠操控時空和預知未來',
                element: 'air',
                primaryAttributes: ['intelligence', 'perception'],
                requirements: { intelligence: 25, perception: 20 },
                specialAbilities: ['時空扭曲', '星象預測', '靈魂投射'],
                retrogradeBonus: { mercury: 5, neptune: 4 }
            },
            'shadow_dancer': {
                name: '影舞者',
                englishName: 'Shadow Dancer',
                description: '在陰影中穿梭的神秘舞者，擅長隱匿和致命打擊',
                element: 'water',
                primaryAttributes: ['agility', 'perception'],
                requirements: { agility: 25, perception: 20 },
                specialAbilities: ['影遁術', '月影斬', '幻象分身'],
                retrogradeBonus: { venus: 4, pluto: 5 }
            },
            'nature_oracle': {
                name: '自然神諭師',
                englishName: 'Nature Oracle',
                description: '與自然溝通的神諭師，擁有治癒和預言的力量',
                element: 'earth',
                primaryAttributes: ['wisdom', 'charisma'],
                requirements: { wisdom: 25, charisma: 20 },
                specialAbilities: ['自然治癒', '動物溝通', '大地祝福'],
                retrogradeBonus: { jupiter: 4, uranus: 3 }
            },
            'void_mystic': {
                name: '虛空神秘學者',
                englishName: 'Void Mystic',
                description: '探索虛空奧秘的學者，掌握禁忌知識和黑暗力量',
                element: 'void',
                primaryAttributes: ['intelligence', 'willpower'],
                requirements: { intelligence: 24, willpower: 22 },
                specialAbilities: ['虛空凝視', '禁忌知識', '靈魂操控'],
                retrogradeBonus: { pluto: 6, neptune: 4 }
            }
        };

        // 逆行專屬職業
        this.retrogradeClasses = {
            'inner_alchemist': {
                name: '內在煉金術師',
                englishName: 'Inner Alchemist',
                description: '將內在衝突轉化為力量的煉金術師',
                requirements: { retrogradeCount: 3 },
                specialAbilities: ['情感煉金', '內在轉化', '心靈治癒']
            },
            'time_weaver': {
                name: '時間編織者',
                englishName: 'Time Weaver',
                description: '掌握時間逆流的神秘存在',
                requirements: { retrogradeCount: 4, mercury: true },
                specialAbilities: ['時間回溯', '命運編織', '因果操控']
            }
        };
    }

    /**
     * 根據出生信息生成增強角色
     * @param {Object} birthData - 出生信息
     * @param {string} characterName - 角色名稱
     * @returns {Object} 增強角色數據
     */
    async generateEnhancedCharacter(birthData, characterName) {
        try {
            // 自動計算星盤
            const chartData = await this.autoChartAPI.calculateChart(birthData);
            
            // 計算逆行影響
            const retrogradeEffects = this.retrogradeCalculator.calculateRetrogradeEffects(chartData);
            
            // 生成基礎角色（使用原有系統）
            const baseCharacter = this.originalGenerator.generateCharacter({
                name: characterName,
                ...this.convertChartToInput(chartData)
            });

            if (!baseCharacter.success) {
                throw new Error('基礎角色生成失敗');
            }

            // 增強角色數據
            const enhancedCharacter = await this.enhanceCharacter(
                baseCharacter.character,
                chartData,
                retrogradeEffects,
                birthData
            );

            return {
                success: true,
                character: enhancedCharacter,
                chartData: chartData,
                retrogradeEffects: retrogradeEffects
            };

        } catch (error) {
            console.error('增強角色生成錯誤:', error);
            return {
                success: false,
                error: error.message
            };
        }
    }

    /**
     * 增強角色數據
     * @param {Object} baseCharacter - 基礎角色
     * @param {Object} chartData - 星盤數據
     * @param {Object} retrogradeEffects - 逆行影響
     * @param {Object} birthData - 出生信息
     * @returns {Object} 增強角色
     */
    async enhanceCharacter(baseCharacter, chartData, retrogradeEffects, birthData) {
        // 應用逆行屬性修正
        const enhancedStats = this.applyRetrogradeModifiers(baseCharacter.stats, retrogradeEffects);
        
        // 判定增強職業
        const enhancedClass = this.determineEnhancedClass(enhancedStats, retrogradeEffects, baseCharacter.class);
        
        // 生成增強技能
        const enhancedSkills = this.generateEnhancedSkills(
            baseCharacter.skills,
            retrogradeEffects,
            enhancedClass
        );
        
        // 生成詳細描述
        const detailedDescription = this.generateDetailedDescription(
            baseCharacter,
            retrogradeEffects,
            enhancedClass,
            chartData
        );
        
        // 計算增強評分
        const enhancedScore = this.calculateEnhancedScore(enhancedStats, retrogradeEffects);
        
        // 生成奇幻元素
        const fantasyElements = this.generateFantasyElements(chartData, retrogradeEffects);

        return {
            ...baseCharacter,
            stats: enhancedStats,
            class: enhancedClass,
            skills: enhancedSkills,
            description: detailedDescription,
            totalScore: enhancedScore,
            retrogradeEffects: retrogradeEffects,
            fantasyElements: fantasyElements,
            birthInfo: birthData,
            enhancedAt: new Date().toISOString()
        };
    }

    /**
     * 應用逆行屬性修正
     * @param {Object} baseStats - 基礎屬性
     * @param {Object} retrogradeEffects - 逆行影響
     * @returns {Object} 修正後屬性
     */
    applyRetrogradeModifiers(baseStats, retrogradeEffects) {
        const enhancedStats = { ...baseStats };

        // 應用逆行修正
        for (const [attr, modifier] of Object.entries(retrogradeEffects.attributeModifiers)) {
            if (enhancedStats[attr] !== undefined) {
                enhancedStats[attr] += modifier;
                enhancedStats[attr] = Math.max(10, enhancedStats[attr]); // 最低10點
            }
        }

        // 添加新屬性
        if (retrogradeEffects.retrogradeCount > 0) {
            enhancedStats.willpower = (enhancedStats.strength + enhancedStats.constitution) / 2 + retrogradeEffects.retrogradeCount * 2;
            enhancedStats.intuition = (enhancedStats.perception + enhancedStats.intelligence) / 2 + retrogradeEffects.retrogradeCount;
        }

        return enhancedStats;
    }

    /**
     * 判定增強職業
     * @param {Object} stats - 角色屬性
     * @param {Object} retrogradeEffects - 逆行影響
     * @param {Object} baseClass - 基礎職業
     * @returns {Object} 增強職業
     */
    determineEnhancedClass(stats, retrogradeEffects, baseClass) {
        // 檢查逆行專屬職業
        for (const [classKey, classData] of Object.entries(this.retrogradeClasses)) {
            if (this.meetsRetrogradeClassRequirements(classData, retrogradeEffects)) {
                return {
                    ...classData,
                    key: classKey,
                    type: 'retrograde_exclusive',
                    baseClass: baseClass
                };
            }
        }

        // 檢查增強職業
        let bestClass = null;
        let bestScore = -1;

        for (const [classKey, classData] of Object.entries(this.enhancedClasses)) {
            const score = this.calculateClassScore(stats, classData, retrogradeEffects);
            if (score > bestScore) {
                bestScore = score;
                bestClass = {
                    ...classData,
                    key: classKey,
                    type: 'enhanced',
                    baseClass: baseClass
                };
            }
        }

        return bestClass || {
            ...baseClass,
            type: 'base',
            enhanced: false
        };
    }

    /**
     * 檢查逆行職業需求
     * @param {Object} classData - 職業數據
     * @param {Object} retrogradeEffects - 逆行影響
     * @returns {boolean} 是否符合需求
     */
    meetsRetrogradeClassRequirements(classData, retrogradeEffects) {
        if (classData.requirements.retrogradeCount && 
            retrogradeEffects.retrogradeCount < classData.requirements.retrogradeCount) {
            return false;
        }

        // 檢查特定行星逆行需求
        for (const [planet, required] of Object.entries(classData.requirements)) {
            if (planet !== 'retrogradeCount' && required) {
                // 這裡需要檢查特定行星是否逆行
                // 暫時簡化處理
                if (retrogradeEffects.retrogradeCount < 2) {
                    return false;
                }
            }
        }

        return true;
    }

    /**
     * 計算職業適合度分數
     * @param {Object} stats - 角色屬性
     * @param {Object} classData - 職業數據
     * @param {Object} retrogradeEffects - 逆行影響
     * @returns {number} 適合度分數
     */
    calculateClassScore(stats, classData, retrogradeEffects) {
        let score = 0;

        // 基礎屬性需求檢查
        for (const [attr, requirement] of Object.entries(classData.requirements)) {
            if (stats[attr] && stats[attr] >= requirement) {
                score += stats[attr];
            } else if (stats[attr]) {
                score -= (requirement - stats[attr]) * 2; // 懲罰不符合需求
            }
        }

        // 逆行加成
        if (classData.retrogradeBonus) {
            for (const [planet, bonus] of Object.entries(classData.retrogradeBonus)) {
                // 簡化：如果有逆行行星就給予加成
                if (retrogradeEffects.retrogradeCount > 0) {
                    score += bonus;
                }
            }
        }

        return score;
    }

    /**
     * 生成增強技能
     * @param {Array} baseSkills - 基礎技能
     * @param {Object} retrogradeEffects - 逆行影響
     * @param {Object} enhancedClass - 增強職業
     * @returns {Array} 增強技能列表
     */
    generateEnhancedSkills(baseSkills, retrogradeEffects, enhancedClass) {
        const enhancedSkills = [...baseSkills];

        // 添加逆行技能
        retrogradeEffects.bonusSkills.forEach(skill => {
            enhancedSkills.push({
                ...skill,
                category: 'retrograde',
                icon: '🌟',
                rarity: 'legendary'
            });
        });

        // 添加職業特殊技能
        if (enhancedClass.specialAbilities) {
            enhancedClass.specialAbilities.forEach(ability => {
                enhancedSkills.push({
                    name: ability,
                    type: '職業特技',
                    category: 'class_special',
                    icon: '⚡',
                    description: this.getSpecialAbilityDescription(ability),
                    rarity: 'epic'
                });
            });
        }

        return enhancedSkills;
    }

    /**
     * 獲取特殊能力描述
     * @param {string} abilityName - 能力名稱
     * @returns {string} 能力描述
     */
    getSpecialAbilityDescription(abilityName) {
        const descriptions = {
            '星辰之力': '汲取星辰能量增強攻擊力，在夜晚戰鬥時威力倍增',
            '宇宙護盾': '創造星光護盾抵禦攻擊，可反射魔法傷害',
            '恆星爆發': '釋放恆星級別的能量爆發，對大範圍敵人造成毀滅性傷害',
            '時空扭曲': '操控時空流動，可以減緩敵人行動或加速盟友',
            '星象預測': '通過觀察星象預知未來事件，提前做出應對',
            '靈魂投射': '將靈魂投射到其他地點進行偵察或溝通',
            '影遁術': '融入陰影中完全隱身，在黑暗中移動無聲無息',
            '月影斬': '運用月光之力進行致命斬擊，對邪惡生物有額外傷害',
            '幻象分身': '創造多個幻象分身迷惑敵人，真假難辨',
            '自然治癒': '運用自然力量治癒傷痛，可以治療疾病和詛咒',
            '動物溝通': '與各種動物進行心靈溝通，獲得牠們的幫助',
            '大地祝福': '獲得大地母親的祝福，提升所有盟友的能力',
            '虛空凝視': '凝視虛空深淵獲得禁忌知識，但可能承受精神創傷',
            '禁忌知識': '掌握被遺忘的古老知識，能夠施展失傳的法術',
            '靈魂操控': '操控靈魂能量，可以與死者溝通或操控不死生物',
            '情感煉金': '將負面情感轉化為正面力量，治癒心靈創傷',
            '內在轉化': '通過內在修煉實現自我蛻變，突破個人極限',
            '心靈治癒': '治癒他人的心靈創傷和精神疾病',
            '時間回溯': '短暫回溯時間，撤銷剛發生的不利事件',
            '命運編織': '編織命運之線，影響事件的發展方向',
            '因果操控': '操控因果關係，改變事件的結果'
        };

        return descriptions[abilityName] || '神秘而強大的特殊能力';
    }

    /**
     * 生成詳細描述
     * @param {Object} baseCharacter - 基礎角色
     * @param {Object} retrogradeEffects - 逆行影響
     * @param {Object} enhancedClass - 增強職業
     * @param {Object} chartData - 星盤數據
     * @returns {Object} 詳細描述
     */
    generateDetailedDescription(baseCharacter, retrogradeEffects, enhancedClass, chartData) {
        const description = {
            ...baseCharacter.description,
            retrogradeInfluence: retrogradeEffects.retrogradeDescription,
            classEvolution: this.generateClassEvolution(baseCharacter.class, enhancedClass),
            cosmicSignature: this.generateCosmicSignature(chartData),
            destinyPath: this.generateDestinyPath(enhancedClass, retrogradeEffects)
        };

        return description;
    }

    /**
     * 生成職業進化描述
     * @param {Object} baseClass - 基礎職業
     * @param {Object} enhancedClass - 增強職業
     * @returns {string} 職業進化描述
     */
    generateClassEvolution(baseClass, enhancedClass) {
        if (enhancedClass.type === 'base') {
            return `你保持著${baseClass.primary}的純粹道路，專精於傳統的技藝和能力。`;
        }

        if (enhancedClass.type === 'retrograde_exclusive') {
            return `逆行行星的深刻影響讓你超越了傳統的${baseClass.primary}道路，覺醒為${enhancedClass.name}。這是一條只有少數人能夠踏上的神秘之路。`;
        }

        return `從${baseClass.primary}的基礎上，你進化成為了${enhancedClass.name}。星辰的力量指引你走向更高層次的存在。`;
    }

    /**
     * 生成宇宙印記
     * @param {Object} chartData - 星盤數據
     * @returns {string} 宇宙印記描述
     */
    generateCosmicSignature(chartData) {
        const planetCount = Object.keys(chartData.planets).length;
        const retrogradeCount = Object.values(chartData.planets).filter(p => p.retrograde).length;
        
        let signature = `你的宇宙印記由${planetCount}顆行星構成，`;
        
        if (retrogradeCount > 0) {
            signature += `其中${retrogradeCount}顆處於逆行狀態，賦予你獨特的內在力量。`;
        } else {
            signature += `所有行星都處於順行狀態，讓你能夠直接表達宇宙能量。`;
        }

        return signature;
    }

    /**
     * 生成命運之路
     * @param {Object} enhancedClass - 增強職業
     * @param {Object} retrogradeEffects - 逆行影響
     * @returns {string} 命運之路描述
     */
    generateDestinyPath(enhancedClass, retrogradeEffects) {
        let path = `作為${enhancedClass.name}，你的命運之路充滿了`;
        
        if (retrogradeEffects.retrogradeCount >= 3) {
            path += '深度的內在探索和自我轉化。你將通過克服內在的挑戰來獲得真正的力量。';
        } else if (retrogradeEffects.retrogradeCount > 0) {
            path += '獨特的挑戰和機遇。逆行的影響讓你以不同的方式理解世界。';
        } else {
            path += '直接而明確的目標。你能夠清晰地表達自己的能力和意圖。';
        }

        return path;
    }

    /**
     * 計算增強評分
     * @param {Object} stats - 角色屬性
     * @param {Object} retrogradeEffects - 逆行影響
     * @returns {Object} 增強評分
     */
    calculateEnhancedScore(stats, retrogradeEffects) {
        const baseTotal = Object.values(stats).reduce((sum, value) => sum + value, 0);
        const retrogradeBonus = retrogradeEffects.bonusSkills.length * 5;
        const uniquenessBonus = retrogradeEffects.retrogradeCount * 3;
        
        const enhancedTotal = baseTotal + retrogradeBonus + uniquenessBonus;
        const average = enhancedTotal / Object.keys(stats).length;
        
        return {
            total: enhancedTotal,
            base: baseTotal,
            retrogradeBonus: retrogradeBonus,
            uniquenessBonus: uniquenessBonus,
            average: Math.round(average * 10) / 10,
            grade: this.getEnhancedGrade(average, retrogradeEffects.retrogradeCount),
            rarity: this.calculateRarity(retrogradeEffects)
        };
    }

    /**
     * 獲取增強等級
     * @param {number} average - 平均分
     * @param {number} retrogradeCount - 逆行數量
     * @returns {string} 等級
     */
    getEnhancedGrade(average, retrogradeCount) {
        let baseGrade = 'D';
        if (average >= 28) baseGrade = 'S+';
        else if (average >= 25) baseGrade = 'S';
        else if (average >= 22) baseGrade = 'A';
        else if (average >= 19) baseGrade = 'B';
        else if (average >= 16) baseGrade = 'C';

        // 逆行加成
        if (retrogradeCount >= 4) {
            return baseGrade + '★★★';
        } else if (retrogradeCount >= 2) {
            return baseGrade + '★★';
        } else if (retrogradeCount >= 1) {
            return baseGrade + '★';
        }

        return baseGrade;
    }

    /**
     * 計算稀有度
     * @param {Object} retrogradeEffects - 逆行影響
     * @returns {string} 稀有度
     */
    calculateRarity(retrogradeEffects) {
        if (retrogradeEffects.retrogradeCount >= 5) return 'Mythical';
        if (retrogradeEffects.retrogradeCount >= 4) return 'Legendary';
        if (retrogradeEffects.retrogradeCount >= 3) return 'Epic';
        if (retrogradeEffects.retrogradeCount >= 2) return 'Rare';
        if (retrogradeEffects.retrogradeCount >= 1) return 'Uncommon';
        return 'Common';
    }

    /**
     * 生成奇幻元素
     * @param {Object} chartData - 星盤數據
     * @param {Object} retrogradeEffects - 逆行影響
     * @returns {Object} 奇幻元素
     */
    generateFantasyElements(chartData, retrogradeEffects) {
        return {
            aura: this.generateAura(chartData),
            constellation: this.generateConstellation(chartData),
            magicalItems: this.generateMagicalItems(retrogradeEffects),
            companionSpirit: this.generateCompanionSpirit(chartData)
        };
    }

    /**
     * 生成光環
     * @param {Object} chartData - 星盤數據
     * @returns {Object} 光環信息
     */
    generateAura(chartData) {
        const colors = ['金色', '銀色', '紫色', '藍色', '綠色', '紅色'];
        const effects = ['閃爍', '流動', '脈動', '旋轉', '波動'];
        
        return {
            color: colors[Math.floor(Math.random() * colors.length)],
            effect: effects[Math.floor(Math.random() * effects.length)],
            intensity: Math.floor(Math.random() * 10) + 1
        };
    }

    /**
     * 生成星座
     * @param {Object} chartData - 星盤數據
     * @returns {string} 星座描述
     */
    generateConstellation(chartData) {
        const constellations = [
            '龍座', '鳳凰座', '獨角獸座', '天馬座', '聖杯座',
            '魔劍座', '智慧之樹座', '時間之輪座', '命運之網座'
        ];
        
        return constellations[Math.floor(Math.random() * constellations.length)];
    }

    /**
     * 生成魔法物品
     * @param {Object} retrogradeEffects - 逆行影響
     * @returns {Array} 魔法物品列表
     */
    generateMagicalItems(retrogradeEffects) {
        const items = [];
        
        if (retrogradeEffects.retrogradeCount >= 1) {
            items.push({
                name: '逆行水晶',
                type: '飾品',
                effect: '增強內在洞察力，減少外界干擾'
            });
        }
        
        if (retrogradeEffects.retrogradeCount >= 3) {
            items.push({
                name: '時間沙漏',
                type: '神器',
                effect: '可以短暫回溯時間，修正錯誤決定'
            });
        }
        
        return items;
    }

    /**
     * 生成守護靈
     * @param {Object} chartData - 星盤數據
     * @returns {Object} 守護靈信息
     */
    generateCompanionSpirit(chartData) {
        const spirits = [
            { name: '星光狐', type: '智慧型', ability: '預知危險' },
            { name: '月影狼', type: '戰鬥型', ability: '夜戰加成' },
            { name: '彩虹鳥', type: '輔助型', ability: '情緒治癒' },
            { name: '水晶龍', type: '魔法型', ability: '能量放大' }
        ];
        
        return spirits[Math.floor(Math.random() * spirits.length)];
    }

    /**
     * 轉換星盤數據為輸入格式
     * @param {Object} chartData - 星盤數據
     * @returns {Object} 輸入格式數據
     */
    convertChartToInput(chartData) {
        const input = {};
        
        for (const [planetName, planetData] of Object.entries(chartData.planets)) {
            input[planetName] = planetData.sign;
            input[planetName + 'House'] = planetData.house;
        }
        
        return input;
    }
}

// 導出模塊
window.EnhancedCharacterGenerator = EnhancedCharacterGenerator;


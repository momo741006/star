/**
 * 🌟 虹靈御所占星主角生成系統 - 角色生成器
 * 整合所有計算邏輯，生成完整的RPG角色
 */

class CharacterGenerator {
    constructor() {
        this.astroEngine = new AstroEngine();
        this.initializeClassData();
    }

    initializeClassData() {
        // D&D職業對應系統
        this.classMapping = {
            fire: {
                primary: ['戰士 Fighter', '野蠻人 Barbarian', '聖騎士 Paladin'],
                secondary: ['遊俠 Ranger', '術士 Sorcerer']
            },
            earth: {
                primary: ['戰士 Fighter', '牧師 Cleric', '德魯伊 Druid'],
                secondary: ['武僧 Monk', '遊俠 Ranger']
            },
            air: {
                primary: ['吟遊詩人 Bard', '法師 Wizard', '盜賊 Rogue'],
                secondary: ['術士 Sorcerer', '靈能師 Artificer']
            },
            water: {
                primary: ['牧師 Cleric', '德魯伊 Druid', '邪術師 Warlock'],
                secondary: ['吟遊詩人 Bard', '術士 Sorcerer']
            }
        };

        // 屬性對應的技能描述
        this.skillDescriptions = {
            charisma: {
                name: '魅力',
                icon: '✨',
                description: '領導力、說服力、社交能力',
                highLevel: '天生的領袖，能夠激勵他人並建立強大的人際網絡',
                mediumLevel: '具有良好的溝通能力和親和力',
                lowLevel: '在社交場合較為內向，但真誠可靠'
            },
            perception: {
                name: '感知',
                icon: '👁️',
                description: '直覺力、洞察力、情感敏感度',
                highLevel: '擁有敏銳的直覺，能夠察覺他人的情感變化和環境的細微差異',
                mediumLevel: '具有不錯的觀察力和同理心',
                lowLevel: '較為理性，依靠邏輯而非直覺做決定'
            },
            intelligence: {
                name: '智力',
                icon: '🧠',
                description: '學習能力、分析能力、記憶力',
                highLevel: '學習能力極強，善於分析複雜問題並找出解決方案',
                mediumLevel: '思維清晰，具有良好的學習和理解能力',
                lowLevel: '更偏向實踐學習，通過經驗積累知識'
            },
            dexterity: {
                name: '敏捷',
                icon: '⚡',
                description: '反應速度、靈活性、技巧性',
                highLevel: '反應迅速，動作靈活，在需要精細操作的任務中表現出色',
                mediumLevel: '具有良好的協調性和反應能力',
                lowLevel: '動作較為穩重，偏好深思熟慮後行動'
            },
            strength: {
                name: '力量',
                icon: '💪',
                description: '意志力、執行力、堅持力',
                highLevel: '意志堅定，執行力強，能夠克服困難達成目標',
                mediumLevel: '具有不錯的毅力和執行能力',
                lowLevel: '較為溫和，偏好合作而非強硬手段'
            },
            constitution: {
                name: '體質',
                icon: '🛡️',
                description: '耐力、穩定性、抗壓能力',
                highLevel: '擁有強大的耐力和抗壓能力，能夠在困難環境中保持穩定',
                mediumLevel: '具有良好的持久力和穩定性',
                lowLevel: '較為敏感，需要良好的環境來發揮最佳狀態'
            }
        };
    }

    /**
     * 生成完整角色
     */
    generateCharacter(inputData) {
        try {
            // 驗證輸入
            const validationErrors = this.astroEngine.validateInput(inputData);
            if (validationErrors.length > 0) {
                return {
                    success: false,
                    errors: validationErrors
                };
            }

            // 計算屬性
            const { stats, breakdown } = this.astroEngine.calculateCharacterStats(inputData);

            // 決定職業
            const characterClass = this.determineClass(inputData, stats);

            // 生成技能
            const skills = this.generateSkills(inputData, stats);

            // 生成描述
            const description = this.generateDescription(inputData, stats, characterClass);

            // 計算總體評分
            const totalScore = this.calculateTotalScore(stats);

            return {
                success: true,
                character: {
                    name: inputData.name || '神秘冒險者',
                    class: characterClass,
                    stats: stats,
                    breakdown: breakdown,
                    skills: skills,
                    description: description,
                    totalScore: totalScore,
                    birthChart: this.generateBirthChart(inputData)
                }
            };

        } catch (error) {
            return {
                success: false,
                errors: [`生成角色時發生錯誤: ${error.message}`]
            };
        }
    }

    /**
     * 決定D&D職業
     */
    determineClass(inputData, stats) {
        // 計算元素權重
        const elementWeight = {
            fire: 0,
            earth: 0,
            air: 0,
            water: 0
        };

        // 主要行星權重
        const planetWeights = {
            sun: 3, moon: 2, mars: 2, mercury: 1, venus: 1, jupiter: 1
        };

        Object.keys(planetWeights).forEach(planet => {
            const sign = inputData[planet];
            if (sign && this.astroEngine.zodiacData[sign]) {
                const element = this.astroEngine.zodiacData[sign].element.toLowerCase();
                elementWeight[element] += planetWeights[planet];
            }
        });

        // 找出主導元素
        let dominantElement = 'fire';
        let maxWeight = 0;
        for (const [element, weight] of Object.entries(elementWeight)) {
            if (weight > maxWeight) {
                maxWeight = weight;
                dominantElement = element;
            }
        }

        // 根據屬性微調職業選擇
        const classes = this.classMapping[dominantElement];
        let selectedClass = classes.primary[Math.floor(Math.random() * classes.primary.length)];

        // 根據最高屬性進行微調
        const maxStat = Object.keys(stats).reduce((a, b) => stats[a] > stats[b] ? a : b);
        
        if (maxStat === 'charisma' && dominantElement === 'fire') {
            selectedClass = '聖騎士 Paladin';
        } else if (maxStat === 'intelligence' && dominantElement === 'air') {
            selectedClass = '法師 Wizard';
        } else if (maxStat === 'perception' && dominantElement === 'water') {
            selectedClass = '德魯伊 Druid';
        } else if (maxStat === 'strength' && dominantElement === 'fire') {
            selectedClass = '戰士 Fighter';
        }

        return {
            primary: selectedClass,
            element: dominantElement,
            elementWeight: elementWeight,
            description: this.getClassDescription(selectedClass, dominantElement)
        };
    }

    /**
     * 獲取職業描述
     */
    getClassDescription(className, element) {
        const descriptions = {
            '戰士 Fighter': '勇敢的前線戰士，擅長各種武器和戰術',
            '野蠻人 Barbarian': '原始力量的化身，在戰鬥中狂暴無比',
            '聖騎士 Paladin': '正義的守護者，結合武力與神聖力量',
            '遊俠 Ranger': '自然的守護者，精通追蹤和遠程戰鬥',
            '術士 Sorcerer': '天生的魔法使用者，力量源自血脈',
            '牧師 Cleric': '神祇的代言人，擅長治療和神聖魔法',
            '德魯伊 Druid': '自然的朋友，能夠變形和操控自然力量',
            '武僧 Monk': '內在力量的修行者，身心合一的戰士',
            '吟遊詩人 Bard': '多才多藝的表演者，用音樂和故事施展魔法',
            '法師 Wizard': '學識淵博的魔法學者，掌握奧術知識',
            '盜賊 Rogue': '靈活的潛行者，擅長偷襲和技巧',
            '邪術師 Warlock': '與超自然存在締結契約的魔法使用者',
            '靈能師 Artificer': '魔法與科技的結合者，創造神奇物品'
        };

        return descriptions[className] || '神秘的冒險者';
    }

    /**
     * 生成技能列表
     */
    generateSkills(inputData, stats) {
        const skills = [];

        // 主要技能（基於最高屬性）
        const sortedStats = Object.entries(stats).sort(([,a], [,b]) => b - a);
        
        sortedStats.slice(0, 3).forEach(([stat, value], index) => {
            const skillData = this.skillDescriptions[stat];
            skills.push({
                name: `${skillData.name}專精`,
                type: index === 0 ? '主技能' : '副技能',
                icon: skillData.icon,
                value: value,
                description: this.getSkillLevelDescription(stat, value),
                category: 'primary'
            });
        });

        // 星座特殊技能
        if (inputData.sun) {
            const sunData = this.astroEngine.zodiacData[inputData.sun];
            skills.push({
                name: `${sunData.deity}的祝福`,
                type: '神祇技能',
                icon: '☀️',
                value: stats.charisma,
                description: `來自${sunData.name}守護神的力量，${sunData.traits.join('、')}`,
                category: 'divine'
            });
        }

        if (inputData.moon) {
            const moonData = this.astroEngine.zodiacData[inputData.moon];
            skills.push({
                name: `${moonData.name}直覺`,
                type: '被動技能',
                icon: '🌙',
                value: stats.perception,
                description: `內在${moonData.element}元素感知，${moonData.traits[0]}特質`,
                category: 'passive'
            });
        }

        // 元素技能
        const elementSkills = this.generateElementSkills(inputData, stats);
        skills.push(...elementSkills);

        return skills;
    }

    /**
     * 生成元素技能
     */
    generateElementSkills(inputData, stats) {
        const elementCount = { fire: 0, earth: 0, air: 0, water: 0 };
        
        // 計算元素分布
        ['sun', 'moon', 'mercury', 'venus', 'mars', 'jupiter'].forEach(planet => {
            const sign = inputData[planet];
            if (sign && this.astroEngine.zodiacData[sign]) {
                const element = this.astroEngine.zodiacData[sign].element.toLowerCase();
                elementCount[element]++;
            }
        });

        const skills = [];
        Object.entries(elementCount).forEach(([element, count]) => {
            if (count >= 2) {
                const elementSkill = this.getElementSkill(element, count, stats);
                if (elementSkill) {
                    skills.push(elementSkill);
                }
            }
        });

        return skills;
    }

    /**
     * 獲取元素技能
     */
    getElementSkill(element, count, stats) {
        const elementSkills = {
            fire: {
                name: '烈焰意志',
                icon: '🔥',
                description: '火元素的力量賦予你不屈的意志和行動力',
                value: stats.strength + count
            },
            earth: {
                name: '大地堅韌',
                icon: '🌍',
                description: '土元素的力量讓你擁有堅實的基礎和持久力',
                value: stats.constitution + count
            },
            air: {
                name: '風之智慧',
                icon: '💨',
                description: '風元素的力量提升你的思維敏捷和溝通能力',
                value: stats.intelligence + count
            },
            water: {
                name: '水之直覺',
                icon: '🌊',
                description: '水元素的力量增強你的直覺和情感感知',
                value: stats.perception + count
            }
        };

        const skill = elementSkills[element];
        if (skill) {
            return {
                ...skill,
                type: '元素技能',
                category: 'elemental'
            };
        }
        return null;
    }

    /**
     * 獲取技能等級描述
     */
    getSkillLevelDescription(stat, value) {
        const skillData = this.skillDescriptions[stat];
        if (value >= 25) {
            return skillData.highLevel;
        } else if (value >= 18) {
            return skillData.mediumLevel;
        } else {
            return skillData.lowLevel;
        }
    }

    /**
     * 生成角色描述
     */
    generateDescription(inputData, stats, characterClass) {
        const sunSign = inputData.sun;
        const moonSign = inputData.moon;
        
        if (!sunSign) return '請輸入完整的星盤資料';

        const sunData = this.astroEngine.zodiacData[sunSign];
        const moonData = moonSign ? this.astroEngine.zodiacData[moonSign] : null;

        // 找出最高和最低屬性
        const sortedStats = Object.entries(stats).sort(([,a], [,b]) => b - a);
        const maxStat = sortedStats[0];
        const minStat = sortedStats[sortedStats.length - 1];

        let description = {
            summary: '',
            personality: '',
            strengths: [],
            challenges: [],
            recommendations: []
        };

        // 一句話總結
        description.summary = `${sunData.name}守護的${characterClass.primary}，以${this.skillDescriptions[maxStat[0]].name}見長，適合在需要${this.skillDescriptions[maxStat[0]].description}的場合發揮所長。`;

        // 性格描述
        description.personality = `作為${sunData.name}的守護者，你天生具有${sunData.traits.join('、')}的特質。`;
        if (moonData) {
            description.personality += `內在的${moonData.name}能量讓你在情感上表現出${moonData.traits[0]}的一面。`;
        }
        description.personality += `你的${characterClass.element}元素主導特質使你成為一名出色的${characterClass.primary}。`;

        // 優勢
        sortedStats.slice(0, 3).forEach(([stat, value]) => {
            description.strengths.push(`${this.skillDescriptions[stat].name}出眾（${value}點）：${this.getSkillLevelDescription(stat, value)}`);
        });

        // 挑戰
        if (minStat[1] < 15) {
            description.challenges.push(`${this.skillDescriptions[minStat[0]].name}較弱（${minStat[1]}點）：${this.getSkillLevelDescription(minStat[0], minStat[1])}`);
        }

        // 建議
        description.recommendations.push(`發揮你的${this.skillDescriptions[maxStat[0]].name}優勢，在團隊中擔任相關角色`);
        description.recommendations.push(`通過實踐和學習來提升較弱的能力領域`);
        description.recommendations.push(`善用${sunData.name}的${sunData.traits[0]}特質來面對挑戰`);

        return description;
    }

    /**
     * 計算總體評分
     */
    calculateTotalScore(stats) {
        const total = Object.values(stats).reduce((sum, value) => sum + value, 0);
        const average = total / Object.keys(stats).length;
        
        return {
            total: total,
            average: Math.round(average * 10) / 10,
            grade: this.getGrade(average),
            distribution: this.getStatDistribution(stats)
        };
    }

    /**
     * 獲取等級評價
     */
    getGrade(average) {
        if (average >= 25) return 'S';
        if (average >= 22) return 'A';
        if (average >= 19) return 'B';
        if (average >= 16) return 'C';
        return 'D';
    }

    /**
     * 獲取屬性分布
     */
    getStatDistribution(stats) {
        const total = Object.values(stats).reduce((sum, value) => sum + value, 0);
        const distribution = {};
        
        Object.entries(stats).forEach(([stat, value]) => {
            distribution[stat] = Math.round((value / total) * 100);
        });
        
        return distribution;
    }

    /**
     * 生成出生星盤摘要
     */
    generateBirthChart(inputData) {
        const chart = {
            planets: {},
            elements: { fire: 0, earth: 0, air: 0, water: 0 },
            modes: { cardinal: 0, fixed: 0, mutable: 0 },
            polarities: { positive: 0, negative: 0 }
        };

        // 統計行星分布
        ['sun', 'moon', 'mercury', 'venus', 'mars', 'jupiter', 'saturn', 'uranus', 'neptune', 'pluto'].forEach(planet => {
            const sign = inputData[planet];
            const house = inputData[planet + 'House'];
            
            if (sign && this.astroEngine.zodiacData[sign]) {
                const signData = this.astroEngine.zodiacData[sign];
                chart.planets[planet] = {
                    sign: signData.name,
                    house: house || '未知',
                    element: signData.element,
                    mode: signData.mode,
                    polarity: signData.polarity
                };

                // 統計元素
                chart.elements[signData.element.toLowerCase()]++;
                
                // 統計模式
                const modeMap = { '開創': 'cardinal', '固定': 'fixed', '變動': 'mutable' };
                chart.modes[modeMap[signData.mode]]++;
                
                // 統計陰陽性
                chart.polarities[signData.polarity === '陽' ? 'positive' : 'negative']++;
            }
        });

        return chart;
    }
}

// 導出模塊
if (typeof module !== 'undefined' && module.exports) {
    module.exports = CharacterGenerator;
} else if (typeof window !== 'undefined') {
    window.CharacterGenerator = CharacterGenerator;
}


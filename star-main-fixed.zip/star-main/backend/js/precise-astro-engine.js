/**
 * 🌟 精確占星計算引擎
 * 基於天文學算法實現準確的行星位置和宮位計算
 */

class PreciseAstroEngine {
    constructor() {
        this.J2000 = 2451545.0; // J2000.0 epoch
        this.DEGREES_PER_RADIAN = 180.0 / Math.PI;
        this.RADIANS_PER_DEGREE = Math.PI / 180.0;
        
        // 星座名稱對應
        this.signNames = [
            '牡羊座', '金牛座', '雙子座', '巨蟹座', '獅子座', '處女座',
            '天秤座', '天蠍座', '射手座', '摩羯座', '水瓶座', '雙魚座'
        ];
        
        // 行星軌道參數 (簡化版，用於演示)
        this.planetData = {
            sun: {
                name: '太陽',
                symbol: '☉',
                meanLongitude: [280.46646, 36000.76983, 0.0003032],
                eccentricity: [0.01670862, -0.000042037, -0.0000001236],
                inclination: [0.0, 0.0, 0.0],
                ascendingNode: [0.0, 0.0, 0.0],
                perihelion: [102.93735, 1.71946, 0.00046]
            },
            moon: {
                name: '月亮',
                symbol: '☽',
                // 月亮計算更複雜，這裡使用簡化算法
                meanLongitude: [218.3164477, 481267.88123421, -0.0015786],
                meanAnomaly: [134.9633964, 477198.8675055, 0.0087414],
                meanDistance: [93.2720950, 483202.0175233, -0.0036539]
            },
            mercury: {
                name: '水星',
                symbol: '☿',
                meanLongitude: [252.25032350, 149472.67411175, 0.00000535],
                eccentricity: [0.20563593, 0.00001906, -0.00000003],
                inclination: [7.00497902, -0.00594749, -0.00000444],
                ascendingNode: [48.33076593, -0.12534081, 0.00000004],
                perihelion: [77.45779628, 0.16047689, -0.00000003]
            },
            venus: {
                name: '金星',
                symbol: '♀',
                meanLongitude: [181.97909950, 58517.81538729, 0.00000165],
                eccentricity: [0.00677672, -0.00004107, 0.00000001],
                inclination: [3.39467605, -0.00078890, -0.00000010],
                ascendingNode: [76.67984255, -0.27769418, 0.00000014],
                perihelion: [131.60246718, 0.00268329, -0.00000002]
            },
            mars: {
                name: '火星',
                symbol: '♂',
                meanLongitude: [355.43299958, 19140.30268499, 0.00000261],
                eccentricity: [0.09340062, 0.00009048, -0.00000008],
                inclination: [1.84969142, -0.00813131, -0.00000013],
                ascendingNode: [49.55953891, -0.29257343, 0.00000016],
                perihelion: [336.06023395, 0.44441088, -0.00000017]
            },
            jupiter: {
                name: '木星',
                symbol: '♃',
                meanLongitude: [34.39644051, 3034.74612775, 0.00000004],
                eccentricity: [0.04838624, -0.00013253, -0.00000004],
                inclination: [1.30439695, -0.00183714, 0.00000001],
                ascendingNode: [100.47390909, 0.20469106, 0.00000013],
                perihelion: [14.72847983, 0.21252668, 0.00000392]
            },
            saturn: {
                name: '土星',
                symbol: '♄',
                meanLongitude: [50.07744430, 1222.49362201, -0.00000004],
                eccentricity: [0.05386179, -0.00034550, -0.00000004],
                inclination: [2.48599187, 0.00193609, -0.00000001],
                ascendingNode: [113.66242448, -0.28867794, -0.00000009],
                perihelion: [93.05723748, 0.17966668, 0.00000077]
            },
            uranus: {
                name: '天王星',
                symbol: '♅',
                meanLongitude: [314.05500511, 428.48202785, 0.00000486],
                eccentricity: [0.04725744, -0.00004397, -0.00000001],
                inclination: [0.77263783, -0.00242939, 0.00000004],
                ascendingNode: [74.01692503, 0.04240589, 0.00000004],
                perihelion: [173.00529106, 0.09266985, 0.00000007]
            },
            neptune: {
                name: '海王星',
                symbol: '♆',
                meanLongitude: [304.34866548, 218.45945325, -0.00000347],
                eccentricity: [0.00859048, 0.00005105, 0.00000001],
                inclination: [1.77004347, 0.00035372, -0.00000004],
                ascendingNode: [131.78422574, -0.00508664, -0.00000002],
                perihelion: [48.12027554, 0.03252668, 0.00000014]
            },
            pluto: {
                name: '冥王星',
                symbol: '♇',
                meanLongitude: [238.92903833, 145.20780515, -0.00000006],
                eccentricity: [0.24882730, 0.00005170, 0.00000002],
                inclination: [17.14001206, 0.00004818, -0.00000001],
                ascendingNode: [110.30393684, -0.01183482, -0.00000018],
                perihelion: [224.06891629, -0.04062942, -0.00000002]
            }
        };
    }

    /**
     * 計算儒略日
     * @param {Date} date - 日期對象
     * @returns {number} 儒略日
     */
    calculateJulianDay(date) {
        const year = date.getUTCFullYear();
        const month = date.getUTCMonth() + 1;
        const day = date.getUTCDate();
        const hour = date.getUTCHours();
        const minute = date.getUTCMinutes();
        const second = date.getUTCSeconds();
        
        let a = Math.floor((14 - month) / 12);
        let y = year + 4800 - a;
        let m = month + 12 * a - 3;
        
        let jdn = day + Math.floor((153 * m + 2) / 5) + 365 * y + 
                  Math.floor(y / 4) - Math.floor(y / 100) + Math.floor(y / 400) - 32045;
        
        let jd = jdn + (hour - 12) / 24 + minute / 1440 + second / 86400;
        
        return jd;
    }

    /**
     * 計算自J2000.0以來的世紀數
     * @param {number} jd - 儒略日
     * @returns {number} 世紀數
     */
    calculateCenturiesFromJ2000(jd) {
        return (jd - this.J2000) / 36525.0;
    }

    /**
     * 標準化角度到0-360度範圍
     * @param {number} angle - 角度
     * @returns {number} 標準化後的角度
     */
    normalizeAngle(angle) {
        while (angle < 0) angle += 360;
        while (angle >= 360) angle -= 360;
        return angle;
    }

    /**
     * 計算行星的平均經度
     * @param {Object} planetData - 行星數據
     * @param {number} T - 世紀數
     * @returns {number} 平均經度
     */
    calculateMeanLongitude(planetData, T) {
        const [L0, L1, L2] = planetData.meanLongitude;
        return this.normalizeAngle(L0 + L1 * T + L2 * T * T);
    }

    /**
     * 計算太陽的視經度
     * @param {number} jd - 儒略日
     * @returns {number} 太陽經度
     */
    calculateSunLongitude(jd) {
        const T = this.calculateCenturiesFromJ2000(jd);
        const sunData = this.planetData.sun;
        
        // 計算平均經度
        const L = this.calculateMeanLongitude(sunData, T);
        
        // 計算平均近點角
        const M = this.normalizeAngle(357.52911 + 35999.05029 * T - 0.0001537 * T * T);
        const M_rad = M * this.RADIANS_PER_DEGREE;
        
        // 計算中心方程
        const C = (1.914602 - 0.004817 * T - 0.000014 * T * T) * Math.sin(M_rad) +
                  (0.019993 - 0.000101 * T) * Math.sin(2 * M_rad) +
                  0.000289 * Math.sin(3 * M_rad);
        
        // 真經度
        const trueLongitude = this.normalizeAngle(L + C);
        
        return trueLongitude;
    }

    /**
     * 計算月亮的經度
     * @param {number} jd - 儒略日
     * @returns {number} 月亮經度
     */
    calculateMoonLongitude(jd) {
        const T = this.calculateCenturiesFromJ2000(jd);
        const moonData = this.planetData.moon;
        
        // 月亮的平均經度
        const L = this.calculateMeanLongitude(moonData, T);
        
        // 月亮的平均近點角
        const M = this.normalizeAngle(134.9633964 + 477198.8675055 * T + 0.0087414 * T * T);
        
        // 太陽的平均近點角
        const M_sun = this.normalizeAngle(357.5291092 + 35999.0502909 * T - 0.0001536 * T * T);
        
        // 月亮與太陽平均經度差
        const D = this.normalizeAngle(297.8501921 + 445267.1114034 * T - 0.0018819 * T * T);
        
        // 月亮升交點平均經度
        const F = this.normalizeAngle(93.2720950 + 483202.0175233 * T - 0.0036539 * T * T);
        
        // 主要攝動項
        const perturbations = 
            6.288774 * Math.sin(M * this.RADIANS_PER_DEGREE) +
            1.274027 * Math.sin((2 * D - M) * this.RADIANS_PER_DEGREE) +
            0.658314 * Math.sin(2 * D * this.RADIANS_PER_DEGREE) +
            0.213618 * Math.sin(2 * M * this.RADIANS_PER_DEGREE) +
            -0.185116 * Math.sin(M_sun * this.RADIANS_PER_DEGREE) +
            -0.114332 * Math.sin(2 * F * this.RADIANS_PER_DEGREE);
        
        return this.normalizeAngle(L + perturbations);
    }

    /**
     * 計算行星經度 (簡化算法)
     * @param {string} planetName - 行星名稱
     * @param {number} jd - 儒略日
     * @returns {number} 行星經度
     */
    calculatePlanetLongitude(planetName, jd) {
        if (planetName === 'sun') {
            return this.calculateSunLongitude(jd);
        }
        if (planetName === 'moon') {
            return this.calculateMoonLongitude(jd);
        }
        
        const T = this.calculateCenturiesFromJ2000(jd);
        const planetData = this.planetData[planetName];
        
        if (!planetData) {
            throw new Error(`未知的行星: ${planetName}`);
        }
        
        // 計算平均經度
        const L = this.calculateMeanLongitude(planetData, T);
        
        // 簡化的攝動計算 (實際應該更複雜)
        let perturbation = 0;
        
        // 根據不同行星添加主要攝動項
        switch (planetName) {
            case 'mercury':
                perturbation = 0.3 * Math.sin((L + 50) * this.RADIANS_PER_DEGREE);
                break;
            case 'venus':
                perturbation = 0.2 * Math.sin((L + 30) * this.RADIANS_PER_DEGREE);
                break;
            case 'mars':
                perturbation = 0.5 * Math.sin((L + 120) * this.RADIANS_PER_DEGREE);
                break;
            case 'jupiter':
                perturbation = 0.1 * Math.sin((L + 200) * this.RADIANS_PER_DEGREE);
                break;
            case 'saturn':
                perturbation = 0.1 * Math.sin((L + 250) * this.RADIANS_PER_DEGREE);
                break;
            default:
                perturbation = 0;
        }
        
        return this.normalizeAngle(L + perturbation);
    }

    /**
     * 將經度轉換為星座和度數
     * @param {number} longitude - 經度
     * @returns {Object} 星座信息
     */
    longitudeToSign(longitude) {
        const signIndex = Math.floor(longitude / 30);
        const degree = longitude % 30;
        const minutes = (degree % 1) * 60;
        const seconds = (minutes % 1) * 60;
        
        return {
            sign: this.signNames[signIndex],
            signIndex: signIndex,
            degree: Math.floor(degree),
            minutes: Math.floor(minutes),
            seconds: Math.floor(seconds),
            decimalDegree: degree,
            longitude: longitude
        };
    }

    /**
     * 計算上升點
     * @param {number} jd - 儒略日
     * @param {number} latitude - 緯度
     * @param {number} longitude - 經度
     * @returns {number} 上升點經度
     */
    calculateAscendant(jd, latitude, longitude) {
        const T = this.calculateCenturiesFromJ2000(jd);
        
        // 計算恆星時
        const theta0 = 280.46061837 + 360.98564736629 * (jd - this.J2000) + 
                      0.000387933 * T * T - T * T * T / 38710000;
        
        const localSiderealTime = this.normalizeAngle(theta0 + longitude);
        
        // 計算黃道傾角
        const epsilon = 23.4392911 - 0.0130042 * T - 0.00000164 * T * T + 0.000000504 * T * T * T;
        const epsilon_rad = epsilon * this.RADIANS_PER_DEGREE;
        
        // 計算上升點
        const lat_rad = latitude * this.RADIANS_PER_DEGREE;
        const lst_rad = localSiderealTime * this.RADIANS_PER_DEGREE;
        
        const y = -Math.cos(lst_rad);
        const x = Math.sin(epsilon_rad) * Math.tan(lat_rad) + Math.cos(epsilon_rad) * Math.sin(lst_rad);
        
        let ascendant = Math.atan2(y, x) * this.DEGREES_PER_RADIAN;
        ascendant = this.normalizeAngle(ascendant);
        
        return ascendant;
    }

    /**
     * 計算天頂 (MC)
     * @param {number} jd - 儒略日
     * @param {number} longitude - 經度
     * @returns {number} 天頂經度
     */
    calculateMidheaven(jd, longitude) {
        const T = this.calculateCenturiesFromJ2000(jd);
        
        // 計算恆星時
        const theta0 = 280.46061837 + 360.98564736629 * (jd - this.J2000) + 
                      0.000387933 * T * T - T * T * T / 38710000;
        
        const localSiderealTime = this.normalizeAngle(theta0 + longitude);
        
        // 計算黃道傾角
        const epsilon = 23.4392911 - 0.0130042 * T - 0.00000164 * T * T + 0.000000504 * T * T * T;
        const epsilon_rad = epsilon * this.RADIANS_PER_DEGREE;
        
        // 天頂就是當地恆星時對應的黃道經度
        const lst_rad = localSiderealTime * this.RADIANS_PER_DEGREE;
        
        const y = Math.sin(lst_rad);
        const x = Math.cos(lst_rad) * Math.cos(epsilon_rad);
        
        let mc = Math.atan2(y, x) * this.DEGREES_PER_RADIAN;
        mc = this.normalizeAngle(mc);
        
        return mc;
    }

    /**
     * 計算宮位 (使用Placidus宮位制)
     * @param {number} ascendant - 上升點
     * @param {number} mc - 天頂
     * @param {number} latitude - 緯度
     * @returns {Array} 12宮位的起始經度
     */
    calculateHouses(ascendant, mc, latitude) {
        const houses = new Array(12);
        
        // 角宮位 (1, 4, 7, 10)
        houses[0] = ascendant;                    // 1宮 (上升點)
        houses[3] = this.normalizeAngle(mc + 180); // 4宮 (天底)
        houses[6] = this.normalizeAngle(ascendant + 180); // 7宮 (下降點)
        houses[9] = mc;                           // 10宮 (天頂)
        
        // 使用簡化的Placidus算法計算其他宮位
        const lat_rad = latitude * this.RADIANS_PER_DEGREE;
        
        // 2, 3宮
        for (let i = 1; i <= 2; i++) {
            const t = i / 3.0;
            houses[i] = this.normalizeAngle(houses[0] + t * (houses[3] - houses[0]));
        }
        
        // 5, 6宮
        for (let i = 4; i <= 5; i++) {
            const t = (i - 3) / 3.0;
            houses[i] = this.normalizeAngle(houses[3] + t * (houses[6] - houses[3]));
        }
        
        // 8, 9宮
        for (let i = 7; i <= 8; i++) {
            const t = (i - 6) / 3.0;
            houses[i] = this.normalizeAngle(houses[6] + t * (houses[9] - houses[6]));
        }
        
        // 11, 12宮
        for (let i = 10; i <= 11; i++) {
            const t = (i - 9) / 3.0;
            houses[i] = this.normalizeAngle(houses[9] + t * (houses[0] + 360 - houses[9]));
            if (houses[i] > 360) houses[i] -= 360;
        }
        
        return houses;
    }

    /**
     * 判斷行星所在宮位
     * @param {number} planetLongitude - 行星經度
     * @param {Array} houses - 宮位數組
     * @returns {number} 宮位號 (1-12)
     */
    getPlanetHouse(planetLongitude, houses) {
        for (let i = 0; i < 12; i++) {
            const currentHouse = houses[i];
            const nextHouse = houses[(i + 1) % 12];
            
            if (nextHouse > currentHouse) {
                if (planetLongitude >= currentHouse && planetLongitude < nextHouse) {
                    return i + 1;
                }
            } else {
                // 跨越0度的情況
                if (planetLongitude >= currentHouse || planetLongitude < nextHouse) {
                    return i + 1;
                }
            }
        }
        return 1; // 默認返回1宮
    }

    /**
     * 檢測行星是否逆行
     * @param {string} planetName - 行星名稱
     * @param {number} jd - 儒略日
     * @returns {boolean} 是否逆行
     */
    isRetrograde(planetName, jd) {
        // 太陽和月亮不會逆行
        if (planetName === 'sun' || planetName === 'moon') {
            return false;
        }
        
        // 計算前後一天的位置來判斷運動方向
        const longitude1 = this.calculatePlanetLongitude(planetName, jd - 1);
        const longitude2 = this.calculatePlanetLongitude(planetName, jd + 1);
        
        let diff = longitude2 - longitude1;
        
        // 處理跨越0度的情況
        if (diff > 180) diff -= 360;
        if (diff < -180) diff += 360;
        
        return diff < 0; // 如果經度減少，則為逆行
    }

    /**
     * 計算完整的星盤
     * @param {Date} birthDate - 出生日期
     * @param {number} latitude - 緯度
     * @param {number} longitude - 經度
     * @returns {Object} 完整星盤數據
     */
    calculateChart(birthDate, latitude, longitude) {
        const jd = this.calculateJulianDay(birthDate);
        
        // 計算所有行星位置
        const planets = {};
        const planetNames = ['sun', 'moon', 'mercury', 'venus', 'mars', 'jupiter', 'saturn', 'uranus', 'neptune', 'pluto'];
        
        for (const planetName of planetNames) {
            const planetLongitude = this.calculatePlanetLongitude(planetName, jd);
            const signInfo = this.longitudeToSign(planetLongitude);
            const isRetro = this.isRetrograde(planetName, jd);
            
            planets[planetName] = {
                name: this.planetData[planetName].name,
                symbol: this.planetData[planetName].symbol,
                longitude: planetLongitude,
                sign: signInfo.sign,
                signIndex: signInfo.signIndex,
                degree: signInfo.degree,
                minutes: signInfo.minutes,
                seconds: signInfo.seconds,
                retrograde: isRetro
            };
        }
        
        // 計算上升點和天頂
        const ascendant = this.calculateAscendant(jd, latitude, longitude);
        const mc = this.calculateMidheaven(jd, longitude);
        
        // 計算宮位
        const houses = this.calculateHouses(ascendant, mc, latitude);
        
        // 為每個行星分配宮位
        for (const planetName of planetNames) {
            planets[planetName].house = this.getPlanetHouse(planets[planetName].longitude, houses);
        }
        
        // 計算重要點位
        const angles = {
            ascendant: {
                name: '上升點',
                symbol: 'ASC',
                ...this.longitudeToSign(ascendant),
                longitude: ascendant
            },
            midheaven: {
                name: '天頂',
                symbol: 'MC',
                ...this.longitudeToSign(mc),
                longitude: mc
            },
            descendant: {
                name: '下降點',
                symbol: 'DSC',
                ...this.longitudeToSign(this.normalizeAngle(ascendant + 180)),
                longitude: this.normalizeAngle(ascendant + 180)
            },
            imumCoeli: {
                name: '天底',
                symbol: 'IC',
                ...this.longitudeToSign(this.normalizeAngle(mc + 180)),
                longitude: this.normalizeAngle(mc + 180)
            }
        };
        
        return {
            birthDate: birthDate,
            location: { latitude, longitude },
            julianDay: jd,
            planets: planets,
            houses: houses.map((house, index) => ({
                number: index + 1,
                longitude: house,
                sign: this.longitudeToSign(house).sign
            })),
            angles: angles,
            calculatedAt: new Date()
        };
    }

    /**
     * 格式化度數顯示
     * @param {Object} signInfo - 星座信息
     * @returns {string} 格式化的度數字符串
     */
    formatDegree(signInfo) {
        const retrograde = signInfo.retrograde ? '℞' : '';
        return `${signInfo.sign} ${signInfo.degree}°${String(signInfo.minutes).padStart(2, '0')}'${String(signInfo.seconds).padStart(2, '0')}"${retrograde}`;
    }

    /**
     * 生成星盤報告
     * @param {Object} chart - 星盤數據
     * @returns {string} 星盤報告
     */
    generateChartReport(chart) {
        let report = `🌟 星盤報告\n`;
        report += `出生時間: ${chart.birthDate.toLocaleString('zh-TW')}\n`;
        report += `出生地點: ${chart.location.latitude.toFixed(2)}°N, ${chart.location.longitude.toFixed(2)}°E\n\n`;
        
        report += `📍 重要點位:\n`;
        for (const [key, angle] of Object.entries(chart.angles)) {
            report += `${angle.name}: ${this.formatDegree(angle)}\n`;
        }
        
        report += `\n🪐 行星位置:\n`;
        for (const [key, planet] of Object.entries(chart.planets)) {
            report += `${planet.symbol} ${planet.name}: ${this.formatDegree(planet)} (${planet.house}宮)\n`;
        }
        
        return report;
    }
}

// 導出類
if (typeof module !== 'undefined' && module.exports) {
    module.exports = PreciseAstroEngine;
} else {
    window.PreciseAstroEngine = PreciseAstroEngine;
}


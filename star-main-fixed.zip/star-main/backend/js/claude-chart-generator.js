class ClaudeChartGenerator {
    constructor() {
        this.claudeAPI = new ClaudeAstroAPI();
        this.characterSystem = new WorkingCharacterSystem();
        console.log('[ClaudeChartGenerator] Claude星盤生成器已初始化');
    }

    // 從出生信息生成完整角色
    async generateCharacterFromBirth(birthData) {
        console.log('[ClaudeChartGenerator] 開始從出生信息生成角色:', birthData);

        try {
            // 顯示加載狀態
            this.showLoadingState('正在計算星盤...');

            // 調用Claude API生成星盤
            const chartData = await this.claudeAPI.generateFullChart(birthData);
            
            this.updateLoadingState('正在生成角色...');

            // 從星盤生成角色
            const character = this.characterSystem.generateCharacterFromClaudeChart(birthData.name, chartData);

            this.updateLoadingState('正在生成解讀報告...');

            // 生成詳細解讀報告
            const report = await this.claudeAPI.generateChartReport(chartData);

            // 組合完整結果
            const result = {
                character: character,
                chart: chartData,
                report: report,
                birthData: birthData,
                generatedAt: new Date().toISOString()
            };

            this.hideLoadingState();
            console.log('[ClaudeChartGenerator] 角色生成完成:', result);

            return result;

        } catch (error) {
            this.hideLoadingState();
            console.error('[ClaudeChartGenerator] 角色生成失敗:', error);
            throw error;
        }
    }

    // 顯示加載狀態
    showLoadingState(message) {
        // 創建或更新加載提示
        let loadingDiv = document.getElementById('claude-loading');
        if (!loadingDiv) {
            loadingDiv = document.createElement('div');
            loadingDiv.id = 'claude-loading';
            loadingDiv.className = 'claude-loading-overlay';
            document.body.appendChild(loadingDiv);
        }

        loadingDiv.innerHTML = `
            <div class="claude-loading-content">
                <div class="claude-loading-spinner"></div>
                <div class="claude-loading-text">${message}</div>
                <div class="claude-loading-subtitle">Claude正在為您計算專業星盤...</div>
            </div>
        `;
        loadingDiv.style.display = 'flex';
    }

    // 更新加載狀態
    updateLoadingState(message) {
        const loadingText = document.querySelector('.claude-loading-text');
        if (loadingText) {
            loadingText.textContent = message;
        }
    }

    // 隱藏加載狀態
    hideLoadingState() {
        const loadingDiv = document.getElementById('claude-loading');
        if (loadingDiv) {
            loadingDiv.style.display = 'none';
        }
    }

    // 驗證出生信息
    validateBirthData(birthData) {
        const errors = [];

        if (!birthData.name || birthData.name.trim() === '') {
            errors.push('請輸入角色名稱');
        }

        if (!birthData.date || birthData.date === '') {
            errors.push('請選擇出生日期');
        }

        if (!birthData.time || birthData.time === '') {
            errors.push('請選擇出生時間');
        }

        if (!birthData.location || birthData.location === '') {
            errors.push('請選擇出生地點');
        }

        // 驗證日期格式
        if (birthData.date) {
            const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
            if (!dateRegex.test(birthData.date)) {
                errors.push('出生日期格式不正確');
            }
        }

        // 驗證時間格式
        if (birthData.time) {
            const timeRegex = /^\d{2}:\d{2}$/;
            if (!timeRegex.test(birthData.time)) {
                errors.push('出生時間格式不正確');
            }
        }

        return errors;
    }

    // 格式化星盤數據用於顯示
    formatChartForDisplay(chartData) {
        const formatted = {
            planets: {},
            houses: {},
            summary: chartData.summary || {}
        };

        // 格式化行星數據
        Object.entries(chartData.planets).forEach(([planet, data]) => {
            formatted.planets[planet] = {
                ...data,
                signName: this.getSignName(data.sign),
                signSymbol: this.getSignSymbol(data.sign),
                planetSymbol: this.getPlanetSymbol(planet),
                formattedDegree: `${Math.floor(data.degree)}°${Math.floor((data.degree % 1) * 60)}'`
            };
        });

        // 格式化宮位數據
        Object.entries(chartData.houses).forEach(([house, data]) => {
            formatted.houses[house] = {
                ...data,
                signName: this.getSignName(data.sign),
                signSymbol: this.getSignSymbol(data.sign),
                formattedDegree: `${Math.floor(data.degree)}°${Math.floor((data.degree % 1) * 60)}'`
            };
        });

        return formatted;
    }

    // 獲取星座中文名稱
    getSignName(signKey) {
        const signNames = {
            'aries': '牡羊座',
            'taurus': '金牛座',
            'gemini': '雙子座',
            'cancer': '巨蟹座',
            'leo': '獅子座',
            'virgo': '處女座',
            'libra': '天秤座',
            'scorpio': '天蠍座',
            'sagittarius': '射手座',
            'capricorn': '摩羯座',
            'aquarius': '水瓶座',
            'pisces': '雙魚座'
        };
        return signNames[signKey] || signKey;
    }

    // 獲取星座符號
    getSignSymbol(signKey) {
        const signSymbols = {
            'aries': '♈',
            'taurus': '♉',
            'gemini': '♊',
            'cancer': '♋',
            'leo': '♌',
            'virgo': '♍',
            'libra': '♎',
            'scorpio': '♏',
            'sagittarius': '♐',
            'capricorn': '♑',
            'aquarius': '♒',
            'pisces': '♓'
        };
        return signSymbols[signKey] || '?';
    }

    // 獲取行星符號
    getPlanetSymbol(planetKey) {
        const planetSymbols = {
            'sun': '☀️',
            'moon': '🌙',
            'mercury': '☿',
            'venus': '♀',
            'mars': '♂',
            'jupiter': '♃',
            'saturn': '♄',
            'uranus': '♅',
            'neptune': '♆',
            'pluto': '♇'
        };
        return planetSymbols[planetKey] || '?';
    }
}

// 將ClaudeChartGenerator暴露到全局
window.ClaudeChartGenerator = ClaudeChartGenerator;


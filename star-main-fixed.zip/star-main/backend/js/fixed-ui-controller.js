/**
 * 🌟 虹靈御所占星系統 - 修復版UI控制器
 * 修復角色生成和模式切換問題
 */

class FixedUIController {
    constructor() {
        this.currentChart = null;
        this.currentCharacter = null;
        this.isAutoMode = false;
        
        this.initializeElements();
        this.bindEvents();
        this.initializeCharacterGenerator();
    }

    initializeElements() {
        // 模式切換按鈕
        this.manualModeBtn = document.querySelector('button:nth-child(1)');
        this.autoModeBtn = document.querySelector('button:nth-child(2)');
        
        // 輸入區域
        this.manualMode = document.getElementById('manualMode');
        this.autoMode = document.getElementById('autoMode');
        
        // 表單元素
        this.characterNameInput = document.getElementById('characterName');
        this.generateBtn = document.querySelector('button[id*="generate"], .generate-btn');
        
        // 星座選擇器
        this.signSelectors = {
            sun: document.getElementById('sun'),
            moon: document.getElementById('moon'),
            mercury: document.getElementById('mercury'),
            venus: document.getElementById('venus'),
            mars: document.getElementById('mars'),
            jupiter: document.getElementById('jupiter')
        };
        
        // 自動排盤輸入
        this.birthDateInput = document.getElementById('birthDate');
        this.birthTimeInput = document.getElementById('birthTime');
        this.birthLocationInput = document.getElementById('birthLocation');
        
        // 結果顯示區域
        this.resultSection = document.getElementById('resultSection');
        this.characterCard = document.getElementById('characterCard');
        
        console.log('Elements initialized:', {
            manualModeBtn: !!this.manualModeBtn,
            autoModeBtn: !!this.autoModeBtn,
            manualMode: !!this.manualMode,
            autoMode: !!this.autoMode,
            generateBtn: !!this.generateBtn,
            signSelectors: Object.keys(this.signSelectors).map(k => k + ':' + !!this.signSelectors[k])
        });
    }

    initializeCharacterGenerator() {
        // 初始化角色生成器
        if (typeof EnhancedCharacterGenerator !== 'undefined') {
            this.characterGenerator = new EnhancedCharacterGenerator();
            console.log('Enhanced character generator initialized');
        } else if (typeof CharacterGenerator !== 'undefined') {
            this.characterGenerator = new CharacterGenerator();
            console.log('Basic character generator initialized');
        } else {
            console.warn('Character generator not found, using fallback');
            this.characterGenerator = {
                generateCharacter: (chart) => this.fallbackCharacterGeneration(chart)
            };
        }
        
        // 確保生成器對象存在
        if (!this.characterGenerator || typeof this.characterGenerator.generateCharacter !== 'function') {
            console.warn('Character generator invalid, creating fallback');
            this.characterGenerator = {
                generateCharacter: (chart) => this.fallbackCharacterGeneration(chart)
            };
        }
    }

    bindEvents() {
        // 模式切換
        if (this.manualModeBtn) {
            this.manualModeBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.switchToManualMode();
            });
        }
        if (this.autoModeBtn) {
            this.autoModeBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.switchToAutoMode();
            });
        }
        
        // 生成按鈕
        if (this.generateBtn) {
            this.generateBtn.addEventListener('click', (e) => {
                e.preventDefault();
                if (this.isAutoMode) {
                    this.generateCharacterAuto();
                } else {
                    this.generateCharacterManual();
                }
            });
        }
        
        console.log('Events bound successfully');
    }

    switchToManualMode() {
        console.log('Switching to manual mode');
        this.isAutoMode = false;
        
        // 更新按鈕狀態
        if (this.manualModeBtn) {
            this.manualModeBtn.classList.add('active');
        }
        if (this.autoModeBtn) {
            this.autoModeBtn.classList.remove('active');
        }
        
        // 切換顯示區域
        if (this.manualMode) {
            this.manualMode.style.display = 'block';
        }
        if (this.autoMode) {
            this.autoMode.style.display = 'none';
        }
        
        this.showMessage('已切換到手動輸入模式', 'success');
    }

    switchToAutoMode() {
        console.log('Switching to auto mode');
        this.isAutoMode = true;
        
        // 更新按鈕狀態
        if (this.autoModeBtn) {
            this.autoModeBtn.classList.add('active');
        }
        if (this.manualModeBtn) {
            this.manualModeBtn.classList.remove('active');
        }
        
        // 切換顯示區域
        if (this.manualMode) {
            this.manualMode.style.display = 'none';
        }
        if (this.autoMode) {
            this.autoMode.style.display = 'block';
        }
        
        this.showMessage('已切換到自動排盤模式', 'success');
    }

    async generateCharacterManual() {
        try {
            console.log('Starting manual character generation');
            this.showLoadingState();
            
            // 驗證角色名稱
            const characterName = this.characterNameInput?.value?.trim();
            if (!characterName) {
                throw new Error('請輸入角色名稱');
            }
            
            // 收集星座選擇
            const selectedSigns = {};
            const requiredSigns = ['sun', 'moon', 'mercury', 'venus', 'mars', 'jupiter'];
            
            for (const planet of requiredSigns) {
                const selector = this.signSelectors[planet];
                console.log(`Checking ${planet}:`, selector?.value, selector?.selectedIndex);
                
                if (!selector || !selector.value || selector.value === '') {
                    throw new Error(`請選擇${this.getPlanetName(planet)}星座`);
                }
                
                selectedSigns[planet] = {
                    sign: selector.value,
                    signName: selector.options[selector.selectedIndex].text.split(' ')[1] || selector.value
                };
            }
            
            console.log('Selected signs:', selectedSigns);
            
            // 創建模擬星盤數據
            const mockChart = this.createMockChart(selectedSigns);
            this.currentChart = mockChart;
            
            // 生成角色
            const character = await this.characterGenerator.generateCharacter(mockChart);
            character.name = characterName;
            this.currentCharacter = character;
            
            // 顯示結果
            this.displayCharacter(character);
            this.hideLoadingState();
            this.showMessage('角色生成成功！', 'success');
            
        } catch (error) {
            console.error('Manual generation error:', error);
            this.hideLoadingState();
            this.showMessage(error.message, 'error');
        }
    }

    async generateCharacterAuto() {
        try {
            console.log('Starting auto character generation');
            this.showLoadingState();
            
            // 驗證輸入
            const birthDate = this.birthDateInput?.value;
            const birthTime = this.birthTimeInput?.value;
            const birthLocation = this.birthLocationInput?.value;
            
            if (!birthDate || !birthTime || !birthLocation) {
                throw new Error('請填寫完整的出生信息');
            }
            
            // 這裡應該調用真實的占星API
            // 暫時使用模擬數據
            const autoChart = this.createAutoChart(birthDate, birthTime, birthLocation);
            this.currentChart = autoChart;
            
            // 生成角色
            const character = await this.characterGenerator.generateCharacter(autoChart);
            character.name = document.getElementById('autoCharacterName')?.value || '神秘冒險者';
            this.currentCharacter = character;
            
            // 顯示結果
            this.displayCharacter(character);
            this.hideLoadingState();
            this.showMessage('自動排盤角色生成成功！', 'success');
            
        } catch (error) {
            console.error('Auto generation error:', error);
            this.hideLoadingState();
            this.showMessage(error.message, 'error');
        }
    }

    createMockChart(selectedSigns) {
        const chart = {
            planets: {},
            houses: {},
            aspects: [],
            metadata: {
                type: 'manual',
                timestamp: new Date().toISOString()
            }
        };
        
        // 轉換星座選擇為星盤數據
        Object.keys(selectedSigns).forEach(planet => {
            const signData = selectedSigns[planet];
            chart.planets[planet] = {
                sign: signData.sign,
                signName: signData.signName,
                degree: Math.random() * 30, // 隨機度數
                retrograde: Math.random() < 0.2 // 20%機率逆行
            };
        });
        
        return chart;
    }

    createAutoChart(birthDate, birthTime, birthLocation) {
        // 這裡應該調用真實的占星計算
        // 暫時返回模擬數據
        return {
            planets: {
                sun: { sign: 'leo', signName: '獅子座', degree: 15.5, retrograde: false },
                moon: { sign: 'cancer', signName: '巨蟹座', degree: 22.3, retrograde: false },
                mercury: { sign: 'virgo', signName: '處女座', degree: 8.7, retrograde: true },
                venus: { sign: 'libra', signName: '天秤座', degree: 12.1, retrograde: false },
                mars: { sign: 'aries', signName: '牡羊座', degree: 28.9, retrograde: false },
                jupiter: { sign: 'sagittarius', signName: '射手座', degree: 5.4, retrograde: false }
            },
            houses: {},
            aspects: [],
            metadata: {
                type: 'auto',
                birthDate,
                birthTime,
                birthLocation,
                timestamp: new Date().toISOString()
            }
        };
    }

    fallbackCharacterGeneration(chart) {
        // 簡單的後備角色生成
        const classes = ['戰士', '法師', '盜賊', '牧師', '遊俠', '吟遊詩人'];
        const randomClass = classes[Math.floor(Math.random() * classes.length)];
        
        return {
            class: randomClass,
            level: Math.floor(Math.random() * 20) + 1,
            attributes: {
                strength: Math.floor(Math.random() * 20) + 1,
                dexterity: Math.floor(Math.random() * 20) + 1,
                constitution: Math.floor(Math.random() * 20) + 1,
                intelligence: Math.floor(Math.random() * 20) + 1,
                wisdom: Math.floor(Math.random() * 20) + 1,
                charisma: Math.floor(Math.random() * 20) + 1
            },
            skills: ['基礎戰鬥', '生存技能'],
            rating: ['D', 'C', 'B', 'A', 'S'][Math.floor(Math.random() * 5)]
        };
    }

    displayCharacter(character) {
        // 創建角色卡片HTML
        const cardHTML = `
            <div class="character-card mystical-card">
                <div class="character-header">
                    <h2 class="character-name">${character.name}</h2>
                    <div class="character-class">${character.class} (${character.rating}級)</div>
                </div>
                
                <div class="character-stats">
                    <h3>屬性</h3>
                    <div class="stats-grid">
                        <div class="stat-item">
                            <div class="stat-name">力量</div>
                            <div class="stat-value">${character.attributes.strength}</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-name">敏捷</div>
                            <div class="stat-value">${character.attributes.dexterity}</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-name">體質</div>
                            <div class="stat-value">${character.attributes.constitution}</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-name">智力</div>
                            <div class="stat-value">${character.attributes.intelligence}</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-name">感知</div>
                            <div class="stat-value">${character.attributes.wisdom}</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-name">魅力</div>
                            <div class="stat-value">${character.attributes.charisma}</div>
                        </div>
                    </div>
                </div>
                
                <div class="character-skills">
                    <h3>技能</h3>
                    <div class="skills-list">
                        ${character.skills.map(skill => `<span class="skill-tag">${skill}</span>`).join('')}
                    </div>
                </div>
            </div>
        `;
        
        // 顯示結果區域
        if (this.resultSection) {
            this.resultSection.style.display = 'block';
            this.resultSection.innerHTML = cardHTML;
        } else {
            // 如果沒有結果區域，創建一個
            const resultDiv = document.createElement('div');
            resultDiv.id = 'resultSection';
            resultDiv.innerHTML = cardHTML;
            document.body.appendChild(resultDiv);
        }
        
        // 滾動到結果
        setTimeout(() => {
            if (this.resultSection) {
                this.resultSection.scrollIntoView({ behavior: 'smooth' });
            }
        }, 100);
    }

    showLoadingState() {
        if (this.generateBtn) {
            this.generateBtn.disabled = true;
            this.generateBtn.innerHTML = '<span class="loading-spinner">⏳</span> 正在生成角色...';
        }
    }

    hideLoadingState() {
        if (this.generateBtn) {
            this.generateBtn.disabled = false;
            this.generateBtn.innerHTML = '<span class="btn-icon">✨</span> 生成角色 <span class="btn-icon">✨</span>';
        }
    }

    showMessage(message, type = 'info') {
        console.log(`[${type.toUpperCase()}] ${message}`);
        
        // 創建通知元素
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.textContent = message;
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 15px 20px;
            border-radius: 8px;
            color: white;
            font-weight: bold;
            z-index: 10000;
            animation: slideIn 0.3s ease-out;
            background: ${type === 'error' ? '#e74c3c' : type === 'success' ? '#27ae60' : '#3498db'};
        `;
        
        document.body.appendChild(notification);
        
        // 3秒後自動移除
        setTimeout(() => {
            if (notification.parentNode) {
                notification.style.animation = 'slideOut 0.3s ease-in';
                setTimeout(() => {
                    if (notification.parentNode) {
                        notification.parentNode.removeChild(notification);
                    }
                }, 300);
            }
        }, 3000);
    }

    getPlanetName(planet) {
        const names = {
            sun: '太陽',
            moon: '月亮',
            mercury: '水星',
            venus: '金星',
            mars: '火星',
            jupiter: '木星'
        };
        return names[planet] || planet;
    }
}

// 添加CSS動畫
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    
    @keyframes slideOut {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(100%); opacity: 0; }
    }
    
    .loading-spinner {
        animation: spin 1s linear infinite;
    }
    
    @keyframes spin {
        from { transform: rotate(0deg); }
        to { transform: rotate(360deg); }
    }
    
    .character-card {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 30px;
        border-radius: 20px;
        margin: 20px 0;
        box-shadow: 0 20px 40px rgba(0,0,0,0.1);
    }
    
    .character-header {
        text-align: center;
        margin-bottom: 30px;
        border-bottom: 2px solid rgba(255,255,255,0.3);
        padding-bottom: 20px;
    }
    
    .character-name {
        font-size: 2.5rem;
        margin-bottom: 10px;
        text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
    }
    
    .character-class {
        font-size: 1.3rem;
        opacity: 0.9;
    }
    
    .stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
        gap: 15px;
        margin: 20px 0;
    }
    
    .stat-item {
        background: rgba(255,255,255,0.1);
        padding: 15px;
        border-radius: 10px;
        text-align: center;
        backdrop-filter: blur(10px);
    }
    
    .stat-name {
        font-size: 0.9rem;
        opacity: 0.8;
        margin-bottom: 5px;
    }
    
    .stat-value {
        font-size: 1.8rem;
        font-weight: bold;
    }
    
    .skills-list {
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
        margin-top: 15px;
    }
    
    .skill-tag {
        background: rgba(255,255,255,0.2);
        padding: 8px 15px;
        border-radius: 20px;
        font-size: 0.9rem;
        backdrop-filter: blur(10px);
    }
`;
document.head.appendChild(style);

// 初始化控制器
document.addEventListener('DOMContentLoaded', () => {
    console.log('Initializing Fixed UI Controller');
    window.uiController = new FixedUIController();
});


/**
 * 🌟 虹靈御所占星系統 - 更新版UI控制器
 * 整合精確占星引擎
 */

class UpdatedUIController {
    constructor() {
        this.preciseEngine = new PreciseAstroEngine();
        this.characterGenerator = null;
        this.currentChart = null;
        this.currentCharacter = null;
        this.isAutoMode = false;
        
        this.initializeElements();
        this.bindEvents();
        this.initializeEffects();
    }

    initializeElements() {
        // 模式切換按鈕
        this.manualModeBtn = document.getElementById('manualModeBtn');
        this.autoModeBtn = document.getElementById('autoModeBtn');
        
        // 輸入區域
        this.manualMode = document.getElementById('manualMode');
        this.autoMode = document.getElementById('autoMode');
        
        // 表單元素
        this.characterNameInput = document.getElementById('characterName');
        this.generateBtn = document.getElementById('generateBtn');
        
        // 星座選擇器
        this.signSelectors = {
            sun: document.getElementById('sun'),
            moon: document.getElementById('moon'),
            mercury: document.getElementById('mercury'),
            venus: document.getElementById('venus'),
            mars: document.getElementById('mars'),
            jupiter: document.getElementById('jupiter')
        };
        
        // 自動排盤輸入
        this.birthDateInput = document.getElementById('birthDate');
        this.birthTimeInput = document.getElementById('birthTime');
        this.birthLocationInput = document.getElementById('birthLocation');
        this.latitudeInput = document.getElementById('latitude');
        this.longitudeInput = document.getElementById('longitude');
        this.autoGenerateBtn = document.getElementById('autoGenerateBtn');
        
        // 結果顯示
        this.resultSection = document.getElementById('resultSection');
        this.characterCard = document.getElementById('characterCard');
        this.chartDetails = document.getElementById('chartDetails');
        
        // 操作按鈕
        this.exportBtn = document.getElementById('exportBtn');
        this.shareBtn = document.getElementById('shareBtn');
        this.regenerateBtn = document.getElementById('regenerateBtn');
    }

    bindEvents() {
        // 模式切換
        if (this.manualModeBtn) {
            this.manualModeBtn.addEventListener('click', () => this.switchToManualMode());
        }
        if (this.autoModeBtn) {
            this.autoModeBtn.addEventListener('click', () => this.switchToAutoMode());
        }
        
        // 生成按鈕
        if (this.generateBtn) {
            this.generateBtn.addEventListener('click', () => this.generateCharacterManual());
        }
        if (this.autoGenerateBtn) {
            this.autoGenerateBtn.addEventListener('click', () => this.generateCharacterAuto());
        }
        
        // 操作按鈕
        if (this.exportBtn) {
            this.exportBtn.addEventListener('click', () => this.exportDetailedReport());
        }
        if (this.shareBtn) {
            this.shareBtn.addEventListener('click', () => this.shareCharacter());
        }
        if (this.regenerateBtn) {
            this.regenerateBtn.addEventListener('click', () => this.regenerateCharacter());
        }
        
        // 地點輸入自動完成
        if (this.birthLocationInput) {
            this.birthLocationInput.addEventListener('input', () => this.handleLocationInput());
        }
    }

    initializeEffects() {
        // 初始化視覺效果
        if (typeof EnhancedEffects !== 'undefined') {
            this.effects = new EnhancedEffects();
        }
    }

    switchToManualMode() {
        this.isAutoMode = false;
        this.manualModeBtn?.classList.add('active');
        this.autoModeBtn?.classList.remove('active');
        
        if (this.manualMode) this.manualMode.style.display = 'block';
        if (this.autoMode) this.autoMode.style.display = 'none';
        
        this.showNotification('已切換到手動輸入模式', 'info');
    }

    switchToAutoMode() {
        this.isAutoMode = true;
        this.autoModeBtn?.classList.add('active');
        this.manualModeBtn?.classList.remove('active');
        
        if (this.manualMode) this.manualMode.style.display = 'none';
        if (this.autoMode) this.autoMode.style.display = 'block';
        
        this.showNotification('已切換到自動排盤模式', 'info');
    }

    async generateCharacterManual() {
        try {
            this.showLoading('正在生成角色...');
            
            // 驗證輸入
            const characterName = this.characterNameInput?.value?.trim();
            if (!characterName) {
                throw new Error('請輸入角色名稱');
            }
            
            // 收集星座選擇
            const selectedSigns = {};
            const requiredSigns = ['sun', 'moon', 'mercury', 'venus', 'mars', 'jupiter'];
            
            for (const planet of requiredSigns) {
                const selector = this.signSelectors[planet];
                if (!selector || selector.selectedIndex === 0) {
                    throw new Error(`請選擇${this.getPlanetName(planet)}星座`);
                }
                selectedSigns[planet] = {
                    signIndex: selector.selectedIndex - 1,
                    sign: selector.options[selector.selectedIndex].text.split(' ')[1]
                };
            }
            
            // 創建模擬星盤數據
            const mockChart = this.createMockChart(selectedSigns);
            this.currentChart = mockChart;
            
            // 生成角色
            await this.generateCharacterFromChart(characterName, mockChart);
            
        } catch (error) {
            this.showNotification(error.message, 'error');
            console.error('手動生成角色錯誤:', error);
        } finally {
            this.hideLoading();
        }
    }

    async generateCharacterAuto() {
        try {
            this.showLoading('正在計算星盤並生成角色...');
            
            // 驗證輸入
            const characterName = this.characterNameInput?.value?.trim();
            if (!characterName) {
                throw new Error('請輸入角色名稱');
            }
            
            const birthDate = this.birthDateInput?.value;
            const birthTime = this.birthTimeInput?.value;
            const latitude = parseFloat(this.latitudeInput?.value || 0);
            const longitude = parseFloat(this.longitudeInput?.value || 0);
            
            if (!birthDate || !birthTime) {
                throw new Error('請輸入完整的出生日期和時間');
            }
            
            if (latitude === 0 && longitude === 0) {
                throw new Error('請輸入出生地點的經緯度');
            }
            
            // 創建出生日期對象
            const birthDateTime = new Date(`${birthDate}T${birthTime}:00`);
            
            // 使用精確引擎計算星盤
            const chart = this.preciseEngine.calculateChart(birthDateTime, latitude, longitude);
            this.currentChart = chart;
            
            // 顯示星盤詳情
            this.displayChartDetails(chart);
            
            // 生成角色
            await this.generateCharacterFromChart(characterName, chart);
            
        } catch (error) {
            this.showNotification(error.message, 'error');
            console.error('自動生成角色錯誤:', error);
        } finally {
            this.hideLoading();
        }
    }

    createMockChart(selectedSigns) {
        // 為手動模式創建模擬星盤數據
        const mockChart = {
            planets: {},
            houses: [],
            angles: {},
            birthDate: new Date(),
            location: { latitude: 0, longitude: 0 }
        };
        
        // 創建行星數據
        for (const [planet, signData] of Object.entries(selectedSigns)) {
            const longitude = signData.signIndex * 30 + Math.random() * 30; // 隨機度數
            const signInfo = this.preciseEngine.longitudeToSign(longitude);
            
            mockChart.planets[planet] = {
                name: this.getPlanetName(planet),
                symbol: this.getPlanetSymbol(planet),
                longitude: longitude,
                sign: signInfo.sign,
                signIndex: signInfo.signIndex,
                degree: signInfo.degree,
                minutes: signInfo.minutes,
                seconds: signInfo.seconds,
                house: Math.floor(Math.random() * 12) + 1,
                retrograde: Math.random() < 0.2 // 20%機率逆行
            };
        }
        
        return mockChart;
    }

    async generateCharacterFromChart(characterName, chart) {
        // 初始化角色生成器
        if (!this.characterGenerator) {
            this.characterGenerator = new EnhancedCharacterGenerator();
        }
        
        // 生成角色
        const character = this.characterGenerator.generateFromChart(characterName, chart);
        this.currentCharacter = character;
        
        // 顯示結果
        this.displayCharacter(character);
        this.showResultSection();
        
        this.showNotification('角色生成成功！', 'success');
    }

    displayChartDetails(chart) {
        if (!this.chartDetails) return;
        
        let html = '<div class="chart-details">';
        html += '<h3>🌟 星盤詳情</h3>';
        
        // 顯示行星位置
        html += '<div class="planets-section">';
        html += '<h4>🪐 行星位置</h4>';
        for (const [key, planet] of Object.entries(chart.planets)) {
            const retrograde = planet.retrograde ? ' ℞' : '';
            html += `<div class="planet-item">`;
            html += `<span class="planet-symbol">${planet.symbol}</span>`;
            html += `<span class="planet-name">${planet.name}</span>`;
            html += `<span class="planet-position">${planet.sign} ${planet.degree}°${String(planet.minutes).padStart(2, '0')}'${retrograde}</span>`;
            html += `<span class="planet-house">${planet.house}宮</span>`;
            html += `</div>`;
        }
        html += '</div>';
        
        // 顯示重要點位
        html += '<div class="angles-section">';
        html += '<h4>📍 重要點位</h4>';
        for (const [key, angle] of Object.entries(chart.angles)) {
            html += `<div class="angle-item">`;
            html += `<span class="angle-symbol">${angle.symbol}</span>`;
            html += `<span class="angle-name">${angle.name}</span>`;
            html += `<span class="angle-position">${angle.sign} ${angle.degree}°${String(angle.minutes).padStart(2, '0')}'</span>`;
            html += `</div>`;
        }
        html += '</div>';
        
        html += '</div>';
        this.chartDetails.innerHTML = html;
    }

    displayCharacter(character) {
        if (!this.characterCard) return;
        
        let html = `
            <div class="character-header">
                <h2 class="character-name">${character.name}</h2>
                <div class="character-class">${character.profession.name}</div>
                <div class="character-rating">評級: ${character.rating}</div>
            </div>
            
            <div class="character-stats">
                <h3>屬性數值</h3>
                <div class="stats-grid">
        `;
        
        for (const [key, value] of Object.entries(character.attributes)) {
            html += `
                <div class="stat-item">
                    <div class="stat-name">${this.getAttributeName(key)}</div>
                    <div class="stat-value">${value}</div>
                </div>
            `;
        }
        
        html += `
                </div>
            </div>
            
            <div class="character-skills">
                <h3>技能專精</h3>
        `;
        
        for (const skill of character.skills) {
            html += `
                <div class="skill-item ${skill.type}">
                    <div class="skill-name">${skill.name}</div>
                    <div class="skill-type">${skill.type === 'primary' ? '主技能' : '副技能'}</div>
                    <div class="skill-description">${skill.description}</div>
                </div>
            `;
        }
        
        html += '</div>';
        this.characterCard.innerHTML = html;
    }

    showResultSection() {
        if (this.resultSection) {
            this.resultSection.style.display = 'block';
            this.resultSection.scrollIntoView({ behavior: 'smooth' });
        }
    }

    async exportDetailedReport() {
        if (!this.currentCharacter || !this.currentChart) {
            this.showNotification('請先生成角色', 'warning');
            return;
        }
        
        try {
            this.showLoading('正在生成詳細報告...');
            
            // 創建詳細報告
            const report = this.generateDetailedReport(this.currentCharacter, this.currentChart);
            
            // 創建並下載HTML文件
            const blob = new Blob([report], { type: 'text/html;charset=utf-8' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `${this.currentCharacter.name}_角色報告.html`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            
            this.showNotification('報告已下載', 'success');
            
        } catch (error) {
            this.showNotification('報告生成失敗', 'error');
            console.error('報告生成錯誤:', error);
        } finally {
            this.hideLoading();
        }
    }

    generateDetailedReport(character, chart) {
        return `
<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${character.name} - 角色詳細報告</title>
    <style>
        body {
            font-family: 'Microsoft JhengHei', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: #333;
            margin: 0;
            padding: 20px;
        }
        .report-container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
        }
        .header {
            text-align: center;
            margin-bottom: 40px;
            border-bottom: 3px solid #667eea;
            padding-bottom: 20px;
        }
        .character-name {
            font-size: 2.5rem;
            color: #667eea;
            margin-bottom: 10px;
        }
        .character-class {
            font-size: 1.5rem;
            color: #764ba2;
            margin-bottom: 10px;
        }
        .section {
            margin-bottom: 30px;
        }
        .section-title {
            font-size: 1.5rem;
            color: #667eea;
            border-left: 4px solid #667eea;
            padding-left: 15px;
            margin-bottom: 15px;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }
        .stat-item {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 10px;
            text-align: center;
            border: 2px solid #e9ecef;
        }
        .stat-name {
            font-weight: bold;
            color: #667eea;
            margin-bottom: 5px;
        }
        .stat-value {
            font-size: 1.5rem;
            color: #764ba2;
            font-weight: bold;
        }
        .skill-item {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 15px;
            border-left: 4px solid #667eea;
        }
        .skill-name {
            font-weight: bold;
            color: #667eea;
            margin-bottom: 5px;
        }
        .description {
            line-height: 1.6;
            color: #555;
        }
        .chart-section {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
        }
        .planet-item {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-bottom: 1px solid #e9ecef;
        }
        .footer {
            text-align: center;
            margin-top: 40px;
            padding-top: 20px;
            border-top: 2px solid #e9ecef;
            color: #888;
        }
    </style>
</head>
<body>
    <div class="report-container">
        <div class="header">
            <h1 class="character-name">${character.name}</h1>
            <div class="character-class">${character.profession.name}</div>
            <div>評級: ${character.rating}</div>
            <div>稀有度: ${character.rarity}</div>
        </div>

        <div class="section">
            <h2 class="section-title">屬性數值</h2>
            <div class="stats-grid">
                ${Object.entries(character.attributes).map(([key, value]) => `
                <div class="stat-item">
                    <div class="stat-name">${this.getAttributeName(key)}</div>
                    <div class="stat-value">${value}</div>
                </div>
                `).join('')}
            </div>
        </div>

        <div class="section">
            <h2 class="section-title">技能專精</h2>
            ${character.skills.map(skill => `
            <div class="skill-item">
                <div class="skill-name">${skill.name} (${skill.type === 'primary' ? '主技能' : '副技能'})</div>
                <div class="description">${skill.description}</div>
            </div>
            `).join('')}
        </div>

        <div class="section">
            <h2 class="section-title">職業介紹</h2>
            <div class="description">
                <h3>${character.profession.name}</h3>
                <p>${character.profession.description}</p>
                <h4>職業特色：</h4>
                <ul>
                    ${character.profession.features?.map(feature => `<li>${feature}</li>`).join('') || '<li>神秘而強大的存在</li>'}
                </ul>
            </div>
        </div>

        ${chart ? `
        <div class="section">
            <h2 class="section-title">星盤分析</h2>
            <div class="chart-section">
                <h3>行星位置</h3>
                ${Object.entries(chart.planets).map(([key, planet]) => `
                <div class="planet-item">
                    <span>${planet.symbol} ${planet.name}</span>
                    <span>${planet.sign} ${planet.degree}°${String(planet.minutes).padStart(2, '0')}'${planet.retrograde ? ' ℞' : ''}</span>
                    <span>${planet.house}宮</span>
                </div>
                `).join('')}
            </div>
        </div>
        ` : ''}

        <div class="footer">
            <p>由虹靈御所占星主角生成系統生成</p>
            <p>生成時間: ${new Date().toLocaleString('zh-TW')}</p>
        </div>
    </div>
</body>
</html>
        `;
    }

    handleLocationInput() {
        // 簡化的地點處理，實際應該連接地理編碼API
        const location = this.birthLocationInput?.value?.toLowerCase();
        
        // 預設一些常見城市的坐標
        const cityCoords = {
            '台北': { lat: 25.0330, lng: 121.5654 },
            '台中': { lat: 24.1477, lng: 120.6736 },
            '高雄': { lat: 22.6273, lng: 120.3014 },
            '台南': { lat: 22.9999, lng: 120.2269 },
            '新竹': { lat: 24.8138, lng: 120.9675 },
            '桃園': { lat: 24.9936, lng: 121.3010 }
        };
        
        for (const [city, coords] of Object.entries(cityCoords)) {
            if (location?.includes(city)) {
                if (this.latitudeInput) this.latitudeInput.value = coords.lat;
                if (this.longitudeInput) this.longitudeInput.value = coords.lng;
                break;
            }
        }
    }

    // 輔助方法
    getPlanetName(planet) {
        const names = {
            sun: '太陽', moon: '月亮', mercury: '水星',
            venus: '金星', mars: '火星', jupiter: '木星',
            saturn: '土星', uranus: '天王星', neptune: '海王星', pluto: '冥王星'
        };
        return names[planet] || planet;
    }

    getPlanetSymbol(planet) {
        const symbols = {
            sun: '☉', moon: '☽', mercury: '☿',
            venus: '♀', mars: '♂', jupiter: '♃',
            saturn: '♄', uranus: '♅', neptune: '♆', pluto: '♇'
        };
        return symbols[planet] || '●';
    }

    getAttributeName(attr) {
        const names = {
            charisma: '魅力', perception: '感知', intelligence: '智力',
            agility: '敏捷', strength: '力量', constitution: '體質',
            willpower: '意志力', intuition: '直覺'
        };
        return names[attr] || attr;
    }

    showLoading(message) {
        // 顯示加載動畫
        const loadingDiv = document.createElement('div');
        loadingDiv.id = 'loadingOverlay';
        loadingDiv.innerHTML = `
            <div class="loading-content">
                <div class="loading-spinner"></div>
                <div class="loading-text">${message}</div>
            </div>
        `;
        document.body.appendChild(loadingDiv);
    }

    hideLoading() {
        const loadingDiv = document.getElementById('loadingOverlay');
        if (loadingDiv) {
            loadingDiv.remove();
        }
    }

    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.remove();
        }, 3000);
    }

    shareCharacter() {
        if (!this.currentCharacter) {
            this.showNotification('請先生成角色', 'warning');
            return;
        }
        
        const shareText = `我在虹靈御所占星系統生成了角色：${this.currentCharacter.name}（${this.currentCharacter.profession.name}，評級${this.currentCharacter.rating}）`;
        
        if (navigator.share) {
            navigator.share({
                title: '虹靈御所占星角色',
                text: shareText,
                url: window.location.href
            });
        } else {
            navigator.clipboard.writeText(shareText).then(() => {
                this.showNotification('角色信息已複製到剪貼板', 'success');
            });
        }
    }

    regenerateCharacter() {
        if (this.isAutoMode) {
            this.generateCharacterAuto();
        } else {
            this.generateCharacterManual();
        }
    }
}

// 初始化控制器
document.addEventListener('DOMContentLoaded', () => {
    window.uiController = new UpdatedUIController();
});


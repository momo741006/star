// 增強占星系統 - 10大行星 + 12宮位
class EnhancedAstroSystem {
    constructor() {
        this.planets = {
            sun: { name: '太陽', symbol: '☀️', description: '外顯個性' },
            moon: { name: '月亮', symbol: '🌙', description: '內在情感' },
            mercury: { name: '水星', symbol: '☿', description: '思維溝通' },
            venus: { name: '金星', symbol: '♀', description: '愛情美感' },
            mars: { name: '火星', symbol: '♂', description: '行動力量' },
            jupiter: { name: '木星', symbol: '♃', description: '幸運擴展' },
            saturn: { name: '土星', symbol: '♄', description: '責任限制' },
            uranus: { name: '天王星', symbol: '♅', description: '創新變革' },
            neptune: { name: '海王星', symbol: '♆', description: '夢想靈感' },
            pluto: { name: '冥王星', symbol: '♇', description: '轉化重生' }
        };

        this.signs = {
            aries: { name: '牡羊座', symbol: '♈', element: 'fire', quality: 'cardinal' },
            taurus: { name: '金牛座', symbol: '♉', element: 'earth', quality: 'fixed' },
            gemini: { name: '雙子座', symbol: '♊', element: 'air', quality: 'mutable' },
            cancer: { name: '巨蟹座', symbol: '♋', element: 'water', quality: 'cardinal' },
            leo: { name: '獅子座', symbol: '♌', element: 'fire', quality: 'fixed' },
            virgo: { name: '處女座', symbol: '♍', element: 'earth', quality: 'mutable' },
            libra: { name: '天秤座', symbol: '♎', element: 'air', quality: 'cardinal' },
            scorpio: { name: '天蠍座', symbol: '♏', element: 'water', quality: 'fixed' },
            sagittarius: { name: '射手座', symbol: '♐', element: 'fire', quality: 'mutable' },
            capricorn: { name: '摩羯座', symbol: '♑', element: 'earth', quality: 'cardinal' },
            aquarius: { name: '水瓶座', symbol: '♒', element: 'air', quality: 'fixed' },
            pisces: { name: '雙魚座', symbol: '♓', element: 'water', quality: 'mutable' }
        };

        this.houses = {
            1: { name: '第一宮', description: '自我形象', theme: '個性外貌' },
            2: { name: '第二宮', description: '金錢價值', theme: '財富資源' },
            3: { name: '第三宮', description: '溝通學習', theme: '兄弟姊妹' },
            4: { name: '第四宮', description: '家庭根基', theme: '家族傳統' },
            5: { name: '第五宮', description: '創造娛樂', theme: '戀愛子女' },
            6: { name: '第六宮', description: '工作健康', theme: '日常服務' },
            7: { name: '第七宮', description: '伙伴關係', theme: '婚姻合作' },
            8: { name: '第八宮', description: '轉化重生', theme: '神秘資源' },
            9: { name: '第九宮', description: '哲學信仰', theme: '高等教育' },
            10: { name: '第十宮', description: '事業聲望', theme: '社會地位' },
            11: { name: '第十一宮', description: '友誼願望', theme: '團體理想' },
            12: { name: '第十二宮', description: '潛意識', theme: '靈性犧牲' }
        };

        this.planetAttributes = {
            sun: { strength: 3, intelligence: 2, agility: 1, wisdom: 2, charisma: 3, constitution: 2 },
            moon: { strength: 1, intelligence: 2, agility: 2, wisdom: 3, charisma: 2, constitution: 3 },
            mercury: { strength: 1, intelligence: 3, agility: 3, wisdom: 2, charisma: 2, constitution: 1 },
            venus: { strength: 1, intelligence: 2, agility: 2, wisdom: 2, charisma: 3, constitution: 2 },
            mars: { strength: 3, intelligence: 1, agility: 3, wisdom: 1, charisma: 2, constitution: 3 },
            jupiter: { strength: 2, intelligence: 3, agility: 1, wisdom: 3, charisma: 3, constitution: 2 },
            saturn: { strength: 2, intelligence: 2, agility: 1, wisdom: 3, charisma: 1, constitution: 3 },
            uranus: { strength: 2, intelligence: 3, agility: 3, wisdom: 2, charisma: 2, constitution: 1 },
            neptune: { strength: 1, intelligence: 2, agility: 2, wisdom: 3, charisma: 3, constitution: 2 },
            pluto: { strength: 3, intelligence: 2, agility: 2, wisdom: 3, charisma: 2, constitution: 3 }
        };
    }

    // 計算行星在星座的影響
    calculatePlanetaryInfluence(planetKey, signKey) {
        const planet = this.planets[planetKey];
        const sign = this.signs[signKey];
        const baseAttributes = this.planetAttributes[planetKey];
        
        // 根據星座元素調整屬性
        let modifier = 1.0;
        switch(sign.element) {
            case 'fire': 
                modifier = planetKey === 'mars' || planetKey === 'sun' ? 1.2 : 1.0;
                break;
            case 'earth': 
                modifier = planetKey === 'saturn' || planetKey === 'venus' ? 1.2 : 1.0;
                break;
            case 'air': 
                modifier = planetKey === 'mercury' || planetKey === 'uranus' ? 1.2 : 1.0;
                break;
            case 'water': 
                modifier = planetKey === 'moon' || planetKey === 'neptune' || planetKey === 'pluto' ? 1.2 : 1.0;
                break;
        }

        // 應用修正係數
        const adjustedAttributes = {};
        for (let attr in baseAttributes) {
            adjustedAttributes[attr] = Math.round(baseAttributes[attr] * modifier);
        }

        return {
            planet: planet.name,
            sign: sign.name,
            attributes: adjustedAttributes,
            influence: modifier > 1.0 ? 'strong' : 'normal'
        };
    }

    // 計算宮位影響
    calculateHouseInfluence(planetKey, houseNumber) {
        const planet = this.planets[planetKey];
        const house = this.houses[houseNumber];
        
        // 特殊宮位影響
        const houseModifiers = {
            1: { charisma: 1.2, strength: 1.1 }, // 第一宮強化個人魅力
            2: { constitution: 1.2, wisdom: 1.1 }, // 第二宮強化體質和智慧
            3: { intelligence: 1.2, agility: 1.1 }, // 第三宮強化智力和敏捷
            4: { wisdom: 1.2, constitution: 1.1 }, // 第四宮強化智慧和體質
            5: { charisma: 1.3, strength: 1.1 }, // 第五宮強化魅力
            6: { constitution: 1.3, agility: 1.1 }, // 第六宮強化體質
            7: { charisma: 1.2, wisdom: 1.1 }, // 第七宮強化魅力和智慧
            8: { strength: 1.2, wisdom: 1.2 }, // 第八宮強化力量和智慧
            9: { wisdom: 1.3, intelligence: 1.1 }, // 第九宮強化智慧
            10: { charisma: 1.2, strength: 1.2 }, // 第十宮強化魅力和力量
            11: { charisma: 1.2, agility: 1.1 }, // 第十一宮強化魅力
            12: { wisdom: 1.2, intelligence: 1.1 } // 第十二宮強化智慧
        };

        return {
            planet: planet.name,
            house: house.name,
            theme: house.theme,
            modifiers: houseModifiers[houseNumber] || {}
        };
    }

    // 生成完整的角色配置
    generateCharacterFromChart(chartData) {
        console.log('[EnhancedAstroSystem] 開始生成角色，輸入數據：', chartData);
        
        let totalAttributes = {
            strength: 8,
            intelligence: 8,
            agility: 8,
            wisdom: 8,
            charisma: 8,
            constitution: 8
        };

        let influences = [];
        let planetaryPowers = [];

        // 處理所有行星
        for (let planetKey in chartData.planets) {
            const signKey = chartData.planets[planetKey];
            if (signKey && signKey !== 'none') {
                const influence = this.calculatePlanetaryInfluence(planetKey, signKey);
                influences.push(influence);
                
                // 累加屬性
                for (let attr in influence.attributes) {
                    totalAttributes[attr] += influence.attributes[attr];
                }

                // 記錄行星力量
                planetaryPowers.push({
                    planet: influence.planet,
                    sign: influence.sign,
                    power: influence.influence === 'strong' ? '強勢' : '正常'
                });
            }
        }

        // 處理宮位影響（簡化版，使用太陽星座決定主要宮位）
        if (chartData.planets.sun) {
            const sunHouse = this.getSunHouse(chartData.planets.sun);
            const houseInfluence = this.calculateHouseInfluence('sun', sunHouse);
            
            // 應用宮位修正
            for (let attr in houseInfluence.modifiers) {
                totalAttributes[attr] = Math.round(totalAttributes[attr] * houseInfluence.modifiers[attr]);
            }
        }

        // 確保屬性在合理範圍內
        for (let attr in totalAttributes) {
            totalAttributes[attr] = Math.max(8, Math.min(20, totalAttributes[attr]));
        }

        // 計算總分和評級
        const totalScore = Object.values(totalAttributes).reduce((sum, val) => sum + val, 0);
        const averageScore = totalScore / 6;
        
        let grade = 'D';
        if (averageScore >= 18) grade = 'SS';
        else if (averageScore >= 16) grade = 'S';
        else if (averageScore >= 14) grade = 'A';
        else if (averageScore >= 12) grade = 'B';
        else if (averageScore >= 10) grade = 'C';

        // 決定職業
        const profession = this.determineProfession(totalAttributes, influences);

        console.log('[EnhancedAstroSystem] 角色生成完成：', {
            attributes: totalAttributes,
            grade: grade,
            profession: profession.name
        });

        return {
            attributes: totalAttributes,
            grade: grade,
            profession: profession,
            planetaryPowers: planetaryPowers,
            influences: influences,
            totalScore: totalScore,
            specialAbilities: this.generateSpecialAbilities(influences)
        };
    }

    // 根據太陽星座決定主要宮位
    getSunHouse(sunSign) {
        const houseMapping = {
            aries: 1, taurus: 2, gemini: 3, cancer: 4,
            leo: 5, virgo: 6, libra: 7, scorpio: 8,
            sagittarius: 9, capricorn: 10, aquarius: 11, pisces: 12
        };
        return houseMapping[sunSign] || 1;
    }

    // 決定職業
    determineProfession(attributes, influences) {
        const professions = [
            {
                name: '星辰戰士',
                requirements: { strength: 14, constitution: 12 },
                description: '以星辰之力戰鬥的勇士，擁有強大的物理戰鬥能力',
                skills: ['星辰劍術', '護盾防禦', '戰鬥直覺', '領導統御']
            },
            {
                name: '宇宙法師',
                requirements: { intelligence: 14, wisdom: 12 },
                description: '操控宇宙能量的魔法師，精通各種神秘法術',
                skills: ['星象魔法', '元素操控', '預言術', '魔法研究']
            },
            {
                name: '星影遊俠',
                requirements: { agility: 14, wisdom: 12 },
                description: '穿梭於星影之間的敏捷戰士，擅長遠程攻擊和潛行',
                skills: ['精準射擊', '隱身術', '野外生存', '追蹤技巧']
            },
            {
                name: '聖光牧師',
                requirements: { wisdom: 14, charisma: 12 },
                description: '傳播聖光的神職人員，擁有治療和祝福的能力',
                skills: ['神聖治療', '祝福術', '驅邪', '靈性指導']
            },
            {
                name: '星空吟遊詩人',
                requirements: { charisma: 14, intelligence: 12 },
                description: '用音樂和故事傳播星空智慧的藝術家',
                skills: ['魅惑歌聲', '激勵盟友', '古老傳說', '社交魅力']
            },
            {
                name: '暗影刺客',
                requirements: { agility: 14, intelligence: 12 },
                description: '隱藏在暗影中的致命殺手，擅長暗殺和潛行',
                skills: ['暗殺技巧', '毒藥製作', '鎖定技術', '隱匿行動']
            }
        ];

        // 找到符合條件的職業
        for (let profession of professions) {
            let qualified = true;
            for (let attr in profession.requirements) {
                if (attributes[attr] < profession.requirements[attr]) {
                    qualified = false;
                    break;
                }
            }
            if (qualified) {
                return profession;
            }
        }

        // 如果沒有符合條件的，返回基礎職業
        return {
            name: '星空學徒',
            description: '剛踏入星空世界的新手冒險者，潛力無限',
            skills: ['基礎戰鬥', '基礎魔法', '學習能力', '適應力']
        };
    }

    // 生成特殊能力
    generateSpecialAbilities(influences) {
        const abilities = [];
        
        influences.forEach(influence => {
            if (influence.influence === 'strong') {
                abilities.push(`${influence.planet}在${influence.sign}的強勢影響`);
            }
        });

        return abilities.length > 0 ? abilities : ['星空親和力'];
    }
}

// 全局實例
window.enhancedAstroSystem = new EnhancedAstroSystem();
console.log('[EnhancedAstroSystem] 增強占星系統已初始化');


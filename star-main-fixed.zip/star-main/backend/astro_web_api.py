#!/usr/bin/env python3
"""
虹靈御所占星系統 Web API
整合專業占星諮詢師和D&D角色生成功能
"""

from flask import Flask, request, jsonify, render_template_string
from flask_cors import CORS
import json
import traceback
from astro_consultant import ProfessionalAstrologer
from dnd_character_generator import DnDCharacterGenerator

app = Flask(__name__)
CORS(app)  # 允許跨域請求

# 初始化占星師和角色生成器
astrologer = ProfessionalAstrologer()
dnd_generator = DnDCharacterGenerator()

@app.route('/')
def home():
    """API 首頁，顯示文檔"""
    return render_template_string("""
<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>虹靈御所占星系統 API</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; background: #1a1a2e; color: #eee; }
        .container { max-width: 800px; margin: 0 auto; }
        h1 { color: #ffd700; text-align: center; }
        .endpoint { background: #16213e; padding: 20px; margin: 20px 0; border-radius: 8px; }
        .method { color: #4CAF50; font-weight: bold; }
        .url { color: #2196F3; font-family: monospace; }
        .description { margin: 10px 0; }
        .example { background: #0f3460; padding: 10px; border-radius: 4px; margin: 10px 0; }
        pre { overflow-x: auto; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🌟 虹靈御所占星系統 API</h1>
        
        <div class="endpoint">
            <h3><span class="method">POST</span> <span class="url">/api/calculate_chart</span></h3>
            <div class="description">計算完整星盤並生成D&D角色</div>
        </div>
        
        <div class="endpoint">
            <h3><span class="method">GET</span> <span class="url">/api/health</span></h3>
            <div class="description">檢查API健康狀態</div>
        </div>
        
        <div class="endpoint">
            <h3><span class="method">GET</span> <span class="url">/api/test</span></h3>
            <div class="description">測試API功能</div>
        </div>
        
        <p style="text-align: center; margin-top: 40px; color: #888;">
            Powered by Kerykeion & Professional Astrology
        </p>
    </div>
</body>
</html>
    """)


@app.route('/api/health', methods=['GET'])
def health_check():
    """健康檢查"""
    return jsonify({
        'status': 'healthy',
        'message': '虹靈御所占星系統運行正常',
        'version': '1.0.0'
    })

@app.route('/api/calculate_chart', methods=['POST'])
def calculate_chart():
    """計算星盤並生成D&D角色"""
    try:
        data = request.get_json()
        
        # 驗證必要參數
        required_fields = ['name', 'year', 'month', 'day', 'hour', 'minute', 
                          'city', 'longitude', 'latitude', 'timezone']
        
        for field in required_fields:
            if field not in data:
                return jsonify({
                    'success': False,
                    'error': f'缺少必要參數: {field}'
                }), 400
        
        # 計算星盤
        chart_data = astrologer.calculate_natal_chart(
            name=data['name'],
            year=int(data['year']),
            month=int(data['month']),
            day=int(data['day']),
            hour=int(data['hour']),
            minute=int(data['minute']),
            city=data['city'],
            longitude=float(data['longitude']),
            latitude=float(data['latitude']),
            timezone=data['timezone']
        )
        
        # 心理分析
        psychology = astrologer.analyze_chart_psychology(chart_data)
        
        # 生成D&D角色
        dnd_character = dnd_generator.generate_complete_character(chart_data)
        
        # 移除不能序列化的對象
        if 'chart_object' in chart_data:
            del chart_data['chart_object']
        
        return jsonify({
            'success': True,
            'data': {
                'birth_chart': chart_data,
                'psychological_analysis': psychology,
                'dnd_character': dnd_character
            }
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e),
            'traceback': traceback.format_exc()
        }), 500

@app.route('/api/generate_character', methods=['POST'])
def generate_character_only():
    """僅生成D&D角色"""
    try:
        data = request.get_json()
        
        if 'chart_data' not in data:
            return jsonify({
                'success': False,
                'error': '需要提供星盤數據'
            }), 400
        
        chart_data = data['chart_data']
        dnd_character = dnd_generator.generate_complete_character(chart_data)
        
        return jsonify({
            'success': True,
            'data': {
                'dnd_character': dnd_character
            }
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/test', methods=['GET'])
def test_api():
    """測試API功能"""
    try:
        # 使用測試數據
        test_data = {
            'name': '測試冒險者',
            'year': 1989,
            'month': 9,
            'day': 23,
            'hour': 12,
            'minute': 30,
            'city': '台北',
            'longitude': 121.5654,
            'latitude': 25.033,
            'timezone': 'Asia/Taipei'
        }
        
        # 計算星盤
        chart_data = astrologer.calculate_natal_chart(**test_data)
        
        # 生成角色
        dnd_character = dnd_generator.generate_complete_character(chart_data)
        
        # 移除不能序列化的對象
        if 'chart_object' in chart_data:
            del chart_data['chart_object']
        
        return jsonify({
            'success': True,
            'message': 'API測試成功',
            'test_result': {
                'character_name': dnd_character['name'],
                'dnd_class': dnd_character['class']['name'],
                'rating': dnd_character['rating'],
                'total_stats': dnd_character['total_stats']
            }
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e),
            'traceback': traceback.format_exc()
        }), 500
if __name__ == '__main__':
    import os
    port = int(os.environ.get('PORT', 5000))
    print(f"🌟 啟動虹靈御所占星系統 API...")
    print(f"🚀 端口: {port}")
    app.run(host='0.0.0.0', port=port, debug=False)
    
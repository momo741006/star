/**
 * 🌟 虹靈御所占星主角生成系統 - 增強視覺效果控制器
 * 提供豐富的視覺效果和互動體驗
 */

class EnhancedEffectsController {
    constructor() {
        this.particleSystem = null;
        this.audioContext = null;
        this.soundEffects = {};
        this.isInitialized = false;
        
        this.initializeEffects();
    }

    /**
     * 初始化所有效果
     */
    async initializeEffects() {
        try {
            this.initializeParticleSystem();
            this.initializeInteractiveEffects();
            this.initializeAudioSystem();
            this.initializeScrollEffects();
            this.isInitialized = true;
            console.log('增強視覺效果系統初始化完成');
        } catch (error) {
            console.error('視覺效果初始化失敗:', error);
        }
    }

    /**
     * 初始化粒子系統
     */
    initializeParticleSystem() {
        // 創建動態星塵效果
        this.createFloatingStardust();
        
        // 創建魔法光環效果
        this.createMagicalAuras();
        
        // 創建能量波紋效果
        this.createEnergyRipples();
    }

    /**
     * 創建浮動星塵效果
     */
    createFloatingStardust() {
        const stardustContainer = document.createElement('div');
        stardustContainer.className = 'floating-stardust';
        stardustContainer.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: 3;
        `;
        
        // 創建多個星塵粒子
        for (let i = 0; i < 50; i++) {
            const particle = document.createElement('div');
            particle.className = 'stardust-particle';
            particle.style.cssText = `
                position: absolute;
                width: ${Math.random() * 4 + 2}px;
                height: ${Math.random() * 4 + 2}px;
                background: radial-gradient(circle, #ffd700, transparent);
                border-radius: 50%;
                left: ${Math.random() * 100}%;
                top: ${Math.random() * 100}%;
                opacity: ${Math.random() * 0.8 + 0.2};
                animation: stardustFloat ${Math.random() * 10 + 15}s linear infinite;
                animation-delay: ${Math.random() * 5}s;
            `;
            stardustContainer.appendChild(particle);
        }
        
        document.body.appendChild(stardustContainer);
        
        // 添加星塵動畫CSS
        this.addStardustCSS();
    }

    /**
     * 添加星塵動畫CSS
     */
    addStardustCSS() {
        const style = document.createElement('style');
        style.textContent = `
            @keyframes stardustFloat {
                0% {
                    transform: translateY(100vh) translateX(0px) rotate(0deg);
                    opacity: 0;
                }
                10% {
                    opacity: 1;
                }
                90% {
                    opacity: 1;
                }
                100% {
                    transform: translateY(-100px) translateX(${Math.random() * 200 - 100}px) rotate(360deg);
                    opacity: 0;
                }
            }
            
            .stardust-particle:hover {
                transform: scale(2);
                transition: transform 0.3s ease;
            }
        `;
        document.head.appendChild(style);
    }

    /**
     * 創建魔法光環效果
     */
    createMagicalAuras() {
        const auraContainer = document.createElement('div');
        auraContainer.className = 'magical-auras';
        auraContainer.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: 1;
        `;
        
        // 創建多個光環
        for (let i = 0; i < 3; i++) {
            const aura = document.createElement('div');
            aura.className = 'magical-aura';
            aura.style.cssText = `
                position: absolute;
                width: ${300 + i * 100}px;
                height: ${300 + i * 100}px;
                border: 2px solid rgba(255, 215, 0, ${0.3 - i * 0.1});
                border-radius: 50%;
                left: 50%;
                top: 50%;
                transform: translate(-50%, -50%);
                animation: auraRotate ${20 + i * 10}s linear infinite;
                animation-direction: ${i % 2 === 0 ? 'normal' : 'reverse'};
            `;
            auraContainer.appendChild(aura);
        }
        
        document.body.appendChild(auraContainer);
        
        // 添加光環動畫CSS
        this.addAuraCSS();
    }

    /**
     * 添加光環動畫CSS
     */
    addAuraCSS() {
        const style = document.createElement('style');
        style.textContent = `
            @keyframes auraRotate {
                from { transform: translate(-50%, -50%) rotate(0deg); }
                to { transform: translate(-50%, -50%) rotate(360deg); }
            }
            
            .magical-aura {
                box-shadow: 
                    0 0 20px rgba(255, 215, 0, 0.3),
                    inset 0 0 20px rgba(255, 215, 0, 0.1);
            }
        `;
        document.head.appendChild(style);
    }

    /**
     * 創建能量波紋效果
     */
    createEnergyRipples() {
        document.addEventListener('click', (e) => {
            this.createRippleEffect(e.clientX, e.clientY);
        });
    }

    /**
     * 創建波紋效果
     * @param {number} x - X座標
     * @param {number} y - Y座標
     */
    createRippleEffect(x, y) {
        const ripple = document.createElement('div');
        ripple.className = 'energy-ripple';
        ripple.style.cssText = `
            position: fixed;
            left: ${x}px;
            top: ${y}px;
            width: 0;
            height: 0;
            border: 2px solid rgba(102, 126, 234, 0.6);
            border-radius: 50%;
            pointer-events: none;
            z-index: 1000;
            animation: rippleExpand 1s ease-out forwards;
        `;
        
        document.body.appendChild(ripple);
        
        // 1秒後移除波紋
        setTimeout(() => {
            if (ripple.parentNode) {
                ripple.parentNode.removeChild(ripple);
            }
        }, 1000);
        
        // 添加波紋動畫CSS（如果還沒有）
        if (!document.querySelector('#ripple-styles')) {
            this.addRippleCSS();
        }
    }

    /**
     * 添加波紋動畫CSS
     */
    addRippleCSS() {
        const style = document.createElement('style');
        style.id = 'ripple-styles';
        style.textContent = `
            @keyframes rippleExpand {
                to {
                    width: 200px;
                    height: 200px;
                    margin-left: -100px;
                    margin-top: -100px;
                    opacity: 0;
                }
            }
        `;
        document.head.appendChild(style);
    }

    /**
     * 初始化互動效果
     */
    initializeInteractiveEffects() {
        // 鼠標跟隨效果
        this.initializeMouseFollower();
        
        // 元素懸停效果
        this.initializeHoverEffects();
        
        // 按鈕點擊效果
        this.initializeButtonEffects();
    }

    /**
     * 初始化鼠標跟隨效果
     */
    initializeMouseFollower() {
        const follower = document.createElement('div');
        follower.className = 'mouse-follower';
        follower.style.cssText = `
            position: fixed;
            width: 20px;
            height: 20px;
            background: radial-gradient(circle, rgba(255, 215, 0, 0.8), transparent);
            border-radius: 50%;
            pointer-events: none;
            z-index: 9999;
            transition: transform 0.1s ease;
            mix-blend-mode: screen;
        `;
        
        document.body.appendChild(follower);
        
        document.addEventListener('mousemove', (e) => {
            follower.style.left = e.clientX - 10 + 'px';
            follower.style.top = e.clientY - 10 + 'px';
        });
    }

    /**
     * 初始化懸停效果
     */
    initializeHoverEffects() {
        // 為所有可互動元素添加懸停效果
        const interactiveElements = document.querySelectorAll('button, .mode-btn, .action-btn, .generate-btn, input, select');
        
        interactiveElements.forEach(element => {
            element.addEventListener('mouseenter', () => {
                this.addGlowEffect(element);
            });
            
            element.addEventListener('mouseleave', () => {
                this.removeGlowEffect(element);
            });
        });
    }

    /**
     * 添加發光效果
     * @param {HTMLElement} element - 目標元素
     */
    addGlowEffect(element) {
        element.style.boxShadow = '0 0 20px rgba(102, 126, 234, 0.6), 0 0 40px rgba(102, 126, 234, 0.4)';
        element.style.transform = 'translateY(-2px) scale(1.02)';
        element.style.transition = 'all 0.3s ease';
    }

    /**
     * 移除發光效果
     * @param {HTMLElement} element - 目標元素
     */
    removeGlowEffect(element) {
        element.style.boxShadow = '';
        element.style.transform = '';
    }

    /**
     * 初始化按鈕效果
     */
    initializeButtonEffects() {
        document.addEventListener('click', (e) => {
            if (e.target.matches('button, .btn, .mode-btn, .action-btn, .generate-btn')) {
                this.createButtonClickEffect(e.target);
            }
        });
    }

    /**
     * 創建按鈕點擊效果
     * @param {HTMLElement} button - 按鈕元素
     */
    createButtonClickEffect(button) {
        // 創建能量爆發效果
        const burst = document.createElement('div');
        burst.className = 'button-burst';
        burst.style.cssText = `
            position: absolute;
            top: 50%;
            left: 50%;
            width: 0;
            height: 0;
            background: radial-gradient(circle, rgba(255, 215, 0, 0.8), transparent);
            border-radius: 50%;
            pointer-events: none;
            z-index: 1000;
            animation: burstExpand 0.6s ease-out forwards;
        `;
        
        button.style.position = 'relative';
        button.appendChild(burst);
        
        // 0.6秒後移除效果
        setTimeout(() => {
            if (burst.parentNode) {
                burst.parentNode.removeChild(burst);
            }
        }, 600);
        
        // 添加爆發動畫CSS（如果還沒有）
        if (!document.querySelector('#burst-styles')) {
            this.addBurstCSS();
        }
    }

    /**
     * 添加爆發動畫CSS
     */
    addBurstCSS() {
        const style = document.createElement('style');
        style.id = 'burst-styles';
        style.textContent = `
            @keyframes burstExpand {
                to {
                    width: 100px;
                    height: 100px;
                    margin-left: -50px;
                    margin-top: -50px;
                    opacity: 0;
                }
            }
        `;
        document.head.appendChild(style);
    }

    /**
     * 初始化音頻系統
     */
    async initializeAudioSystem() {
        try {
            // 創建音頻上下文（需要用戶互動後才能啟用）
            document.addEventListener('click', () => {
                if (!this.audioContext) {
                    this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
                    this.createSoundEffects();
                }
            }, { once: true });
        } catch (error) {
            console.log('音頻系統不可用:', error);
        }
    }

    /**
     * 創建音效
     */
    createSoundEffects() {
        if (!this.audioContext) return;
        
        // 創建按鈕點擊音效
        this.soundEffects.click = this.createTone(800, 0.1, 'sine');
        
        // 創建懸停音效
        this.soundEffects.hover = this.createTone(600, 0.05, 'sine');
        
        // 創建生成完成音效
        this.soundEffects.complete = this.createChord([523, 659, 784], 0.3);
    }

    /**
     * 創建音調
     * @param {number} frequency - 頻率
     * @param {number} duration - 持續時間
     * @param {string} type - 波形類型
     * @returns {Function} 播放函數
     */
    createTone(frequency, duration, type = 'sine') {
        return () => {
            if (!this.audioContext) return;
            
            const oscillator = this.audioContext.createOscillator();
            const gainNode = this.audioContext.createGain();
            
            oscillator.connect(gainNode);
            gainNode.connect(this.audioContext.destination);
            
            oscillator.frequency.value = frequency;
            oscillator.type = type;
            
            gainNode.gain.setValueAtTime(0, this.audioContext.currentTime);
            gainNode.gain.linearRampToValueAtTime(0.1, this.audioContext.currentTime + 0.01);
            gainNode.gain.exponentialRampToValueAtTime(0.001, this.audioContext.currentTime + duration);
            
            oscillator.start(this.audioContext.currentTime);
            oscillator.stop(this.audioContext.currentTime + duration);
        };
    }

    /**
     * 創建和弦
     * @param {Array} frequencies - 頻率數組
     * @param {number} duration - 持續時間
     * @returns {Function} 播放函數
     */
    createChord(frequencies, duration) {
        return () => {
            frequencies.forEach(freq => {
                this.createTone(freq, duration)();
            });
        };
    }

    /**
     * 播放音效
     * @param {string} effectName - 音效名稱
     */
    playSound(effectName) {
        if (this.soundEffects[effectName]) {
            this.soundEffects[effectName]();
        }
    }

    /**
     * 初始化滾動效果
     */
    initializeScrollEffects() {
        // 視差滾動效果
        window.addEventListener('scroll', () => {
            const scrolled = window.pageYOffset;
            const parallax = document.querySelector('.cosmic-particles');
            
            if (parallax) {
                parallax.style.transform = `translateY(${scrolled * 0.5}px)`;
            }
        });
        
        // 滾動時的元素動畫
        this.initializeScrollAnimations();
    }

    /**
     * 初始化滾動動畫
     */
    initializeScrollAnimations() {
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('animate-in');
                }
            });
        }, observerOptions);
        
        // 觀察所有需要動畫的元素
        const animatedElements = document.querySelectorAll('.input-section, .result-section, .character-card');
        animatedElements.forEach(el => observer.observe(el));
        
        // 添加滾動動畫CSS
        this.addScrollAnimationCSS();
    }

    /**
     * 添加滾動動畫CSS
     */
    addScrollAnimationCSS() {
        const style = document.createElement('style');
        style.textContent = `
            .input-section, .result-section, .character-card {
                opacity: 0;
                transform: translateY(50px);
                transition: all 0.8s ease;
            }
            
            .animate-in {
                opacity: 1 !important;
                transform: translateY(0) !important;
            }
        `;
        document.head.appendChild(style);
    }

    /**
     * 創建慶祝效果
     */
    createCelebrationEffect() {
        // 創建彩帶效果
        this.createConfetti();
        
        // 播放慶祝音效
        this.playSound('complete');
        
        // 創建光芒四射效果
        this.createRadialBurst();
    }

    /**
     * 創建彩帶效果
     */
    createConfetti() {
        const colors = ['#ff6b6b', '#4ecdc4', '#45b7d1', '#feca57', '#ff9ff3', '#54a0ff'];
        
        for (let i = 0; i < 50; i++) {
            const confetti = document.createElement('div');
            confetti.style.cssText = `
                position: fixed;
                width: 10px;
                height: 10px;
                background: ${colors[Math.floor(Math.random() * colors.length)]};
                left: ${Math.random() * 100}%;
                top: -10px;
                z-index: 1000;
                pointer-events: none;
                animation: confettiFall ${Math.random() * 3 + 2}s linear forwards;
                animation-delay: ${Math.random() * 2}s;
            `;
            
            document.body.appendChild(confetti);
            
            // 3秒後移除
            setTimeout(() => {
                if (confetti.parentNode) {
                    confetti.parentNode.removeChild(confetti);
                }
            }, 5000);
        }
        
        // 添加彩帶動畫CSS（如果還沒有）
        if (!document.querySelector('#confetti-styles')) {
            this.addConfettiCSS();
        }
    }

    /**
     * 添加彩帶動畫CSS
     */
    addConfettiCSS() {
        const style = document.createElement('style');
        style.id = 'confetti-styles';
        style.textContent = `
            @keyframes confettiFall {
                to {
                    transform: translateY(100vh) rotate(720deg);
                    opacity: 0;
                }
            }
        `;
        document.head.appendChild(style);
    }

    /**
     * 創建光芒四射效果
     */
    createRadialBurst() {
        const burst = document.createElement('div');
        burst.style.cssText = `
            position: fixed;
            top: 50%;
            left: 50%;
            width: 0;
            height: 0;
            background: radial-gradient(circle, rgba(255, 215, 0, 0.8), transparent);
            border-radius: 50%;
            pointer-events: none;
            z-index: 1000;
            animation: radialBurst 2s ease-out forwards;
        `;
        
        document.body.appendChild(burst);
        
        setTimeout(() => {
            if (burst.parentNode) {
                burst.parentNode.removeChild(burst);
            }
        }, 2000);
        
        // 添加光芒動畫CSS（如果還沒有）
        if (!document.querySelector('#radial-burst-styles')) {
            this.addRadialBurstCSS();
        }
    }

    /**
     * 添加光芒動畫CSS
     */
    addRadialBurstCSS() {
        const style = document.createElement('style');
        style.id = 'radial-burst-styles';
        style.textContent = `
            @keyframes radialBurst {
                0% {
                    width: 0;
                    height: 0;
                    margin-left: 0;
                    margin-top: 0;
                    opacity: 1;
                }
                50% {
                    width: 400px;
                    height: 400px;
                    margin-left: -200px;
                    margin-top: -200px;
                    opacity: 0.8;
                }
                100% {
                    width: 800px;
                    height: 800px;
                    margin-left: -400px;
                    margin-top: -400px;
                    opacity: 0;
                }
            }
        `;
        document.head.appendChild(style);
    }

    /**
     * 銷毀效果系統
     */
    destroy() {
        // 清理音頻上下文
        if (this.audioContext) {
            this.audioContext.close();
        }
        
        // 移除所有動態創建的元素
        const dynamicElements = document.querySelectorAll('.floating-stardust, .magical-auras, .mouse-follower');
        dynamicElements.forEach(el => {
            if (el.parentNode) {
                el.parentNode.removeChild(el);
            }
        });
        
        this.isInitialized = false;
    }
}

// 全局效果控制器實例
window.enhancedEffects = new EnhancedEffectsController();


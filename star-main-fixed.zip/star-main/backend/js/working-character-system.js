// 虹靈御所占星主角生成系統 - 完整工作版本
class WorkingCharacterSystem {
    constructor() {
        this.planets = [
            { id: 'sunSign', name: '太陽', symbol: '☀️', description: '外顯個性' },
            { id: 'moonSign', name: '月亮', symbol: '🌙', description: '內在情感' },
            { id: 'mercurySign', name: '水星', symbol: '☿', description: '思維溝通' },
            { id: 'venusSign', name: '金星', symbol: '♀', description: '愛情美感' },
            { id: 'marsSign', name: '火星', symbol: '♂', description: '行動力量' },
            { id: 'jupiterSign', name: '木星', symbol: '♃', description: '幸運擴展' },
            { id: 'saturnSign', name: '土星', symbol: '♄', description: '責任限制' },
            { id: 'uranusSign', name: '天王星', symbol: '♅', description: '創新變革' },
            { id: 'neptuneSign', name: '海王星', symbol: '♆', description: '夢想靈感' },
            { id: 'plutoSign', name: '冥王星', symbol: '♇', description: '轉化重生' }
        ];

        this.signs = {
            'aries': { name: '牡羊座', symbol: '♈', element: 'fire', quality: 'cardinal' },
            'taurus': { name: '金牛座', symbol: '♉', element: 'earth', quality: 'fixed' },
            'gemini': { name: '雙子座', symbol: '♊', element: 'air', quality: 'mutable' },
            'cancer': { name: '巨蟹座', symbol: '♋', element: 'water', quality: 'cardinal' },
            'leo': { name: '獅子座', symbol: '♌', element: 'fire', quality: 'fixed' },
            'virgo': { name: '處女座', symbol: '♍', element: 'earth', quality: 'mutable' },
            'libra': { name: '天秤座', symbol: '♎', element: 'air', quality: 'cardinal' },
            'scorpio': { name: '天蠍座', symbol: '♏', element: 'water', quality: 'fixed' },
            'sagittarius': { name: '射手座', symbol: '♐', element: 'fire', quality: 'mutable' },
            'capricorn': { name: '摩羯座', symbol: '♑', element: 'earth', quality: 'cardinal' },
            'aquarius': { name: '水瓶座', symbol: '♒', element: 'air', quality: 'fixed' },
            'pisces': { name: '雙魚座', symbol: '♓', element: 'water', quality: 'mutable' }
        };

        this.classes = [
            { 
                name: '戰士', 
                englishName: 'Warrior',
                description: '勇敢的近戰戰鬥專家',
                primaryStat: 'strength',
                skills: ['劍術精通', '盾牌防禦', '戰鬥怒吼', '堅韌意志']
            },
            { 
                name: '法師', 
                englishName: 'Mage',
                description: '掌握奧秘魔法的智者',
                primaryStat: 'intelligence',
                skills: ['元素魔法', '奧術知識', '法術護盾', '魔力恢復']
            },
            { 
                name: '盜賊', 
                englishName: 'Rogue',
                description: '敏捷的暗影行者',
                primaryStat: 'dexterity',
                skills: ['潛行術', '開鎖技巧', '毒刃攻擊', '閃避技能']
            },
            { 
                name: '牧師', 
                englishName: 'Cleric',
                description: '神聖力量的傳播者',
                primaryStat: 'wisdom',
                skills: ['治療術', '神聖護盾', '驅邪術', '祝福儀式']
            },
            { 
                name: '遊俠', 
                englishName: 'Ranger',
                description: '自然的守護者',
                primaryStat: 'dexterity',
                skills: ['精準射擊', '野外生存', '動物溝通', '自然魔法']
            },
            { 
                name: '聖騎士', 
                englishName: 'Paladin',
                description: '正義與榮耀的化身',
                primaryStat: 'strength',
                skills: ['神聖打擊', '正義審判', '治療之光', '領導魅力']
            }
        ];

        this.grades = ['D', 'C', 'B', 'A', 'S', 'SS'];
        
        console.log('[WorkingCharacterSystem] 系統初始化完成');
    }

    // 收集星座數據
    collectPlanetData() {
        const planetData = {};
        let selectedCount = 0;

        this.planets.forEach(planet => {
            const element = document.getElementById(planet.id);
            if (element && element.value) {
                planetData[planet.id] = element.value;
                selectedCount++;
            }
        });

        console.log(`[WorkingCharacterSystem] 收集到 ${selectedCount}/10 個行星數據:`, planetData);
        return { data: planetData, count: selectedCount };
    }

    // 驗證輸入數據
    validateInput(characterName, planetData) {
        const errors = [];

        if (!characterName || characterName.trim().length === 0) {
            errors.push('請輸入角色名稱');
        }

        if (planetData.count < 10) {
            errors.push(`請選擇所有10個行星的星座 (目前已選擇 ${planetData.count}/10)`);
        }

        return errors;
    }

    // 計算屬性值
    calculateAttributes(planetData) {
        const attributes = {
            strength: 8,      // 基礎值降低，增加變化空間
            intelligence: 8,
            dexterity: 8,
            wisdom: 8,
            charisma: 8,
            constitution: 8
        };

        // 行星對屬性的特殊影響
        const planetInfluence = {
            sunSign: { strength: 3, charisma: 2 },        // 太陽：力量和魅力
            moonSign: { wisdom: 3, constitution: 1 },      // 月亮：智慧和體質
            mercurySign: { intelligence: 3, dexterity: 1 }, // 水星：智力和敏捷
            venusSign: { charisma: 3, wisdom: 1 },         // 金星：魅力和智慧
            marsSign: { strength: 3, dexterity: 2 },       // 火星：力量和敏捷
            jupiterSign: { wisdom: 2, charisma: 2, constitution: 1 }, // 木星：智慧、魅力、體質
            saturnSign: { constitution: 3, strength: 1 },   // 土星：體質和力量
            uranusSign: { intelligence: 2, dexterity: 2 },  // 天王星：智力和敏捷
            neptuneSign: { wisdom: 2, charisma: 2 },        // 海王星：智慧和魅力
            plutoSign: { strength: 2, constitution: 2 }     // 冥王星：力量和體質
        };

        // 根據行星星座計算屬性修正
        Object.entries(planetData.data).forEach(([planet, sign]) => {
            const signData = this.signs[sign];
            const planetBonus = planetInfluence[planet];
            
            if (!signData || !planetBonus) return;

            // 應用行星特定的屬性加成
            Object.entries(planetBonus).forEach(([attr, bonus]) => {
                attributes[attr] += bonus;
            });

            // 根據星座元素給予額外加成
            switch (signData.element) {
                case 'fire':
                    attributes.strength += Math.floor(Math.random() * 3) + 1; // 1-3
                    attributes.charisma += Math.floor(Math.random() * 2) + 1; // 1-2
                    break;
                case 'earth':
                    attributes.constitution += Math.floor(Math.random() * 3) + 1; // 1-3
                    attributes.strength += Math.floor(Math.random() * 2) + 1; // 1-2
                    break;
                case 'air':
                    attributes.intelligence += Math.floor(Math.random() * 3) + 1; // 1-3
                    attributes.dexterity += Math.floor(Math.random() * 2) + 1; // 1-2
                    break;
                case 'water':
                    attributes.wisdom += Math.floor(Math.random() * 3) + 1; // 1-3
                    attributes.charisma += Math.floor(Math.random() * 2) + 1; // 1-2
                    break;
            }

            // 根據星座性質給予額外加成
            switch (signData.quality) {
                case 'cardinal': // 開創
                    attributes.charisma += Math.floor(Math.random() * 2) + 1;
                    attributes.strength += Math.floor(Math.random() * 2);
                    break;
                case 'fixed': // 固定
                    attributes.constitution += Math.floor(Math.random() * 2) + 1;
                    attributes.wisdom += Math.floor(Math.random() * 2);
                    break;
                case 'mutable': // 變動
                    attributes.dexterity += Math.floor(Math.random() * 2) + 1;
                    attributes.intelligence += Math.floor(Math.random() * 2);
                    break;
            }
        });

        // 添加隨機變化，確保每次生成都不同
        Object.keys(attributes).forEach(attr => {
            const randomBonus = Math.floor(Math.random() * 8) - 3; // -3 到 +4 的隨機值
            attributes[attr] += randomBonus;
            
            // 限制在合理範圍內 (8-25)
            attributes[attr] = Math.max(8, Math.min(25, attributes[attr]));
        });

        console.log('[WorkingCharacterSystem] 計算後的屬性:', attributes);
        return attributes;
    }

    // 選擇職業
    selectClass(attributes) {
        // 找出最高的屬性
        const maxAttr = Object.entries(attributes).reduce((max, [attr, value]) => 
            value > max.value ? { attr, value } : max, { attr: '', value: 0 });

        // 根據最高屬性選擇職業
        let selectedClass;
        switch (maxAttr.attr) {
            case 'strength':
                selectedClass = Math.random() > 0.5 ? this.classes[0] : this.classes[5]; // 戰士或聖騎士
                break;
            case 'intelligence':
                selectedClass = this.classes[1]; // 法師
                break;
            case 'dexterity':
                selectedClass = Math.random() > 0.5 ? this.classes[2] : this.classes[4]; // 盜賊或遊俠
                break;
            case 'wisdom':
                selectedClass = this.classes[3]; // 牧師
                break;
            case 'charisma':
                selectedClass = this.classes[5]; // 聖騎士
                break;
            default:
                selectedClass = this.classes[Math.floor(Math.random() * this.classes.length)];
        }

        return selectedClass;
    }

    // 計算角色評級
    calculateGrade(attributes) {
        // 計算屬性總和
        const totalStats = Object.values(attributes).reduce((sum, value) => sum + value, 0);
        
        // 計算屬性平衡度（標準差）
        const average = totalStats / 6;
        const variance = Object.values(attributes).reduce((sum, value) => 
            sum + Math.pow(value - average, 2), 0) / 6;
        const standardDeviation = Math.sqrt(variance);
        
        // 平衡度獎勵（標準差越小，平衡度越好）
        const balanceBonus = Math.max(0, 5 - standardDeviation);
        
        // 最終評分 = 屬性總和 + 平衡度獎勵
        const finalScore = totalStats + balanceBonus;
        
        console.log(`[WorkingCharacterSystem] 評級計算: 總和=${totalStats}, 平衡度=${balanceBonus.toFixed(1)}, 最終=${finalScore.toFixed(1)}`);
        
        // 根據最終評分決定等級
        if (finalScore >= 140) return 'SS';
        if (finalScore >= 120) return 'S';
        if (finalScore >= 100) return 'A';
        if (finalScore >= 85) return 'B';
        if (finalScore >= 70) return 'C';
        return 'D';
    }

    // 生成角色
    generateCharacter(characterName) {
        console.log('[WorkingCharacterSystem] 開始生成角色:', characterName);

        // 收集數據
        const planetResult = this.collectPlanetData();
        
        // 驗證輸入
        const errors = this.validateInput(characterName, planetResult);
        if (errors.length > 0) {
            this.showError(errors);
            return null;
        }

        // 計算屬性
        const attributes = this.calculateAttributes(planetResult);
        
        // 選擇職業
        const characterClass = this.selectClass(attributes);
        
        // 計算評級
        const grade = this.calculateGrade(attributes);

        // 生成角色對象
        const character = {
            name: characterName.trim(),
            class: characterClass,
            attributes: attributes,
            grade: grade,
            planetData: planetResult, // 保存完整的星座數據
            createdAt: new Date().toLocaleString('zh-TW')
        };

        console.log('[WorkingCharacterSystem] 角色生成完成:', character);
        return character;
    }

    // 顯示錯誤
    showError(errors) {
        const errorMessage = errors.join('\\n');
        alert(`⚠️ 請修正以下問題：\\n\\n${errorMessage}`);
        console.error('[WorkingCharacterSystem] 驗證錯誤:', errors);
    }

    // 顯示角色結果
    displayCharacter(character) {
        if (!character) return;

        // 創建結果顯示區域
        let resultArea = document.getElementById('characterResult');
        if (!resultArea) {
            resultArea = document.createElement('div');
            resultArea.id = 'characterResult';
            resultArea.className = 'character-result';
            
            // 插入到生成按鈕後面
            const generateButton = document.querySelector('.generate-button');
            if (generateButton && generateButton.parentNode) {
                generateButton.parentNode.insertBefore(resultArea, generateButton.nextSibling);
            } else {
                document.body.appendChild(resultArea);
            }
        }

        // 生成HTML內容
        const html = `
            <div class="character-card">
                <div class="character-header">
                    <h2>🌟 ${character.name}</h2>
                    <div class="character-grade grade-${character.grade}">${character.grade}級</div>
                </div>
                
                <div class="character-info">
                    <div class="character-class">
                        <h3>職業：${character.class.name} (${character.class.englishName})</h3>
                        <p>${character.class.description}</p>
                    </div>
                    
                    <div class="character-attributes">
                        <h3>屬性</h3>
                        <div class="attributes-grid">
                            <div class="attribute">
                                <span class="attr-name">💪 力量</span>
                                <span class="attr-value">${character.attributes.strength}</span>
                            </div>
                            <div class="attribute">
                                <span class="attr-name">🧠 智力</span>
                                <span class="attr-value">${character.attributes.intelligence}</span>
                            </div>
                            <div class="attribute">
                                <span class="attr-name">🏃 敏捷</span>
                                <span class="attr-value">${character.attributes.dexterity}</span>
                            </div>
                            <div class="attribute">
                                <span class="attr-name">🧙 智慧</span>
                                <span class="attr-value">${character.attributes.wisdom}</span>
                            </div>
                            <div class="attribute">
                                <span class="attr-name">✨ 魅力</span>
                                <span class="attr-value">${character.attributes.charisma}</span>
                            </div>
                            <div class="attribute">
                                <span class="attr-name">❤️ 體質</span>
                                <span class="attr-value">${character.attributes.constitution}</span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="character-skills">
                        <h3>技能專精</h3>
                        <div class="skills-list">
                            ${character.class.skills.map(skill => `<span class="skill-tag">${skill}</span>`).join('')}
                        </div>
                    </div>
                    
                    <div class="character-planets">
                        <h3>星座配置</h3>
                        <div class="planets-summary">
                            ${this.planets.map(planet => {
                                const sign = character.planets[planet.id];
                                const signData = this.signs[sign];
                                return sign ? `<div class="planet-item">
                                    ${planet.symbol} ${planet.name}: ${signData.symbol} ${signData.name}
                                </div>` : '';
                            }).join('')}
                        </div>
                    </div>
                    
                    <div class="character-footer">
                        <p>生成時間：${character.createdAt}</p>
                    </div>
                </div>
            </div>
        `;

        resultArea.innerHTML = html;
        
        // 滾動到結果區域
        resultArea.scrollIntoView({ behavior: 'smooth', block: 'start' });
        
        console.log('[WorkingCharacterSystem] 角色顯示完成');
    }
}

// 全局實例
window.workingCharacterSystem = new WorkingCharacterSystem();


    // 從星盤生成角色
    generateCharacterFromChart(name, chart) {
        console.log('[WorkingCharacterSystem] 從星盤生成角色:', name, chart);

        try {
            // 轉換星盤數據為星座配置
            const signConfig = {};
            
            // 映射行星到對應的選擇器ID
            const planetMapping = {
                sun: 'sunSign',
                moon: 'moonSign', 
                mercury: 'mercurySign',
                venus: 'venusSign',
                mars: 'marsSign',
                jupiter: 'jupiterSign',
                saturn: 'saturnSign',
                uranus: 'uranusSign',
                neptune: 'neptuneSign',
                pluto: 'plutoSign'
            };

            // 轉換星盤數據
            Object.entries(chart.planets).forEach(([planet, data]) => {
                const selectorId = planetMapping[planet];
                if (selectorId) {
                    signConfig[selectorId] = data.sign;
                }
            });

            console.log('[WorkingCharacterSystem] 星座配置:', signConfig);

            // 使用現有的角色生成邏輯
            const character = this.generateCharacter(name, signConfig);

            // 添加星盤特有信息
            if (character) {
                character.isAutoGenerated = true;
                character.chart = chart;
                
                // 添加逆行行星影響
                const retrogradePlanets = Object.entries(chart.planets)
                    .filter(([planet, data]) => data.isRetrograde)
                    .map(([planet, data]) => ({ planet, data }));

                if (retrogradePlanets.length > 0) {
                    character.retrogradeEffects = this.calculateRetrogradeEffects(retrogradePlanets);
                }

                // 添加宮位信息
                character.houses = chart.houses;
            }

            return character;

        } catch (error) {
            console.error('[WorkingCharacterSystem] 從星盤生成角色失敗:', error);
            throw error;
        }
    }

    // 計算逆行行星影響
    calculateRetrogradeEffects(retrogradePlanets) {
        const effects = [];
        
        retrogradePlanets.forEach(({ planet, data }) => {
            const planetName = this.planets.find(p => p.id === planet + 'Sign')?.name || planet;
            
            switch (planet) {
                case 'mercury':
                    effects.push(`${planetName}逆行：溝通需要更多耐心，思考更加深入`);
                    break;
                case 'venus':
                    effects.push(`${planetName}逆行：情感表達更加內斂，美感獨特`);
                    break;
                case 'mars':
                    effects.push(`${planetName}逆行：行動力需要內在驅動，策略性更強`);
                    break;
                case 'jupiter':
                    effects.push(`${planetName}逆行：成長來自內在反思，智慧深邃`);
                    break;
                case 'saturn':
                    effects.push(`${planetName}逆行：責任感強烈，自我要求嚴格`);
                    break;
                case 'uranus':
                    effects.push(`${planetName}逆行：創新思維獨特，變革來自內在`);
                    break;
                case 'neptune':
                    effects.push(`${planetName}逆行：直覺敏銳，靈性追求深刻`);
                    break;
                case 'pluto':
                    effects.push(`${planetName}逆行：轉化力量強大，深層心理洞察`);
                    break;
            }
        });

        return effects;
    }


    // 從Claude星盤數據生成角色
    generateCharacterFromClaudeChart(name, chartData) {
        console.log('[WorkingCharacterSystem] 從Claude星盤生成角色:', name, chartData);
        
        try {
            // 轉換Claude星盤數據為內部格式
            const signConfig = this.convertClaudeChartToSignConfig(chartData);
            
            // 使用轉換後的配置生成角色
            const character = this.generateCharacter(name, signConfig);
            
            // 添加星盤相關信息
            if (character) {
                character.chartData = chartData;
                character.houses = chartData.houses;
                character.aspects = chartData.aspects;
                character.summary = chartData.summary;
                
                // 添加宮位分析
                character.houseAnalysis = this.generateHouseAnalysis(chartData.houses);
                
                // 添加相位分析
                character.aspectAnalysis = this.generateAspectAnalysis(chartData.aspects);
                
                // 添加Claude專業解讀
                character.claudeAnalysis = chartData.summary?.lifeDirection || '專業占星解讀';
            }
            
            return character;
            
        } catch (error) {
            console.error('[WorkingCharacterSystem] 從Claude星盤生成角色失敗:', error);
            return null;
        }
    }

    // 轉換Claude星盤數據為內部星座配置格式
    convertClaudeChartToSignConfig(chartData) {
        const signConfig = {};
        
        if (chartData.planets) {
            // 轉換行星星座
            const planetMapping = {
                'sun': 'sunSign',
                'moon': 'moonSign',
                'mercury': 'mercurySign',
                'venus': 'venusSign',
                'mars': 'marsSign',
                'jupiter': 'jupiterSign',
                'saturn': 'saturnSign',
                'uranus': 'uranusSign',
                'neptune': 'neptuneSign',
                'pluto': 'plutoSign'
            };
            
            Object.entries(planetMapping).forEach(([claudeKey, internalKey]) => {
                if (chartData.planets[claudeKey] && chartData.planets[claudeKey].sign) {
                    signConfig[internalKey] = chartData.planets[claudeKey].sign;
                }
            });
        }
        
        console.log('[WorkingCharacterSystem] 轉換後的星座配置:', signConfig);
        return signConfig;
    }

    // 生成宮位分析
    generateHouseAnalysis(houses) {
        if (!houses) return '宮位分析暫不可用';
        
        const analysis = [];
        
        // 分析重要宮位
        const importantHouses = ['1', '4', '7', '10']; // 角宮
        importantHouses.forEach(house => {
            if (houses[house]) {
                const houseData = houses[house];
                analysis.push(`第${house}宮(${this.getHouseName(house)})位於${this.getSignName(houseData.sign)}`);
            }
        });
        
        return analysis.join('；');
    }

    // 生成相位分析
    generateAspectAnalysis(aspects) {
        if (!aspects || !Array.isArray(aspects)) return '相位分析暫不可用';
        
        const analysis = [];
        
        // 分析重要相位
        aspects.slice(0, 3).forEach(aspect => {
            analysis.push(`${aspect.planet1}與${aspect.planet2}形成${aspect.aspect}`);
        });
        
        return analysis.join('；');
    }

    // 獲取宮位名稱
    getHouseName(houseNumber) {
        const houseNames = {
            '1': '自我宮',
            '2': '財帛宮',
            '3': '兄弟宮',
            '4': '田宅宮',
            '5': '子女宮',
            '6': '奴僕宮',
            '7': '夫妻宮',
            '8': '疾厄宮',
            '9': '遷移宮',
            '10': '官祿宮',
            '11': '福德宮',
            '12': '玄秘宮'
        };
        return houseNames[houseNumber] || `第${houseNumber}宮`;
    }

    // 獲取星座中文名稱
    getSignName(signKey) {
        const signNames = {
            'aries': '牡羊座',
            'taurus': '金牛座',
            'gemini': '雙子座',
            'cancer': '巨蟹座',
            'leo': '獅子座',
            'virgo': '處女座',
            'libra': '天秤座',
            'scorpio': '天蠍座',
            'sagittarius': '射手座',
            'capricorn': '摩羯座',
            'aquarius': '水瓶座',
            'pisces': '雙魚座'
        };
        return signNames[signKey] || signKey;
    }
}

// 將WorkingCharacterSystem暴露到全局
window.WorkingCharacterSystem = WorkingCharacterSystem;


// 自動排盤計算器
class AutoChartCalculator {
    constructor() {
        this.planetData = {
            sun: { name: '太陽', symbol: '☀️', element: 'fire' },
            moon: { name: '月亮', symbol: '🌙', element: 'water' },
            mercury: { name: '水星', symbol: '☿', element: 'air' },
            venus: { name: '金星', symbol: '♀', element: 'earth' },
            mars: { name: '火星', symbol: '♂', element: 'fire' },
            jupiter: { name: '木星', symbol: '♃', element: 'fire' },
            saturn: { name: '土星', symbol: '♄', element: 'earth' },
            uranus: { name: '天王星', symbol: '♅', element: 'air' },
            neptune: { name: '海王星', symbol: '♆', element: 'water' },
            pluto: { name: '冥王星', symbol: '♇', element: 'water' }
        };

        this.signs = [
            'aries', 'taurus', 'gemini', 'cancer', 'leo', 'virgo',
            'libra', 'scorpio', 'sagittarius', 'capricorn', 'aquarius', 'pisces'
        ];

        this.signNames = {
            aries: '牡羊座', taurus: '金牛座', gemini: '雙子座',
            cancer: '巨蟹座', leo: '獅子座', virgo: '處女座',
            libra: '天秤座', scorpio: '天蠍座', sagittarius: '射手座',
            capricorn: '摩羯座', aquarius: '水瓶座', pisces: '雙魚座'
        };
    }

    // 根據出生信息計算星盤
    calculateChart(birthData) {
        console.log('[AutoChartCalculator] 開始計算星盤:', birthData);

        try {
            // 解析出生日期和時間
            const birthDate = new Date(`${birthData.date}T${birthData.time}`);
            
            // 計算儒略日
            const julianDay = this.calculateJulianDay(birthDate);
            
            // 計算各行星位置
            const planetPositions = {};
            
            Object.keys(this.planetData).forEach(planet => {
                planetPositions[planet] = this.calculatePlanetPosition(planet, julianDay, birthData.location);
            });

            // 計算宮位
            const houses = this.calculateHouses(julianDay, birthData.location, birthData.timezone);

            const chart = {
                birthData: birthData,
                planets: planetPositions,
                houses: houses,
                calculatedAt: new Date().toISOString()
            };

            console.log('[AutoChartCalculator] 星盤計算完成:', chart);
            return chart;

        } catch (error) {
            console.error('[AutoChartCalculator] 計算錯誤:', error);
            throw new Error('星盤計算失敗: ' + error.message);
        }
    }

    // 計算儒略日
    calculateJulianDay(date) {
        const year = date.getFullYear();
        const month = date.getMonth() + 1;
        const day = date.getDate();
        const hour = date.getHours();
        const minute = date.getMinutes();

        let a = Math.floor((14 - month) / 12);
        let y = year + 4800 - a;
        let m = month + 12 * a - 3;

        let jdn = day + Math.floor((153 * m + 2) / 5) + 365 * y + Math.floor(y / 4) - Math.floor(y / 100) + Math.floor(y / 400) - 32045;
        let jd = jdn + (hour - 12) / 24 + minute / 1440;

        return jd;
    }

    // 計算行星位置（簡化版）
    calculatePlanetPosition(planet, julianDay, location) {
        // 這是一個簡化的計算，實際應該使用更精確的天文算法
        const basePositions = {
            sun: 280.0,
            moon: 218.3,
            mercury: 252.3,
            venus: 181.9,
            mars: 355.4,
            jupiter: 34.4,
            saturn: 50.1,
            uranus: 314.1,
            neptune: 304.3,
            pluto: 238.9
        };

        // 計算自J2000.0以來的天數
        const daysSinceJ2000 = julianDay - 2451545.0;
        
        // 簡化的軌道運動（每日平均運動）
        const dailyMotions = {
            sun: 0.9856,
            moon: 13.1764,
            mercury: 4.0923,
            venus: 1.6021,
            mars: 0.5240,
            jupiter: 0.0831,
            saturn: 0.0334,
            uranus: 0.0117,
            neptune: 0.0060,
            pluto: 0.0040
        };

        // 計算當前位置
        let position = basePositions[planet] + (dailyMotions[planet] * daysSinceJ2000);
        position = position % 360;
        if (position < 0) position += 360;

        // 轉換為星座
        const signIndex = Math.floor(position / 30);
        const degree = position % 30;
        const sign = this.signs[signIndex];

        // 檢查逆行（簡化判斷）
        const isRetrograde = this.checkRetrograde(planet, julianDay);

        return {
            sign: sign,
            signName: this.signNames[sign],
            degree: Math.round(degree * 100) / 100,
            position: Math.round(position * 100) / 100,
            isRetrograde: isRetrograde
        };
    }

    // 檢查行星是否逆行
    checkRetrograde(planet, julianDay) {
        // 簡化的逆行判斷
        const retrogradeChances = {
            sun: 0,      // 太陽不逆行
            moon: 0,     // 月亮不逆行
            mercury: 0.2, // 水星逆行機率20%
            venus: 0.08,  // 金星逆行機率8%
            mars: 0.1,    // 火星逆行機率10%
            jupiter: 0.3, // 木星逆行機率30%
            saturn: 0.35, // 土星逆行機率35%
            uranus: 0.4,  // 天王星逆行機率40%
            neptune: 0.4, // 海王星逆行機率40%
            pluto: 0.4    // 冥王星逆行機率40%
        };

        // 使用日期作為隨機種子
        const seed = Math.sin(julianDay + planet.charCodeAt(0)) * 10000;
        const random = seed - Math.floor(seed);
        
        return random < retrogradeChances[planet];
    }

    // 計算宮位（簡化版）
    calculateHouses(julianDay, location, timezone) {
        const houses = {};
        
        // 簡化的宮位計算
        for (let i = 1; i <= 12; i++) {
            const housePosition = (i - 1) * 30; // 每個宮位30度
            const signIndex = Math.floor(housePosition / 30);
            
            houses[i] = {
                sign: this.signs[signIndex],
                signName: this.signNames[this.signs[signIndex]],
                degree: housePosition % 30,
                position: housePosition
            };
        }

        return houses;
    }

    // 生成星盤分析
    generateAnalysis(chart) {
        const analysis = [];
        
        // 分析太陽星座
        const sun = chart.planets.sun;
        analysis.push(`太陽位於${sun.signName}，展現出${this.getSignTraits(sun.sign)}的特質。`);

        // 分析月亮星座
        const moon = chart.planets.moon;
        analysis.push(`月亮位於${moon.signName}，內心情感傾向${this.getSignTraits(moon.sign)}。`);

        // 分析逆行行星
        const retrogradePlanets = Object.entries(chart.planets)
            .filter(([planet, data]) => data.isRetrograde)
            .map(([planet, data]) => this.planetData[planet].name);

        if (retrogradePlanets.length > 0) {
            analysis.push(`${retrogradePlanets.join('、')}處於逆行狀態，需要特別關注內在反思與成長。`);
        }

        return analysis.join(' ');
    }

    // 獲取星座特質描述
    getSignTraits(sign) {
        const traits = {
            aries: '積極主動、勇敢直率',
            taurus: '穩重踏實、堅持不懈',
            gemini: '機智靈活、善於溝通',
            cancer: '溫柔體貼、情感豐富',
            leo: '自信大方、領導魅力',
            virgo: '細心謹慎、追求完美',
            libra: '和諧優雅、公正平衡',
            scorpio: '深沉神秘、意志堅強',
            sagittarius: '樂觀開朗、追求自由',
            capricorn: '務實穩重、目標明確',
            aquarius: '獨立創新、思想前衛',
            pisces: '敏感夢幻、富有同情心'
        };

        return traits[sign] || '獨特個性';
    }
}

// 全局實例
window.autoChartCalculator = new AutoChartCalculator();


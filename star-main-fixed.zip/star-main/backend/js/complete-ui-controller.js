// 完整的UI控制器
class CompleteUIController {
    constructor() {
        this.currentMode = 'manual';
        this.characterGenerator = null;
        this.astroEngine = null;
        
        // 元素引用
        this.elements = {};
        
        // 星座選擇器映射
        this.signSelectors = {
            sun: 'sun',
            moon: 'moon', 
            mercury: 'mercury',
            venus: 'venus',
            mars: 'mars',
            jupiter: 'jupiter'
        };
        
        console.log('CompleteUIController initializing...');
        this.init();
    }

    init() {
        try {
            this.initializeElements();
            this.initializeGenerators();
            this.bindEvents();
            this.showNotification('系統初始化完成', 'success');
            console.log('CompleteUIController initialized successfully');
        } catch (error) {
            console.error('CompleteUIController initialization error:', error);
            this.showNotification('系統初始化失敗', 'error');
        }
    }

    initializeElements() {
        // 模式切換按鈕
        this.elements.manualModeBtn = document.getElementById('manualModeBtn');
        this.elements.autoModeBtn = document.getElementById('autoModeBtn');
        
        // 模式容器
        this.elements.manualMode = document.getElementById('manualMode');
        this.elements.autoMode = document.getElementById('autoMode');
        
        // 生成按鈕
        this.elements.generateBtn = document.getElementById('generateBtn');
        this.elements.autoGenerateBtn = document.getElementById('autoGenerateBtn');
        
        // 輸入欄位
        this.elements.characterName = document.getElementById('characterName');
        this.elements.birthDate = document.getElementById('birthDate');
        this.elements.birthTime = document.getElementById('birthTime');
        this.elements.birthPlace = document.getElementById('birthPlace');
        this.elements.timezone = document.getElementById('timezone');
        
        // 結果顯示區域
        this.elements.characterResult = document.getElementById('characterResult');
        this.elements.characterCard = document.getElementById('characterCard');
        
        // 檢查必要元素
        const requiredElements = ['manualModeBtn', 'autoModeBtn', 'manualMode', 'autoMode', 'generateBtn'];
        const missingElements = requiredElements.filter(key => !this.elements[key]);
        
        if (missingElements.length > 0) {
            console.warn('Missing elements:', missingElements);
        }
        
        console.log('Elements initialized:', Object.keys(this.elements).reduce((acc, key) => {
            acc[key] = !!this.elements[key];
            return acc;
        }, {}));
    }

    initializeGenerators() {
        // 初始化角色生成器
        if (typeof WorkingCharacterGenerator !== 'undefined') {
            this.characterGenerator = new WorkingCharacterGenerator();
            console.log('Working character generator initialized');
        } else if (typeof EnhancedCharacterGenerator !== 'undefined') {
            this.characterGenerator = new EnhancedCharacterGenerator();
            console.log('Enhanced character generator initialized');
        } else if (typeof CharacterGenerator !== 'undefined') {
            this.characterGenerator = new CharacterGenerator();
            console.log('Basic character generator initialized');
        } else {
            console.warn('No character generator found, creating fallback');
            this.characterGenerator = {
                generateCharacter: (chart) => this.fallbackCharacterGeneration(chart)
            };
        }
        
        // 初始化占星引擎
        if (typeof PreciseAstroEngine !== 'undefined') {
            this.astroEngine = new PreciseAstroEngine();
            console.log('Precise astro engine initialized');
        } else if (typeof AstroEngine !== 'undefined') {
            this.astroEngine = new AstroEngine();
            console.log('Basic astro engine initialized');
        }
        
        // 確保生成器對象存在
        if (!this.characterGenerator || typeof this.characterGenerator.generateCharacter !== 'function') {
            console.warn('Character generator invalid, creating fallback');
            this.characterGenerator = {
                generateCharacter: (chart) => this.fallbackCharacterGeneration(chart)
            };
        }
    }

    bindEvents() {
        try {
            // 模式切換事件
            if (this.elements.manualModeBtn) {
                this.elements.manualModeBtn.addEventListener('click', () => this.switchToManualMode());
            }
            
            if (this.elements.autoModeBtn) {
                this.elements.autoModeBtn.addEventListener('click', () => this.switchToAutoMode());
            }
            
            // 生成按鈕事件
            if (this.elements.generateBtn) {
                this.elements.generateBtn.addEventListener('click', () => this.generateCharacterManual());
            }
            
            if (this.elements.autoGenerateBtn) {
                this.elements.autoGenerateBtn.addEventListener('click', () => this.generateCharacterAuto());
            }
            
            console.log('Events bound successfully');
        } catch (error) {
            console.error('Event binding error:', error);
        }
    }

    switchToManualMode() {
        try {
            this.currentMode = 'manual';
            
            if (this.elements.manualMode) {
                this.elements.manualMode.style.display = 'block';
            }
            if (this.elements.autoMode) {
                this.elements.autoMode.style.display = 'none';
            }
            
            // 更新按鈕狀態
            if (this.elements.manualModeBtn) {
                this.elements.manualModeBtn.classList.add('active');
            }
            if (this.elements.autoModeBtn) {
                this.elements.autoModeBtn.classList.remove('active');
            }
            
            this.showNotification('已切換到手動輸入模式', 'success');
            console.log('Switched to manual mode');
        } catch (error) {
            console.error('Switch to manual mode error:', error);
        }
    }

    switchToAutoMode() {
        try {
            this.currentMode = 'auto';
            
            if (this.elements.manualMode) {
                this.elements.manualMode.style.display = 'none';
            }
            if (this.elements.autoMode) {
                this.elements.autoMode.style.display = 'block';
            }
            
            // 更新按鈕狀態
            if (this.elements.manualModeBtn) {
                this.elements.manualModeBtn.classList.remove('active');
            }
            if (this.elements.autoModeBtn) {
                this.elements.autoModeBtn.classList.add('active');
            }
            
            this.showNotification('已切換到自動排盤模式', 'success');
            console.log('Switched to auto mode');
        } catch (error) {
            console.error('Switch to auto mode error:', error);
        }
    }

    generateCharacterManual() {
        try {
            console.log('Starting manual character generation');
            
            // 收集星座數據
            const chart = this.collectManualData();
            console.log('Manual data collected:', chart);
            
            if (!this.validateManualData(chart)) {
                this.showNotification('請完整填寫所有星座信息', 'warning');
                return;
            }
            
            // 生成角色
            const character = this.characterGenerator.generateCharacter(chart);
            console.log('Character generated:', character);
            
            // 顯示結果
            this.displayCharacter(character);
            this.showNotification('角色生成成功！', 'success');
            
        } catch (error) {
            console.error('Manual generation error:', error);
            this.showNotification(`生成失敗: ${error.message}`, 'error');
        }
    }

    generateCharacterAuto() {
        try {
            console.log('Starting auto character generation');
            
            // 收集出生數據
            const birthData = this.collectBirthData();
            console.log('Birth data collected:', birthData);
            
            if (!this.validateBirthData(birthData)) {
                this.showNotification('請完整填寫出生信息', 'warning');
                return;
            }
            
            this.showNotification('正在計算星盤...', 'info');
            
            // 計算星盤
            let chart;
            if (this.astroEngine && typeof this.astroEngine.calculateChart === 'function') {
                chart = this.astroEngine.calculateChart(birthData);
            } else {
                // 使用簡化的星盤計算
                chart = this.calculateSimpleChart(birthData);
            }
            
            console.log('Chart calculated:', chart);
            
            // 生成角色
            const character = this.characterGenerator.generateCharacter(chart);
            console.log('Character generated:', character);
            
            // 顯示結果
            this.displayCharacter(character);
            this.showNotification('自動排盤生成成功！', 'success');
            
        } catch (error) {
            console.error('Auto generation error:', error);
            this.showNotification(`自動生成失敗: ${error.message}`, 'error');
        }
    }

    collectManualData() {
        const chart = {
            name: this.elements.characterName ? this.elements.characterName.value : '',
            mode: 'manual'
        };
        
        // 收集星座選擇
        Object.keys(this.signSelectors).forEach(planet => {
            const selector = document.getElementById(this.signSelectors[planet]);
            if (selector && selector.value) {
                chart[planet] = {
                    sign: selector.value,
                    degree: Math.floor(Math.random() * 30) // 簡化處理
                };
                console.log(`Checking ${planet}: ${selector.value} ${selector.selectedIndex}`);
            }
        });
        
        console.log('Selected signs:', chart);
        return chart;
    }

    collectBirthData() {
        // 使用正確的元素ID
        const autoCharacterName = document.getElementById('autoCharacterName');
        const birthDate = document.getElementById('birthDate');
        const birthTime = document.getElementById('birthTime');
        const birthLocation = document.getElementById('birthLocation');
        const timezone = document.getElementById('timezone');
        
        // 詳細調試每個元素的值
        console.log('Element values debug:', {
            autoCharacterName: autoCharacterName ? autoCharacterName.value : 'NOT_FOUND',
            birthDate: birthDate ? birthDate.value : 'NOT_FOUND',
            birthTime: birthTime ? birthTime.value : 'NOT_FOUND',
            birthLocation: birthLocation ? birthLocation.value : 'NOT_FOUND',
            timezone: timezone ? timezone.value : 'NOT_FOUND'
        });
        
        // 特別處理日期和時間輸入
        let dateValue = '';
        let timeValue = '';
        
        if (birthDate) {
            dateValue = birthDate.value || '';
            console.log('Date input type:', birthDate.type);
            console.log('Date input value:', birthDate.value);
            console.log('Date input valueAsDate:', birthDate.valueAsDate);
        }
        
        if (birthTime) {
            timeValue = birthTime.value || '';
            console.log('Time input type:', birthTime.type);
            console.log('Time input value:', birthTime.value);
        }
        
        const data = {
            name: autoCharacterName ? autoCharacterName.value.trim() : '',
            date: dateValue.trim(),
            time: timeValue.trim(),
            place: birthLocation ? birthLocation.value.trim() : '',
            timezone: timezone ? timezone.value : 'Asia/Taipei'
        };
        
        console.log('Collecting birth data:', data);
        console.log('Elements found:', {
            autoCharacterName: !!autoCharacterName,
            birthDate: !!birthDate,
            birthTime: !!birthTime,
            birthLocation: !!birthLocation,
            timezone: !!timezone
        });
        
        return data;
    }

    validateManualData(chart) {
        const requiredPlanets = ['sun', 'moon', 'mercury', 'venus', 'mars', 'jupiter'];
        return requiredPlanets.every(planet => chart[planet] && chart[planet].sign);
    }

    validateBirthData(data) {
        console.log('Validating birth data:', data);
        
        const isValid = data.name && data.name.trim() !== '' && 
                       data.date && data.date.trim() !== '' && 
                       data.time && data.time.trim() !== '' && 
                       data.place && data.place.trim() !== '';
        
        console.log('Validation result:', {
            name: data.name && data.name.trim() !== '',
            date: data.date && data.date.trim() !== '',
            time: data.time && data.time.trim() !== '',
            place: data.place && data.place.trim() !== '',
            overall: isValid
        });
        
        if (!isValid) {
            console.log('Missing fields:', {
                name: !data.name || data.name.trim() === '',
                date: !data.date || data.date.trim() === '',
                time: !data.time || data.time.trim() === '',
                place: !data.place || data.place.trim() === ''
            });
        }
        
        return isValid;
    }

    calculateSimpleChart(birthData) {
        // 簡化的星盤計算（用於演示）
        const signs = ['aries', 'taurus', 'gemini', 'cancer', 'leo', 'virgo', 
                      'libra', 'scorpio', 'sagittarius', 'capricorn', 'aquarius', 'pisces'];
        
        const chart = {
            name: birthData.name,
            mode: 'auto',
            birthData: birthData
        };
        
        // 根據出生日期簡單計算太陽星座
        const date = new Date(birthData.date);
        const month = date.getMonth() + 1;
        const day = date.getDate();
        
        let sunSign = 'leo'; // 默認
        if ((month == 3 && day >= 21) || (month == 4 && day <= 19)) sunSign = 'aries';
        else if ((month == 4 && day >= 20) || (month == 5 && day <= 20)) sunSign = 'taurus';
        else if ((month == 5 && day >= 21) || (month == 6 && day <= 20)) sunSign = 'gemini';
        else if ((month == 6 && day >= 21) || (month == 7 && day <= 22)) sunSign = 'cancer';
        else if ((month == 7 && day >= 23) || (month == 8 && day <= 22)) sunSign = 'leo';
        else if ((month == 8 && day >= 23) || (month == 9 && day <= 22)) sunSign = 'virgo';
        else if ((month == 9 && day >= 23) || (month == 10 && day <= 22)) sunSign = 'libra';
        else if ((month == 10 && day >= 23) || (month == 11 && day <= 21)) sunSign = 'scorpio';
        else if ((month == 11 && day >= 22) || (month == 12 && day <= 21)) sunSign = 'sagittarius';
        else if ((month == 12 && day >= 22) || (month == 1 && day <= 19)) sunSign = 'capricorn';
        else if ((month == 1 && day >= 20) || (month == 2 && day <= 18)) sunSign = 'aquarius';
        else if ((month == 2 && day >= 19) || (month == 3 && day <= 20)) sunSign = 'pisces';
        
        chart.sun = { sign: sunSign, degree: Math.floor(Math.random() * 30) };
        
        // 其他行星隨機分配（簡化處理）
        chart.moon = { sign: signs[Math.floor(Math.random() * 12)], degree: Math.floor(Math.random() * 30) };
        chart.mercury = { sign: signs[Math.floor(Math.random() * 12)], degree: Math.floor(Math.random() * 30) };
        chart.venus = { sign: signs[Math.floor(Math.random() * 12)], degree: Math.floor(Math.random() * 30) };
        chart.mars = { sign: signs[Math.floor(Math.random() * 12)], degree: Math.floor(Math.random() * 30) };
        chart.jupiter = { sign: signs[Math.floor(Math.random() * 12)], degree: Math.floor(Math.random() * 30) };
        
        return chart;
    }

    displayCharacter(character) {
        try {
            if (!this.elements.characterResult) {
                console.warn('Character result element not found');
                return;
            }
            
            this.elements.characterResult.style.display = 'block';
            
            const html = `
                <div class="character-card mystical-card">
                    <div class="character-header">
                        <h3 class="character-name">${character.name}</h3>
                        <div class="character-class">${character.class.name} (${character.class.nameEn})</div>
                        <div class="character-grade grade-${character.grade}">${character.grade}級</div>
                    </div>
                    
                    <div class="character-stats">
                        <h4>屬性</h4>
                        <div class="stats-grid">
                            <div class="stat-item">
                                <span class="stat-name">力量</span>
                                <span class="stat-value">${character.stats.strength}</span>
                            </div>
                            <div class="stat-item">
                                <span class="stat-name">智力</span>
                                <span class="stat-value">${character.stats.intelligence}</span>
                            </div>
                            <div class="stat-item">
                                <span class="stat-name">敏捷</span>
                                <span class="stat-value">${character.stats.agility}</span>
                            </div>
                            <div class="stat-item">
                                <span class="stat-name">智慧</span>
                                <span class="stat-value">${character.stats.wisdom}</span>
                            </div>
                            <div class="stat-item">
                                <span class="stat-name">魅力</span>
                                <span class="stat-value">${character.stats.charisma}</span>
                            </div>
                            <div class="stat-item">
                                <span class="stat-name">體質</span>
                                <span class="stat-value">${character.stats.constitution}</span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="character-skills">
                        <h4>技能</h4>
                        <div class="skills-list">
                            ${character.skills.map(skill => `<span class="skill-tag">${skill}</span>`).join('')}
                        </div>
                    </div>
                    
                    <div class="character-description">
                        <h4>角色描述</h4>
                        <p>${character.description}</p>
                    </div>
                    
                    <div class="fantasy-elements">
                        <h4>✨ 奇幻元素</h4>
                        <ul>
                            ${character.fantasyElements.map(element => `<li>${element}</li>`).join('')}
                        </ul>
                    </div>
                </div>
            `;
            
            this.elements.characterResult.innerHTML = html;
            
            // 滾動到結果區域
            this.elements.characterResult.scrollIntoView({ behavior: 'smooth' });
            
        } catch (error) {
            console.error('Display character error:', error);
        }
    }

    fallbackCharacterGeneration(chart) {
        console.log('Using fallback character generation');
        return {
            name: chart.name || '神秘冒險者',
            class: { name: '戰士', nameEn: 'Fighter', description: '勇敢的戰士' },
            stats: { strength: 8, intelligence: 6, agility: 7, wisdom: 6, charisma: 7, constitution: 8 },
            grade: 'B',
            skills: ['基礎戰鬥', '武器精通', '防禦技巧'],
            chart: chart,
            description: '一位勇敢的冒險者，準備踏上未知的旅程。',
            fantasyElements: ['初心者的勇氣', '命運的指引']
        };
    }

    showNotification(message, type = 'info') {
        console.log(`[${type.toUpperCase()}] ${message}`);
        
        // 創建通知元素
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.textContent = message;
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 12px 20px;
            border-radius: 8px;
            color: white;
            font-weight: bold;
            z-index: 10000;
            animation: slideIn 0.3s ease-out;
        `;
        
        // 設置顏色
        switch (type) {
            case 'success':
                notification.style.backgroundColor = '#4CAF50';
                break;
            case 'error':
                notification.style.backgroundColor = '#f44336';
                break;
            case 'warning':
                notification.style.backgroundColor = '#ff9800';
                break;
            default:
                notification.style.backgroundColor = '#2196F3';
        }
        
        document.body.appendChild(notification);
        
        // 3秒後移除
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 3000);
    }
}

// 頁面加載完成後初始化
document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM loaded, initializing CompleteUIController');
    window.uiController = new CompleteUIController();
});

// 確保全局可用
window.CompleteUIController = CompleteUIController;
console.log('Complete UI controller loaded successfully');


/**
 * 逆行行星影響計算模塊
 * 根據逆行行星狀態計算對RPG屬性和技能的影響
 */

class RetrogradeCalculator {
    constructor() {
        // 逆行行星對屬性的影響配置
        this.retrogradeEffects = {
            mercury: {
                attributes: {
                    intelligence: -2,
                    perception: +3
                },
                skills: [
                    {
                        name: '深度思考',
                        type: 'mental',
                        description: '水星逆行賦予的深度思考能力，在重要決策時能夠更仔細地分析',
                        bonus: 4
                    },
                    {
                        name: '另類溝通',
                        type: 'social',
                        description: '以獨特方式進行溝通，能夠用不同的角度表達想法',
                        bonus: 3
                    }
                ],
                traits: ['謹慎表達', '內向思考', '溝通障礙轉化為優勢']
            },
            venus: {
                attributes: {
                    charisma: -2,
                    creativity: +5
                },
                skills: [
                    {
                        name: '獨特美學',
                        type: 'artistic',
                        description: '金星逆行帶來的獨特藝術品味，能創造與眾不同的美感',
                        bonus: 5
                    },
                    {
                        name: '非傳統關係',
                        type: 'social',
                        description: '以非傳統方式處理人際關係，建立深度而獨特的連結',
                        bonus: 3
                    }
                ],
                traits: ['藝術天賦', '獨特風格', '關係深度']
            },
            mars: {
                attributes: {
                    strength: -3,
                    agility: +2
                },
                skills: [
                    {
                        name: '戰術思維',
                        type: 'combat',
                        description: '火星逆行培養的戰術思維，能夠以策略取勝而非蠻力',
                        bonus: 4
                    },
                    {
                        name: '內在力量',
                        type: 'mental',
                        description: '將憤怒轉化為內在驅動力，擁有持久的意志力',
                        bonus: 3
                    }
                ],
                traits: ['策略思考', '內斂力量', '衝突轉化']
            },
            jupiter: {
                attributes: {
                    wisdom: +2,
                    luck: -1
                },
                skills: [
                    {
                        name: '哲學洞察',
                        type: 'wisdom',
                        description: '木星逆行帶來的深度哲學思考，能夠理解複雜的人生道理',
                        bonus: 4
                    },
                    {
                        name: '文化融合',
                        type: 'knowledge',
                        description: '對不同文化有深度理解，能夠融合多元觀點',
                        bonus: 3
                    }
                ],
                traits: ['哲學思維', '文化敏感', '信念獨立']
            },
            saturn: {
                attributes: {
                    constitution: +3,
                    discipline: +2
                },
                skills: [
                    {
                        name: '結構重建',
                        type: 'leadership',
                        description: '土星逆行賦予的重建能力，能夠創造新的秩序和結構',
                        bonus: 5
                    },
                    {
                        name: '權威挑戰',
                        type: 'social',
                        description: '敢於挑戰不合理的權威，建立更公正的制度',
                        bonus: 4
                    }
                ],
                traits: ['制度改革', '責任感強', '權威質疑']
            },
            uranus: {
                attributes: {
                    innovation: +4,
                    independence: +3
                },
                skills: [
                    {
                        name: '革新思維',
                        type: 'innovation',
                        description: '天王星逆行激發的革新能力，能夠突破傳統思維模式',
                        bonus: 4
                    },
                    {
                        name: '獨立精神',
                        type: 'mental',
                        description: '強烈的獨立意識，不依賴他人而能自主決策',
                        bonus: 3
                    }
                ],
                traits: ['反叛精神', '創新思維', '獨立自主']
            },
            neptune: {
                attributes: {
                    perception: +4,
                    intuition: +3
                },
                skills: [
                    {
                        name: '藝術創作',
                        type: 'artistic',
                        description: '海王星逆行增強的藝術創作能力，能夠創造感人的作品',
                        bonus: 5
                    },
                    {
                        name: '靈性感知',
                        type: 'mystical',
                        description: '對靈性世界的敏銳感知，能夠察覺隱藏的真相',
                        bonus: 4
                    }
                ],
                traits: ['高度敏感', '藝術天賦', '靈性覺醒']
            },
            pluto: {
                attributes: {
                    willpower: +5,
                    transformation: +4
                },
                skills: [
                    {
                        name: '心理洞察',
                        type: 'psychology',
                        description: '冥王星逆行帶來的深度心理洞察力，能夠理解人性深層動機',
                        bonus: 5
                    },
                    {
                        name: '自我重生',
                        type: 'transformation',
                        description: '強大的自我轉化能力，能夠從困境中重新崛起',
                        bonus: 4
                    }
                ],
                traits: ['深度轉化', '心理洞察', '重生能力']
            }
        };
    }

    /**
     * 計算逆行行星對角色的影響
     * @param {Object} chartData - 星盤數據
     * @returns {Object} 逆行影響結果
     */
    calculateRetrogradeEffects(chartData) {
        const effects = {
            attributeModifiers: {},
            bonusSkills: [],
            specialTraits: [],
            retrogradeCount: 0,
            retrogradeDescription: ''
        };

        // 檢查每個行星的逆行狀態
        for (const [planetName, planetData] of Object.entries(chartData.planets)) {
            if (planetData.retrograde && this.retrogradeEffects[planetName]) {
                effects.retrogradeCount++;
                const planetEffect = this.retrogradeEffects[planetName];

                // 應用屬性修正
                for (const [attr, modifier] of Object.entries(planetEffect.attributes)) {
                    if (!effects.attributeModifiers[attr]) {
                        effects.attributeModifiers[attr] = 0;
                    }
                    effects.attributeModifiers[attr] += modifier;
                }

                // 添加特殊技能
                effects.bonusSkills.push(...planetEffect.skills);

                // 添加特質
                effects.specialTraits.push(...planetEffect.traits);
            }
        }

        // 生成逆行描述
        effects.retrogradeDescription = this.generateRetrogradeDescription(effects);

        return effects;
    }

    /**
     * 生成逆行影響的描述文字
     * @param {Object} effects - 逆行影響效果
     * @returns {string} 描述文字
     */
    generateRetrogradeDescription(effects) {
        if (effects.retrogradeCount === 0) {
            return '你的星盤中沒有逆行行星，這表示你能夠直接而自然地表達各行星的能量。';
        }

        let description = `你的星盤中有 ${effects.retrogradeCount} 顆逆行行星，這賦予了你獨特的內在力量：\n\n`;

        if (effects.retrogradeCount >= 4) {
            description += '🌟 多重逆行賦予你深度的內省能力和獨特的人生視角。你可能感覺與眾不同，但這正是你的力量所在。\n\n';
        } else if (effects.retrogradeCount >= 2) {
            description += '✨ 逆行行星讓你在某些領域需要以不同的方式表達自己，但也因此獲得了特殊的洞察力。\n\n';
        } else {
            description += '💫 單一逆行行星為你帶來了特定領域的深度理解和獨特表達方式。\n\n';
        }

        // 添加特質描述
        if (effects.specialTraits.length > 0) {
            description += '你的逆行特質包括：' + effects.specialTraits.slice(0, 3).join('、') + '。';
        }

        return description;
    }

    /**
     * 獲取逆行行星的詳細解釋
     * @param {string} planetName - 行星名稱
     * @returns {Object} 詳細解釋
     */
    getRetrogradeExplanation(planetName) {
        const explanations = {
            mercury: {
                title: '水星逆行 - 深度溝通者',
                description: '你的思考方式與眾不同，需要更多時間來處理和表達想法。這讓你成為一個深度思考者，能夠看到別人忽略的細節。',
                strengths: ['深度分析', '謹慎表達', '獨特視角'],
                challenges: ['溝通延遲', '表達困難', '學習方式特殊'],
                advice: '學會欣賞你獨特的思考方式，給自己足夠的時間來表達想法。'
            },
            venus: {
                title: '金星逆行 - 獨特美學家',
                description: '你對美和關係有著與眾不同的理解，可能不遵循傳統的審美或關係模式。',
                strengths: ['獨特品味', '深度關係', '藝術天賦'],
                challenges: ['社交困難', '自我價值', '關係模式'],
                advice: '相信你獨特的美感和關係觀，它們是你的珍貴資產。'
            },
            mars: {
                title: '火星逆行 - 內在戰士',
                description: '你的行動力和憤怒表達方式與眾不同，更傾向於內化和策略性思考。',
                strengths: ['戰略思維', '持久力', '內在力量'],
                challenges: ['行動遲緩', '憤怒壓抑', '動機困難'],
                advice: '學會將內在的火焰轉化為持久的動力和智慧的行動。'
            }
        };

        return explanations[planetName] || null;
    }

    /**
     * 計算逆行對職業選擇的影響
     * @param {Object} effects - 逆行影響效果
     * @returns {Array} 推薦職業列表
     */
    getRetrogradeCareerSuggestions(effects) {
        const careers = [];

        if (effects.bonusSkills.some(skill => skill.type === 'artistic')) {
            careers.push({
                name: '神秘藝術家',
                description: '運用逆行賦予的獨特美感創造藝術作品',
                suitability: 95
            });
        }

        if (effects.bonusSkills.some(skill => skill.type === 'psychology')) {
            careers.push({
                name: '心靈導師',
                description: '運用深度心理洞察幫助他人成長',
                suitability: 90
            });
        }

        if (effects.bonusSkills.some(skill => skill.type === 'innovation')) {
            careers.push({
                name: '變革先鋒',
                description: '以創新思維推動社會變革',
                suitability: 88
            });
        }

        return careers;
    }
}

// 導出模塊
window.RetrogradeCalculator = RetrogradeCalculator;


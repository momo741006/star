// 增強的角色顯示系統
class EnhancedDisplaySystem {
    constructor() {
        this.resultContainer = null;
        this.init();
    }

    init() {
        // 創建結果顯示容器
        this.createResultContainer();
        console.log('[EnhancedDisplaySystem] 顯示系統初始化完成');
    }

    createResultContainer() {
        // 檢查是否已存在
        let container = document.getElementById('characterResult');
        
        if (!container) {
            container = document.createElement('div');
            container.id = 'characterResult';
            container.className = 'character-result-container';
            container.style.display = 'none';
            
            // 插入到主要內容區域
            const mainContent = document.querySelector('.container') || document.body;
            mainContent.appendChild(container);
        }
        
        this.resultContainer = container;
    }

    displayCharacter(character) {
        if (!this.resultContainer) {
            console.error('[EnhancedDisplaySystem] 結果容器未找到');
            return;
        }

        // 生成角色卡片HTML
        const characterHTML = this.generateCharacterHTML(character);
        
        // 更新容器內容
        this.resultContainer.innerHTML = characterHTML;
        this.resultContainer.style.display = 'block';
        
        // 滾動到結果區域
        this.resultContainer.scrollIntoView({ 
            behavior: 'smooth', 
            block: 'start' 
        });

        // 添加動畫效果
        this.addAnimationEffects();
        
        console.log('[EnhancedDisplaySystem] 角色顯示完成');
    }

    generateCharacterHTML(character) {
        return `
            <div class="character-card">
                <div class="character-header">
                    <h2 class="character-name">${character.name}</h2>
                    <div class="character-profession">${character.class.name} (${character.class.englishName})</div>
                    <div class="character-grade grade-${character.grade}">${character.grade}級</div>
                    <p class="character-description">${character.class.description}</p>
                </div>

                <div class="character-content">
                    <div class="attributes-section">
                        <h3>⚔️ 角色屬性</h3>
                        <div class="attributes-grid">
                            <div class="attribute-item">
                                <div class="attribute-name">💪 力量</div>
                                <div class="attribute-value">${character.attributes.strength}</div>
                                <div class="attribute-bar">
                                    <div class="attribute-fill" style="width: ${(character.attributes.strength / 25) * 100}%"></div>
                                </div>
                            </div>
                            <div class="attribute-item">
                                <div class="attribute-name">🧠 智力</div>
                                <div class="attribute-value">${character.attributes.intelligence}</div>
                                <div class="attribute-bar">
                                    <div class="attribute-fill" style="width: ${(character.attributes.intelligence / 25) * 100}%"></div>
                                </div>
                            </div>
                            <div class="attribute-item">
                                <div class="attribute-name">🏃 敏捷</div>
                                <div class="attribute-value">${character.attributes.dexterity}</div>
                                <div class="attribute-bar">
                                    <div class="attribute-fill" style="width: ${(character.attributes.dexterity / 25) * 100}%"></div>
                                </div>
                            </div>
                            <div class="attribute-item">
                                <div class="attribute-name">🔮 智慧</div>
                                <div class="attribute-value">${character.attributes.wisdom}</div>
                                <div class="attribute-bar">
                                    <div class="attribute-fill" style="width: ${(character.attributes.wisdom / 25) * 100}%"></div>
                                </div>
                            </div>
                            <div class="attribute-item">
                                <div class="attribute-name">✨ 魅力</div>
                                <div class="attribute-value">${character.attributes.charisma}</div>
                                <div class="attribute-bar">
                                    <div class="attribute-fill" style="width: ${(character.attributes.charisma / 25) * 100}%"></div>
                                </div>
                            </div>
                            <div class="attribute-item">
                                <div class="attribute-name">🛡️ 體質</div>
                                <div class="attribute-value">${character.attributes.constitution}</div>
                                <div class="attribute-bar">
                                    <div class="attribute-fill" style="width: ${(character.attributes.constitution / 25) * 100}%"></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="skills-section">
                        <h3>🎯 職業技能</h3>
                        <div class="skills-grid">
                            ${character.class.skills.map(skill => `
                                <div class="skill-item">
                                    <span class="skill-icon">⚡</span>
                                    <span class="skill-name">${skill}</span>
                                </div>
                            `).join('')}
                        </div>
                    </div>

                    <div class="planet-analysis-section">
                        <h3>🌟 星盤分析</h3>
                        <div class="planet-summary">
                            <p>基於您的星座配置，此角色展現出獨特的宇宙能量組合。</p>
                            <div class="element-distribution">
                                <div class="element-item fire">🔥 火象能量: ${this.calculateElementCount(character.planetData, 'fire')}</div>
                                <div class="element-item earth">🌍 土象能量: ${this.calculateElementCount(character.planetData, 'earth')}</div>
                                <div class="element-item air">💨 風象能量: ${this.calculateElementCount(character.planetData, 'air')}</div>
                                <div class="element-item water">🌊 水象能量: ${this.calculateElementCount(character.planetData, 'water')}</div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="character-actions">
                    <button class="action-btn regenerate-btn" onclick="window.mainController.handleGenerate()">
                        🔄 重新生成
                    </button>
                    <button class="action-btn export-btn" onclick="window.enhancedDisplay.exportReport('${character.name}')">
                        📄 導出報告
                    </button>
                </div>
            </div>
        `;
    }

    calculateElementCount(planetData, element) {
        if (!planetData || !planetData.data) return 0;
        
        const signs = {
            'aries': 'fire', 'leo': 'fire', 'sagittarius': 'fire',
            'taurus': 'earth', 'virgo': 'earth', 'capricorn': 'earth',
            'gemini': 'air', 'libra': 'air', 'aquarius': 'air',
            'cancer': 'water', 'scorpio': 'water', 'pisces': 'water'
        };

        return Object.values(planetData.data).filter(sign => signs[sign] === element).length;
    }

    addAnimationEffects() {
        // 添加淡入動畫
        this.resultContainer.style.opacity = '0';
        this.resultContainer.style.transform = 'translateY(20px)';
        
        setTimeout(() => {
            this.resultContainer.style.transition = 'all 0.5s ease-out';
            this.resultContainer.style.opacity = '1';
            this.resultContainer.style.transform = 'translateY(0)';
        }, 100);

        // 屬性條動畫
        setTimeout(() => {
            const attributeBars = this.resultContainer.querySelectorAll('.attribute-fill');
            attributeBars.forEach((bar, index) => {
                setTimeout(() => {
                    bar.style.transition = 'width 0.8s ease-out';
                    bar.style.width = bar.style.width; // 觸發動畫
                }, index * 100);
            });
        }, 500);
    }

    exportReport(characterName) {
        // 簡單的報告導出功能
        const reportContent = this.resultContainer.innerHTML;
        const blob = new Blob([`
            <!DOCTYPE html>
            <html>
            <head>
                <title>${characterName} - 角色報告</title>
                <meta charset="UTF-8">
                <style>
                    body { font-family: Arial, sans-serif; margin: 20px; background: #f0f0f0; }
                    .character-card { background: white; padding: 20px; border-radius: 10px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); }
                    .character-name { color: #FFD700; font-size: 2em; text-align: center; }
                    .attributes-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px; margin: 20px 0; }
                    .attribute-item { text-align: center; padding: 10px; background: #f9f9f9; border-radius: 8px; }
                    .skills-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; }
                    .skill-item { padding: 8px; background: #e8f4fd; border-radius: 5px; }
                </style>
            </head>
            <body>
                ${reportContent}
            </body>
            </html>
        `], { type: 'text/html' });
        
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${characterName}_角色報告.html`;
        a.click();
        URL.revokeObjectURL(url);
        
        console.log(`[EnhancedDisplaySystem] 報告已導出: ${characterName}`);
    }
}

// 創建全局實例
window.enhancedDisplay = new EnhancedDisplaySystem();


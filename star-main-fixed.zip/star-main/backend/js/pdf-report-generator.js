/**
 * 🌟 虹靈御所占星主角生成系統 - PDF報告生成器
 * 生成詳細的角色分析PDF報告
 */

class PDFReportGenerator {
    constructor() {
        this.reportTemplate = null;
        this.initializeTemplate();
    }

    /**
     * 初始化報告模板
     */
    initializeTemplate() {
        this.reportTemplate = {
            title: '🌟 虹靈御所占星角色分析報告',
            sections: [
                'character_overview',
                'astrological_analysis',
                'attribute_breakdown',
                'skill_analysis',
                'retrograde_influence',
                'career_guidance',
                'relationship_compatibility',
                'life_path_guidance',
                'fantasy_elements',
                'appendix'
            ]
        };
    }

    /**
     * 生成完整PDF報告
     * @param {Object} character - 角色數據
     * @param {Object} chartData - 星盤數據
     * @param {Object} retrogradeEffects - 逆行影響
     * @returns {Promise<Blob>} PDF文件
     */
    async generatePDFReport(character, chartData, retrogradeEffects) {
        try {
            // 生成HTML內容
            const htmlContent = this.generateHTMLReport(character, chartData, retrogradeEffects);
            
            // 如果在瀏覽器環境中，使用html2pdf
            if (typeof window !== 'undefined' && window.html2pdf) {
                const element = document.createElement('div');
                element.innerHTML = htmlContent;
                element.style.display = 'none';
                document.body.appendChild(element);
                
                const pdf = await html2pdf()
                    .from(element)
                    .set({
                        margin: 1,
                        filename: `${character.name}_角色報告.pdf`,
                        image: { type: 'jpeg', quality: 0.98 },
                        html2canvas: { scale: 2 },
                        jsPDF: { unit: 'in', format: 'a4', orientation: 'portrait' }
                    })
                    .outputPdf('blob');
                
                document.body.removeChild(element);
                return pdf;
            } else {
                // 返回HTML內容作為備選方案
                return new Blob([htmlContent], { type: 'text/html' });
            }
        } catch (error) {
            console.error('PDF生成錯誤:', error);
            throw new Error('PDF報告生成失敗');
        }
    }

    /**
     * 生成HTML報告內容
     * @param {Object} character - 角色數據
     * @param {Object} chartData - 星盤數據
     * @param {Object} retrogradeEffects - 逆行影響
     * @returns {string} HTML內容
     */
    generateHTMLReport(character, chartData, retrogradeEffects) {
        const reportData = {
            character,
            chartData,
            retrogradeEffects,
            generatedAt: new Date().toLocaleString('zh-TW'),
            reportId: this.generateReportId()
        };

        return `
<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${character.name} - 占星角色分析報告</title>
    <style>
        ${this.getReportStyles()}
    </style>
</head>
<body>
    <div class="report-container">
        ${this.generateCoverPage(reportData)}
        ${this.generateTableOfContents()}
        ${this.generateCharacterOverview(reportData)}
        ${this.generateAstrologicalAnalysis(reportData)}
        ${this.generateAttributeBreakdown(reportData)}
        ${this.generateSkillAnalysis(reportData)}
        ${this.generateRetrogradeInfluence(reportData)}
        ${this.generateCareerGuidance(reportData)}
        ${this.generateRelationshipCompatibility(reportData)}
        ${this.generateLifePathGuidance(reportData)}
        ${this.generateFantasyElements(reportData)}
        ${this.generateAppendix(reportData)}
    </div>
</body>
</html>`;
    }

    /**
     * 獲取報告樣式
     * @returns {string} CSS樣式
     */
    getReportStyles() {
        return `
            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }
            
            body {
                font-family: 'Microsoft JhengHei', 'PingFang TC', 'Noto Sans TC', sans-serif;
                line-height: 1.6;
                color: #333;
                background: #fff;
            }
            
            .report-container {
                max-width: 800px;
                margin: 0 auto;
                padding: 40px;
            }
            
            .cover-page {
                text-align: center;
                padding: 100px 0;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                border-radius: 20px;
                margin-bottom: 40px;
            }
            
            .cover-title {
                font-size: 3rem;
                margin-bottom: 20px;
                text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
            }
            
            .cover-subtitle {
                font-size: 1.5rem;
                margin-bottom: 30px;
                opacity: 0.9;
            }
            
            .character-name-cover {
                font-size: 2.5rem;
                margin-bottom: 20px;
                background: rgba(255,255,255,0.2);
                padding: 20px;
                border-radius: 15px;
                display: inline-block;
            }
            
            .report-info {
                font-size: 1rem;
                opacity: 0.8;
            }
            
            .section {
                margin-bottom: 40px;
                page-break-inside: avoid;
            }
            
            .section-title {
                font-size: 2rem;
                color: #667eea;
                border-bottom: 3px solid #667eea;
                padding-bottom: 10px;
                margin-bottom: 20px;
            }
            
            .subsection-title {
                font-size: 1.5rem;
                color: #764ba2;
                margin: 20px 0 10px 0;
            }
            
            .stats-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                gap: 20px;
                margin: 20px 0;
            }
            
            .stat-card {
                background: #f8f9fa;
                border: 2px solid #e9ecef;
                border-radius: 15px;
                padding: 20px;
                text-align: center;
                transition: all 0.3s ease;
            }
            
            .stat-name {
                font-size: 1.1rem;
                color: #667eea;
                font-weight: bold;
                margin-bottom: 10px;
            }
            
            .stat-value {
                font-size: 2rem;
                color: #764ba2;
                font-weight: bold;
            }
            
            .stat-description {
                font-size: 0.9rem;
                color: #666;
                margin-top: 10px;
            }
            
            .skill-list {
                display: grid;
                gap: 15px;
                margin: 20px 0;
            }
            
            .skill-card {
                background: #f8f9fa;
                border-left: 5px solid #667eea;
                border-radius: 10px;
                padding: 20px;
            }
            
            .skill-name {
                font-size: 1.3rem;
                color: #667eea;
                font-weight: bold;
                margin-bottom: 10px;
            }
            
            .skill-type {
                background: #667eea;
                color: white;
                padding: 4px 12px;
                border-radius: 15px;
                font-size: 0.9rem;
                display: inline-block;
                margin-bottom: 10px;
            }
            
            .skill-description {
                color: #555;
                line-height: 1.5;
            }
            
            .retrograde-section {
                background: linear-gradient(135deg, rgba(255, 107, 107, 0.1) 0%, rgba(254, 202, 87, 0.1) 100%);
                border: 2px solid rgba(255, 107, 107, 0.3);
                border-radius: 15px;
                padding: 25px;
                margin: 20px 0;
            }
            
            .fantasy-section {
                background: linear-gradient(135deg, rgba(118, 75, 162, 0.1) 0%, rgba(102, 126, 234, 0.1) 100%);
                border: 2px solid rgba(118, 75, 162, 0.3);
                border-radius: 15px;
                padding: 25px;
                margin: 20px 0;
            }
            
            .info-box {
                background: #e3f2fd;
                border-left: 5px solid #2196f3;
                padding: 15px;
                margin: 15px 0;
                border-radius: 5px;
            }
            
            .warning-box {
                background: #fff3e0;
                border-left: 5px solid #ff9800;
                padding: 15px;
                margin: 15px 0;
                border-radius: 5px;
            }
            
            .success-box {
                background: #e8f5e8;
                border-left: 5px solid #4caf50;
                padding: 15px;
                margin: 15px 0;
                border-radius: 5px;
            }
            
            .table-of-contents {
                background: #f8f9fa;
                border-radius: 15px;
                padding: 30px;
                margin-bottom: 40px;
            }
            
            .toc-title {
                font-size: 1.5rem;
                color: #667eea;
                margin-bottom: 20px;
                text-align: center;
            }
            
            .toc-list {
                list-style: none;
                padding: 0;
            }
            
            .toc-item {
                padding: 8px 0;
                border-bottom: 1px dotted #ddd;
                display: flex;
                justify-content: space-between;
            }
            
            .toc-item:last-child {
                border-bottom: none;
            }
            
            .page-break {
                page-break-before: always;
            }
            
            .text-center {
                text-align: center;
            }
            
            .text-right {
                text-align: right;
            }
            
            .mb-20 {
                margin-bottom: 20px;
            }
            
            .mt-20 {
                margin-top: 20px;
            }
            
            .highlight {
                background: linear-gradient(120deg, #a8edea 0%, #fed6e3 100%);
                padding: 2px 6px;
                border-radius: 4px;
            }
            
            @media print {
                .report-container {
                    padding: 20px;
                }
                
                .cover-page {
                    padding: 60px 0;
                }
                
                .section {
                    page-break-inside: avoid;
                }
            }
        `;
    }

    /**
     * 生成封面頁
     * @param {Object} reportData - 報告數據
     * @returns {string} HTML內容
     */
    generateCoverPage(reportData) {
        const { character, generatedAt, reportId } = reportData;
        
        return `
            <div class="cover-page">
                <h1 class="cover-title">🌟 虹靈御所</h1>
                <p class="cover-subtitle">占星角色分析報告</p>
                <div class="character-name-cover">${character.name}</div>
                <div class="report-info">
                    <p>報告編號: ${reportId}</p>
                    <p>生成時間: ${generatedAt}</p>
                    <p>職業: ${character.class.name || character.class.primary}</p>
                    <p>評級: ${character.totalScore.grade}</p>
                    ${character.totalScore.rarity ? `<p>稀有度: ${character.totalScore.rarity}</p>` : ''}
                </div>
            </div>
        `;
    }

    /**
     * 生成目錄
     * @returns {string} HTML內容
     */
    generateTableOfContents() {
        const sections = [
            { title: '1. 角色概覽', page: '3' },
            { title: '2. 占星分析', page: '4' },
            { title: '3. 屬性詳解', page: '5' },
            { title: '4. 技能分析', page: '6' },
            { title: '5. 逆行影響', page: '7' },
            { title: '6. 職業指導', page: '8' },
            { title: '7. 關係相容性', page: '9' },
            { title: '8. 人生路徑指引', page: '10' },
            { title: '9. 奇幻元素', page: '11' },
            { title: '10. 附錄', page: '12' }
        ];

        return `
            <div class="table-of-contents page-break">
                <h2 class="toc-title">📋 目錄</h2>
                <ul class="toc-list">
                    ${sections.map(section => `
                        <li class="toc-item">
                            <span>${section.title}</span>
                            <span>第 ${section.page} 頁</span>
                        </li>
                    `).join('')}
                </ul>
            </div>
        `;
    }

    /**
     * 生成角色概覽
     * @param {Object} reportData - 報告數據
     * @returns {string} HTML內容
     */
    generateCharacterOverview(reportData) {
        const { character } = reportData;
        
        return `
            <div class="section page-break">
                <h2 class="section-title">1. 角色概覽</h2>
                
                <div class="info-box">
                    <h3>基本信息</h3>
                    <p><strong>角色名稱：</strong>${character.name}</p>
                    <p><strong>職業：</strong>${character.class.name || character.class.primary}</p>
                    <p><strong>職業描述：</strong>${character.class.description}</p>
                    <p><strong>總體評級：</strong>${character.totalScore.grade}</p>
                    ${character.totalScore.rarity ? `<p><strong>稀有度：</strong>${character.totalScore.rarity}</p>` : ''}
                </div>

                <h3 class="subsection-title">角色特色</h3>
                <div class="success-box">
                    ${typeof character.description === 'string' ? 
                        `<p>${character.description}</p>` : 
                        `
                        ${character.description.summary ? `<p><strong>總結：</strong>${character.description.summary}</p>` : ''}
                        ${character.description.personality ? `<p><strong>性格：</strong>${character.description.personality}</p>` : ''}
                        ${character.description.classEvolution ? `<p><strong>職業進化：</strong>${character.description.classEvolution}</p>` : ''}
                        `
                    }
                </div>

                <h3 class="subsection-title">屬性總覽</h3>
                <p>總屬性點數：<span class="highlight">${character.totalScore.total}</span></p>
                <p>平均屬性：<span class="highlight">${character.totalScore.average}</span></p>
            </div>
        `;
    }

    /**
     * 生成占星分析
     * @param {Object} reportData - 報告數據
     * @returns {string} HTML內容
     */
    generateAstrologicalAnalysis(reportData) {
        const { chartData, character } = reportData;
        
        if (!chartData || !chartData.planets) {
            return `
                <div class="section page-break">
                    <h2 class="section-title">2. 占星分析</h2>
                    <div class="info-box">
                        <p>此角色使用手動輸入模式生成，占星分析基於輸入的星座配置。</p>
                    </div>
                </div>
            `;
        }

        const planetCount = Object.keys(chartData.planets).length;
        const retrogradeCount = Object.values(chartData.planets).filter(p => p.retrograde).length;

        return `
            <div class="section page-break">
                <h2 class="section-title">2. 占星分析</h2>
                
                <h3 class="subsection-title">星盤概況</h3>
                <div class="info-box">
                    <p><strong>行星總數：</strong>${planetCount}</p>
                    <p><strong>逆行行星：</strong>${retrogradeCount}</p>
                    <p><strong>計算時間：</strong>${chartData.calculatedAt ? new Date(chartData.calculatedAt).toLocaleString('zh-TW') : '未知'}</p>
                </div>

                <h3 class="subsection-title">主要行星配置</h3>
                <div class="stats-grid">
                    ${Object.entries(chartData.planets).slice(0, 6).map(([planet, data]) => `
                        <div class="stat-card">
                            <div class="stat-name">${this.getPlanetName(planet)}</div>
                            <div class="stat-value">${this.getSignName(data.sign)}</div>
                            <div class="stat-description">
                                第${data.house}宮
                                ${data.retrograde ? '<br><span style="color: #ff6b6b;">⚡ 逆行</span>' : ''}
                            </div>
                        </div>
                    `).join('')}
                </div>

                ${character.birthInfo ? `
                    <h3 class="subsection-title">出生信息</h3>
                    <div class="info-box">
                        <p><strong>出生日期：</strong>${character.birthInfo.date}</p>
                        <p><strong>出生時間：</strong>${character.birthInfo.time}</p>
                        <p><strong>出生地點：</strong>${character.birthInfo.location}</p>
                        <p><strong>時區：</strong>${character.birthInfo.timezone}</p>
                    </div>
                ` : ''}
            </div>
        `;
    }

    /**
     * 生成屬性詳解
     * @param {Object} reportData - 報告數據
     * @returns {string} HTML內容
     */
    generateAttributeBreakdown(reportData) {
        const { character } = reportData;
        
        const statNames = {
            charisma: '魅力',
            perception: '感知',
            intelligence: '智力',
            dexterity: '敏捷',
            strength: '力量',
            constitution: '體質',
            wisdom: '智慧',
            willpower: '意志力',
            intuition: '直覺'
        };

        const statDescriptions = {
            charisma: '領導力、說服力、社交能力的體現',
            perception: '直覺力、洞察力、情感敏感度的表現',
            intelligence: '學習能力、分析能力、記憶力的展現',
            dexterity: '反應速度、靈活性、技巧性的體現',
            strength: '意志力、執行力、堅持力的表現',
            constitution: '耐力、穩定性、抗壓能力的展現',
            wisdom: '人生智慧、判斷力、洞察力的體現',
            willpower: '內在意志、自制力、決心的表現',
            intuition: '直覺感知、靈感、第六感的體現'
        };

        return `
            <div class="section page-break">
                <h2 class="section-title">3. 屬性詳解</h2>
                
                <div class="stats-grid">
                    ${Object.entries(character.stats)
                        .filter(([key]) => statNames[key])
                        .sort(([,a], [,b]) => b - a)
                        .map(([key, value]) => `
                        <div class="stat-card">
                            <div class="stat-name">${statNames[key]}</div>
                            <div class="stat-value">${Math.round(value)}</div>
                            <div class="stat-description">${statDescriptions[key]}</div>
                        </div>
                    `).join('')}
                </div>

                <h3 class="subsection-title">屬性分析</h3>
                ${this.generateAttributeAnalysis(character.stats)}
            </div>
        `;
    }

    /**
     * 生成屬性分析
     * @param {Object} stats - 屬性數據
     * @returns {string} HTML內容
     */
    generateAttributeAnalysis(stats) {
        const sortedStats = Object.entries(stats)
            .filter(([key]) => ['charisma', 'perception', 'intelligence', 'dexterity', 'strength', 'constitution', 'wisdom'].includes(key))
            .sort(([,a], [,b]) => b - a);

        const highest = sortedStats[0];
        const lowest = sortedStats[sortedStats.length - 1];

        const statNames = {
            charisma: '魅力',
            perception: '感知',
            intelligence: '智力',
            dexterity: '敏捷',
            strength: '力量',
            constitution: '體質',
            wisdom: '智慧'
        };

        return `
            <div class="success-box">
                <h4>優勢屬性</h4>
                <p>你的最強屬性是<span class="highlight">${statNames[highest[0]]}</span>（${Math.round(highest[1])}點），這表示你在相關領域有天賦優勢。</p>
            </div>

            ${lowest[1] < 20 ? `
                <div class="warning-box">
                    <h4>發展空間</h4>
                    <p>你的<span class="highlight">${statNames[lowest[0]]}</span>（${Math.round(lowest[1])}點）相對較弱，可以通過練習和學習來提升。</p>
                </div>
            ` : ''}

            <div class="info-box">
                <h4>平衡建議</h4>
                <p>建議在發揮優勢的同時，也要注意全面發展，創造更均衡的能力組合。</p>
            </div>
        `;
    }

    /**
     * 生成技能分析
     * @param {Object} reportData - 報告數據
     * @returns {string} HTML內容
     */
    generateSkillAnalysis(reportData) {
        const { character } = reportData;
        
        return `
            <div class="section page-break">
                <h2 class="section-title">4. 技能分析</h2>
                
                <div class="skill-list">
                    ${character.skills.map(skill => `
                        <div class="skill-card">
                            <div class="skill-name">${skill.icon || ''} ${skill.name}</div>
                            <div class="skill-type">${skill.type}</div>
                            <div class="skill-description">${skill.description}</div>
                            ${skill.value ? `<p><strong>技能等級：</strong>${skill.value}</p>` : ''}
                            ${skill.category ? `<p><strong>技能類別：</strong>${skill.category}</p>` : ''}
                        </div>
                    `).join('')}
                </div>

                <h3 class="subsection-title">技能發展建議</h3>
                <div class="info-box">
                    <p>根據你的屬性配置和職業特性，建議重點發展以下技能：</p>
                    <ul>
                        ${character.skills.slice(0, 3).map(skill => `
                            <li><strong>${skill.name}：</strong>這項技能與你的天賦相符，值得深入發展</li>
                        `).join('')}
                    </ul>
                </div>
            </div>
        `;
    }

    /**
     * 生成逆行影響分析
     * @param {Object} reportData - 報告數據
     * @returns {string} HTML內容
     */
    generateRetrogradeInfluence(reportData) {
        const { retrogradeEffects } = reportData;
        
        if (!retrogradeEffects || retrogradeEffects.retrogradeCount === 0) {
            return `
                <div class="section page-break">
                    <h2 class="section-title">5. 逆行影響</h2>
                    <div class="info-box">
                        <p>你的星盤中沒有逆行行星，這表示你能夠直接而自然地表達各行星的能量。這是一種相對罕見的配置，代表你的能量流動較為順暢。</p>
                    </div>
                </div>
            `;
        }

        return `
            <div class="section page-break">
                <h2 class="section-title">5. 逆行影響</h2>
                
                <div class="retrograde-section">
                    <h3>⚡ 逆行概況</h3>
                    <p><strong>逆行行星數量：</strong>${retrogradeEffects.retrogradeCount}</p>
                    <p>${retrogradeEffects.retrogradeDescription}</p>
                </div>

                ${retrogradeEffects.bonusSkills.length > 0 ? `
                    <h3 class="subsection-title">逆行特殊技能</h3>
                    <div class="skill-list">
                        ${retrogradeEffects.bonusSkills.map(skill => `
                            <div class="skill-card">
                                <div class="skill-name">🌟 ${skill.name}</div>
                                <div class="skill-type">${skill.type}</div>
                                <div class="skill-description">${skill.description}</div>
                                ${skill.bonus ? `<p><strong>技能加成：</strong>+${skill.bonus}</p>` : ''}
                            </div>
                        `).join('')}
                    </div>
                ` : ''}

                <h3 class="subsection-title">逆行影響解讀</h3>
                <div class="warning-box">
                    <h4>理解逆行</h4>
                    <p>逆行行星並非負面影響，而是代表內在化的能量表達方式。這些行星的能量需要更多的內省和個人化的表達方式。</p>
                </div>

                <div class="success-box">
                    <h4>逆行優勢</h4>
                    <p>逆行行星往往賦予個體獨特的洞察力和與眾不同的表達方式，這些特質在適當發展後可以成為強大的個人優勢。</p>
                </div>
            </div>
        `;
    }

    /**
     * 生成職業指導
     * @param {Object} reportData - 報告數據
     * @returns {string} HTML內容
     */
    generateCareerGuidance(reportData) {
        const { character } = reportData;
        
        return `
            <div class="section page-break">
                <h2 class="section-title">6. 職業指導</h2>
                
                <h3 class="subsection-title">當前職業分析</h3>
                <div class="info-box">
                    <p><strong>職業：</strong>${character.class.name || character.class.primary}</p>
                    <p><strong>職業描述：</strong>${character.class.description}</p>
                    ${character.class.element ? `<p><strong>元素屬性：</strong>${character.class.element}</p>` : ''}
                    ${character.class.type ? `<p><strong>職業類型：</strong>${character.class.type}</p>` : ''}
                </div>

                <h3 class="subsection-title">職業發展建議</h3>
                <div class="success-box">
                    <h4>核心優勢</h4>
                    <p>基於你的屬性配置，你在以下領域具有天然優勢：</p>
                    <ul>
                        ${character.class.primaryAttributes ? character.class.primaryAttributes.map(attr => `
                            <li>${this.getAttributeName(attr)}相關的工作和活動</li>
                        `).join('') : '<li>根據你的最高屬性發展相關技能</li>'}
                    </ul>
                </div>

                <h3 class="subsection-title">職業路徑建議</h3>
                <div class="info-box">
                    <h4>短期目標（1-2年）</h4>
                    <ul>
                        <li>專精當前職業的核心技能</li>
                        <li>建立相關的人際網絡</li>
                        <li>累積實戰經驗</li>
                    </ul>
                    
                    <h4>中期目標（3-5年）</h4>
                    <ul>
                        <li>發展跨領域技能</li>
                        <li>尋求領導或專家角色</li>
                        <li>建立個人品牌</li>
                    </ul>
                    
                    <h4>長期願景（5年以上）</h4>
                    <ul>
                        <li>成為領域內的權威</li>
                        <li>指導和培養後進</li>
                        <li>創新和突破傳統</li>
                    </ul>
                </div>
            </div>
        `;
    }

    /**
     * 生成關係相容性分析
     * @param {Object} reportData - 報告數據
     * @returns {string} HTML內容
     */
    generateRelationshipCompatibility(reportData) {
        const { character } = reportData;
        
        return `
            <div class="section page-break">
                <h2 class="section-title">7. 關係相容性</h2>
                
                <h3 class="subsection-title">人際關係特質</h3>
                <div class="info-box">
                    <p>基於你的魅力屬性（${Math.round(character.stats.charisma || 0)}）和感知屬性（${Math.round(character.stats.perception || 0)}），你在人際關係中的表現：</p>
                </div>

                ${this.generateRelationshipAnalysis(character.stats)}

                <h3 class="subsection-title">團隊合作建議</h3>
                <div class="success-box">
                    <h4>理想團隊角色</h4>
                    <p>根據你的職業和屬性配置，你在團隊中最適合擔任：</p>
                    <ul>
                        ${this.getTeamRoles(character)}
                    </ul>
                </div>

                <h3 class="subsection-title">溝通風格</h3>
                <div class="info-box">
                    ${this.getCommunicationStyle(character.stats)}
                </div>
            </div>
        `;
    }

    /**
     * 生成人生路徑指引
     * @param {Object} reportData - 報告數據
     * @returns {string} HTML內容
     */
    generateLifePathGuidance(reportData) {
        const { character } = reportData;
        
        return `
            <div class="section page-break">
                <h2 class="section-title">8. 人生路徑指引</h2>
                
                <h3 class="subsection-title">人生主題</h3>
                <div class="success-box">
                    ${character.description.destinyPath ? `
                        <p>${character.description.destinyPath}</p>
                    ` : `
                        <p>作為${character.class.name || character.class.primary}，你的人生主題圍繞著${character.class.description}。</p>
                    `}
                </div>

                <h3 class="subsection-title">成長階段</h3>
                <div class="info-box">
                    <h4>🌱 探索期（20-30歲）</h4>
                    <p>這個階段重點在於發現自己的天賦和興趣，建立基礎技能和人際網絡。</p>
                    
                    <h4>🌿 發展期（30-45歲）</h4>
                    <p>專精於選定的領域，建立專業聲譽，承擔更多責任和挑戰。</p>
                    
                    <h4>🌳 成熟期（45-60歲）</h4>
                    <p>發揮領導作用，傳承經驗，在更廣闊的平台上發揮影響力。</p>
                    
                    <h4>🍃 智慧期（60歲以上）</h4>
                    <p>分享人生智慧，指導後進，享受成果並持續學習。</p>
                </div>

                <h3 class="subsection-title">人生建議</h3>
                <div class="warning-box">
                    <h4>需要注意的挑戰</h4>
                    ${this.getLifeChallenges(character)}
                </div>

                <div class="success-box">
                    <h4>發展機會</h4>
                    ${this.getLifeOpportunities(character)}
                </div>
            </div>
        `;
    }

    /**
     * 生成奇幻元素
     * @param {Object} reportData - 報告數據
     * @returns {string} HTML內容
     */
    generateFantasyElements(reportData) {
        const { character } = reportData;
        
        if (!character.fantasyElements) {
            return `
                <div class="section page-break">
                    <h2 class="section-title">9. 奇幻元素</h2>
                    <div class="info-box">
                        <p>此角色使用基礎模式生成，未包含奇幻元素。</p>
                    </div>
                </div>
            `;
        }

        return `
            <div class="section page-break">
                <h2 class="section-title">9. 奇幻元素</h2>
                
                <div class="fantasy-section">
                    <h3>✨ 神秘特質</h3>
                    
                    ${character.fantasyElements.aura ? `
                        <h4>🌟 個人光環</h4>
                        <p><strong>顏色：</strong>${character.fantasyElements.aura.color}</p>
                        <p><strong>效果：</strong>${character.fantasyElements.aura.effect}</p>
                        <p><strong>強度：</strong>${character.fantasyElements.aura.intensity}/10</p>
                    ` : ''}

                    ${character.fantasyElements.constellation ? `
                        <h4>⭐ 守護星座</h4>
                        <p>${character.fantasyElements.constellation}</p>
                        <p>這個星座為你提供特殊的宇宙能量加持。</p>
                    ` : ''}

                    ${character.fantasyElements.companionSpirit ? `
                        <h4>🐾 守護靈</h4>
                        <p><strong>名稱：</strong>${character.fantasyElements.companionSpirit.name}</p>
                        <p><strong>類型：</strong>${character.fantasyElements.companionSpirit.type}</p>
                        <p><strong>特殊能力：</strong>${character.fantasyElements.companionSpirit.ability}</p>
                    ` : ''}

                    ${character.fantasyElements.magicalItems && character.fantasyElements.magicalItems.length > 0 ? `
                        <h4>🔮 魔法物品</h4>
                        ${character.fantasyElements.magicalItems.map(item => `
                            <div class="skill-card">
                                <div class="skill-name">${item.name}</div>
                                <div class="skill-type">${item.type}</div>
                                <div class="skill-description">${item.effect}</div>
                            </div>
                        `).join('')}
                    ` : ''}
                </div>

                <h3 class="subsection-title">奇幻世界中的你</h3>
                <div class="info-box">
                    <p>在奇幻世界中，你將是一個獨特而強大的存在。你的特殊能力和神秘特質讓你在冒險中脫穎而出，成為傳說中的英雄。</p>
                </div>
            </div>
        `;
    }

    /**
     * 生成附錄
     * @param {Object} reportData - 報告數據
     * @returns {string} HTML內容
     */
    generateAppendix(reportData) {
        const { reportId, generatedAt } = reportData;
        
        return `
            <div class="section page-break">
                <h2 class="section-title">10. 附錄</h2>
                
                <h3 class="subsection-title">報告說明</h3>
                <div class="info-box">
                    <p>本報告由虹靈御所占星主角生成系統自動生成，結合了傳統占星學理論和現代RPG角色設計概念。</p>
                    <p>報告內容僅供娛樂和自我探索參考，不應作為人生重大決策的唯一依據。</p>
                </div>

                <h3 class="subsection-title">技術信息</h3>
                <div class="info-box">
                    <p><strong>報告編號：</strong>${reportId}</p>
                    <p><strong>生成時間：</strong>${generatedAt}</p>
                    <p><strong>系統版本：</strong>Enhanced v3.0</p>
                    <p><strong>計算引擎：</strong>虹靈御所占星引擎</p>
                </div>

                <h3 class="subsection-title">免責聲明</h3>
                <div class="warning-box">
                    <p>本報告基於占星學理論和算法生成，內容僅供參考。個人的成長和發展受多種因素影響，包括但不限於個人努力、環境因素、機遇等。</p>
                    <p>使用者應理性看待報告內容，結合實際情況做出判斷和決策。</p>
                </div>

                <div class="text-center mt-20">
                    <p><strong>🌟 感謝使用虹靈御所占星主角生成系統 🌟</strong></p>
                    <p>願星辰指引你的人生道路</p>
                </div>
            </div>
        `;
    }

    // 輔助方法

    /**
     * 生成報告ID
     * @returns {string} 報告ID
     */
    generateReportId() {
        const timestamp = Date.now().toString(36);
        const random = Math.random().toString(36).substr(2, 5);
        return `RPT-${timestamp}-${random}`.toUpperCase();
    }

    /**
     * 獲取行星名稱
     * @param {string} planet - 行星英文名
     * @returns {string} 行星中文名
     */
    getPlanetName(planet) {
        const names = {
            sun: '太陽',
            moon: '月亮',
            mercury: '水星',
            venus: '金星',
            mars: '火星',
            jupiter: '木星',
            saturn: '土星',
            uranus: '天王星',
            neptune: '海王星',
            pluto: '冥王星',
            chiron: '凱龍星',
            ceres: '穀神星'
        };
        return names[planet] || planet;
    }

    /**
     * 獲取星座名稱
     * @param {string} sign - 星座英文名
     * @returns {string} 星座中文名
     */
    getSignName(sign) {
        const names = {
            aries: '牡羊座',
            taurus: '金牛座',
            gemini: '雙子座',
            cancer: '巨蟹座',
            leo: '獅子座',
            virgo: '處女座',
            libra: '天秤座',
            scorpio: '天蠍座',
            sagittarius: '射手座',
            capricorn: '摩羯座',
            aquarius: '水瓶座',
            pisces: '雙魚座'
        };
        return names[sign] || sign;
    }

    /**
     * 獲取屬性名稱
     * @param {string} attr - 屬性英文名
     * @returns {string} 屬性中文名
     */
    getAttributeName(attr) {
        const names = {
            charisma: '魅力',
            perception: '感知',
            intelligence: '智力',
            dexterity: '敏捷',
            strength: '力量',
            constitution: '體質',
            wisdom: '智慧'
        };
        return names[attr] || attr;
    }

    /**
     * 生成關係分析
     * @param {Object} stats - 屬性數據
     * @returns {string} HTML內容
     */
    generateRelationshipAnalysis(stats) {
        const charisma = stats.charisma || 0;
        const perception = stats.perception || 0;

        if (charisma >= 25 && perception >= 25) {
            return `
                <div class="success-box">
                    <p>你具有出色的人際交往能力，既能吸引他人，又能敏銳地察覺他人的需求和情感。</p>
                </div>
            `;
        } else if (charisma >= 25) {
            return `
                <div class="success-box">
                    <p>你具有強大的個人魅力，容易成為團體的焦點，但需要提升對他人情感的敏感度。</p>
                </div>
            `;
        } else if (perception >= 25) {
            return `
                <div class="success-box">
                    <p>你對他人的情感和需求非常敏感，是很好的傾聽者，但可能需要更主動地表達自己。</p>
                </div>
            `;
        } else {
            return `
                <div class="info-box">
                    <p>你在人際關係中較為內斂，偏好深度而非廣度的交往方式。</p>
                </div>
            `;
        }
    }

    /**
     * 獲取團隊角色
     * @param {Object} character - 角色數據
     * @returns {string} HTML內容
     */
    getTeamRoles(character) {
        const roles = [];
        const stats = character.stats;

        if (stats.charisma >= 25) roles.push('<li>團隊領導者或協調者</li>');
        if (stats.intelligence >= 25) roles.push('<li>策略規劃者或分析師</li>');
        if (stats.perception >= 25) roles.push('<li>團隊情感支持者</li>');
        if (stats.strength >= 25) roles.push('<li>執行者或推動者</li>');
        if (stats.dexterity >= 25) roles.push('<li>靈活應變的執行者</li>');

        return roles.length > 0 ? roles.join('') : '<li>穩定可靠的團隊成員</li>';
    }

    /**
     * 獲取溝通風格
     * @param {Object} stats - 屬性數據
     * @returns {string} HTML內容
     */
    getCommunicationStyle(stats) {
        if (stats.charisma >= 25 && stats.intelligence >= 25) {
            return '<p>你的溝通風格兼具說服力和邏輯性，能夠有效地傳達複雜的想法。</p>';
        } else if (stats.charisma >= 25) {
            return '<p>你的溝通風格富有感染力，善於激勵他人，但需要注意邏輯的嚴謹性。</p>';
        } else if (stats.intelligence >= 25) {
            return '<p>你的溝通風格注重邏輯和事實，但可能需要增加情感的表達。</p>';
        } else {
            return '<p>你的溝通風格較為直接和真誠，偏好實質性的對話。</p>';
        }
    }

    /**
     * 獲取人生挑戰
     * @param {Object} character - 角色數據
     * @returns {string} HTML內容
     */
    getLifeChallenges(character) {
        const challenges = [];
        const stats = character.stats;

        const sortedStats = Object.entries(stats)
            .filter(([key]) => ['charisma', 'perception', 'intelligence', 'dexterity', 'strength', 'constitution'].includes(key))
            .sort(([,a], [,b]) => a - b);

        const weakest = sortedStats[0];
        const statNames = {
            charisma: '魅力',
            perception: '感知',
            intelligence: '智力',
            dexterity: '敏捷',
            strength: '力量',
            constitution: '體質'
        };

        if (weakest[1] < 20) {
            challenges.push(`<li>需要加強${statNames[weakest[0]]}相關的能力發展</li>`);
        }

        if (character.retrogradeEffects && character.retrogradeEffects.retrogradeCount > 0) {
            challenges.push('<li>需要學會將內在的逆行能量轉化為優勢</li>');
        }

        challenges.push('<li>保持各項能力的平衡發展</li>');

        return `<ul>${challenges.join('')}</ul>`;
    }

    /**
     * 獲取人生機會
     * @param {Object} character - 角色數據
     * @returns {string} HTML內容
     */
    getLifeOpportunities(character) {
        const opportunities = [];
        const stats = character.stats;

        const sortedStats = Object.entries(stats)
            .filter(([key]) => ['charisma', 'perception', 'intelligence', 'dexterity', 'strength', 'constitution'].includes(key))
            .sort(([,a], [,b]) => b - a);

        const strongest = sortedStats[0];
        const statNames = {
            charisma: '魅力',
            perception: '感知',
            intelligence: '智力',
            dexterity: '敏捷',
            strength: '力量',
            constitution: '體質'
        };

        opportunities.push(`<li>充分發揮你的${statNames[strongest[0]]}優勢</li>`);

        if (character.class.element) {
            opportunities.push(`<li>在${character.class.element}元素相關的領域尋求發展</li>`);
        }

        if (character.retrogradeEffects && character.retrogradeEffects.retrogradeCount > 0) {
            opportunities.push('<li>你的獨特視角可能成為創新的源泉</li>');
        }

        opportunities.push('<li>建立與你的職業和天賦相符的人際網絡</li>');

        return `<ul>${opportunities.join('')}</ul>`;
    }
}

// 導出模塊
window.PDFReportGenerator = PDFReportGenerator;


/**
 * 🌟 虹靈御所占星主角生成系統 - UI控制器
 * 處理用戶界面交互和結果展示
 */

class UIController {
    constructor() {
        this.characterGenerator = new CharacterGenerator();
        this.init();
    }

    init() {
        this.createStars();
        this.bindEvents();
        this.setupFormValidation();
    }

    /**
     * 創建星空背景
     */
    createStars() {
        const starsContainer = document.getElementById('stars');
        const starCount = 200;
        
        for (let i = 0; i < starCount; i++) {
            const star = document.createElement('div');
            star.className = 'star';
            star.style.left = Math.random() * 100 + '%';
            star.style.top = Math.random() * 100 + '%';
            star.style.animationDelay = Math.random() * 3 + 's';
            star.style.animationDuration = (Math.random() * 3 + 2) + 's';
            starsContainer.appendChild(star);
        }
    }

    /**
     * 綁定事件監聽器
     */
    bindEvents() {
        const form = document.getElementById('characterForm');
        form.addEventListener('submit', (e) => this.handleFormSubmit(e));

        // 實時驗證
        const requiredFields = ['sun', 'moon', 'mercury', 'venus', 'mars', 'jupiter'];
        requiredFields.forEach(field => {
            const element = document.getElementById(field);
            if (element) {
                element.addEventListener('change', () => this.validateForm());
            }
        });
    }

    /**
     * 設置表單驗證
     */
    setupFormValidation() {
        const form = document.getElementById('characterForm');
        const inputs = form.querySelectorAll('input[required], select[required]');
        
        inputs.forEach(input => {
            input.addEventListener('blur', () => {
                this.validateField(input);
            });
            
            input.addEventListener('input', () => {
                this.clearFieldError(input);
            });
        });
    }

    /**
     * 驗證單個字段
     */
    validateField(field) {
        const value = field.value.trim();
        const isValid = value !== '';
        
        if (!isValid) {
            this.showFieldError(field, '此欄位為必填');
        } else {
            this.clearFieldError(field);
        }
        
        return isValid;
    }

    /**
     * 顯示字段錯誤
     */
    showFieldError(field, message) {
        this.clearFieldError(field);
        
        field.style.borderColor = '#ff6b6b';
        field.style.boxShadow = '0 0 10px rgba(255, 107, 107, 0.3)';
        
        const errorDiv = document.createElement('div');
        errorDiv.className = 'field-error';
        errorDiv.style.color = '#ff6b6b';
        errorDiv.style.fontSize = '0.8em';
        errorDiv.style.marginTop = '5px';
        errorDiv.textContent = message;
        
        field.parentNode.appendChild(errorDiv);
    }

    /**
     * 清除字段錯誤
     */
    clearFieldError(field) {
        field.style.borderColor = '';
        field.style.boxShadow = '';
        
        const errorDiv = field.parentNode.querySelector('.field-error');
        if (errorDiv) {
            errorDiv.remove();
        }
    }

    /**
     * 驗證整個表單
     */
    validateForm() {
        const form = document.getElementById('characterForm');
        const requiredFields = form.querySelectorAll('input[required], select[required]');
        let isValid = true;
        
        requiredFields.forEach(field => {
            if (!this.validateField(field)) {
                isValid = false;
            }
        });
        
        return isValid;
    }

    /**
     * 處理表單提交
     */
    async handleFormSubmit(event) {
        event.preventDefault();
        
        // 驗證表單
        if (!this.validateForm()) {
            this.showError(['請填寫所有必填欄位']);
            return;
        }

        // 顯示載入狀態
        this.showLoading();
        
        try {
            // 收集表單數據
            const formData = this.collectFormData();
            
            // 生成角色
            const result = await this.generateCharacterAsync(formData);
            
            if (result.success) {
                this.displayCharacter(result.character);
            } else {
                this.showError(result.errors);
            }
        } catch (error) {
            console.error('生成角色時發生錯誤:', error);
            this.showError(['系統發生錯誤，請稍後再試']);
        } finally {
            this.hideLoading();
        }
    }

    /**
     * 收集表單數據
     */
    collectFormData() {
        const form = document.getElementById('characterForm');
        const formData = new FormData(form);
        const data = {};
        
        for (let [key, value] of formData.entries()) {
            if (value.trim() !== '') {
                data[key] = value.trim();
            }
        }
        
        return data;
    }

    /**
     * 異步生成角色（模擬計算時間）
     */
    async generateCharacterAsync(formData) {
        // 模擬計算時間
        await new Promise(resolve => setTimeout(resolve, 1500));
        
        return this.characterGenerator.generateCharacter(formData);
    }

    /**
     * 顯示載入狀態
     */
    showLoading() {
        const button = document.querySelector('.generate-btn');
        const btnText = button.querySelector('.btn-text');
        const btnLoading = button.querySelector('.btn-loading');
        
        button.disabled = true;
        btnText.style.display = 'none';
        btnLoading.style.display = 'flex';
        
        // 隱藏其他內容
        document.getElementById('emptyState').style.display = 'none';
        document.getElementById('characterCard').style.display = 'none';
        document.getElementById('errorMessage').style.display = 'none';
    }

    /**
     * 隱藏載入狀態
     */
    hideLoading() {
        const button = document.querySelector('.generate-btn');
        const btnText = button.querySelector('.btn-text');
        const btnLoading = button.querySelector('.btn-loading');
        
        button.disabled = false;
        btnText.style.display = 'block';
        btnLoading.style.display = 'none';
    }

    /**
     * 顯示錯誤訊息
     */
    showError(errors) {
        const errorContainer = document.getElementById('errorMessage');
        const emptyState = document.getElementById('emptyState');
        const characterCard = document.getElementById('characterCard');
        
        emptyState.style.display = 'none';
        characterCard.style.display = 'none';
        
        errorContainer.innerHTML = `
            <h3>⚠️ 發生錯誤</h3>
            <ul>
                ${errors.map(error => `<li>${error}</li>`).join('')}
            </ul>
        `;
        
        errorContainer.style.display = 'block';
        
        // 滾動到錯誤訊息
        errorContainer.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    /**
     * 顯示角色結果
     */
    displayCharacter(character) {
        const characterCard = document.getElementById('characterCard');
        const emptyState = document.getElementById('emptyState');
        const errorMessage = document.getElementById('errorMessage');
        
        emptyState.style.display = 'none';
        errorMessage.style.display = 'none';
        
        characterCard.innerHTML = this.generateCharacterHTML(character);
        characterCard.style.display = 'block';
        
        // 滾動到結果
        characterCard.scrollIntoView({ behavior: 'smooth', block: 'start' });
        
        // 綁定統計卡片事件
        this.bindStatCardEvents();
    }

    /**
     * 生成角色HTML
     */
    generateCharacterHTML(character) {
        return `
            <div class="character-header">
                <div class="character-name">${character.name}</div>
                <div class="character-class">${character.class.primary}</div>
                <div class="character-title">${character.class.description}</div>
                <div class="character-grade">總體評級: ${character.totalScore.grade}</div>
            </div>

            <div class="stats-container">
                <div class="stats-title">⚔️ 角色屬性</div>
                <div class="stats-grid">
                    ${this.generateStatsHTML(character.stats, character.breakdown)}
                </div>
            </div>

            <div class="skills-container">
                <div class="skill-section">
                    <div class="skill-title">🌟 主要技能</div>
                    ${this.generateSkillsHTML(character.skills.filter(skill => skill.category === 'primary'))}
                </div>
                <div class="skill-section">
                    <div class="skill-title">✨ 特殊技能</div>
                    ${this.generateSkillsHTML(character.skills.filter(skill => skill.category !== 'primary'))}
                </div>
            </div>

            <div class="description-container">
                <div class="description-title">📜 角色描述</div>
                <div class="description-text">${character.description.summary}</div>
                
                <div class="description-section">
                    <h4>性格特質</h4>
                    <div class="description-text">${character.description.personality}</div>
                </div>
                
                <div class="description-section">
                    <h4>優勢能力</h4>
                    <ul>
                        ${character.description.strengths.map(strength => `<li>${strength}</li>`).join('')}
                    </ul>
                </div>
                
                ${character.description.challenges.length > 0 ? `
                <div class="description-section">
                    <h4>成長空間</h4>
                    <ul>
                        ${character.description.challenges.map(challenge => `<li>${challenge}</li>`).join('')}
                    </ul>
                </div>
                ` : ''}
                
                <div class="description-section">
                    <h4>發展建議</h4>
                    <ul>
                        ${character.description.recommendations.map(rec => `<li>${rec}</li>`).join('')}
                    </ul>
                </div>
            </div>

            <div class="description-container">
                <div class="description-title">🌌 星盤摘要</div>



                <div class="description-text">
                    元素分布：火${character.birthChart.elements.fire} | 土${character.birthChart.elements.earth} | 風${character.birthChart.elements.air} | 水${character.birthChart.elements.water}
                </div>
                <div class="description-text">
                    模式分布：開創${character.birthChart.modes.cardinal} | 固定${character.birthChart.modes.fixed} | 變動${character.birthChart.modes.mutable}
                </div>
                <div class="description-text">
                    陰陽分布：陽性${character.birthChart.polarities.positive} | 陰性${character.birthChart.polarities.negative}
                </div>
            </div>
        `;
    }

    /**
     * 生成屬性HTML
     */
    generateStatsHTML(stats, breakdown) {
        const statIcons = {
            charisma: '✨',
            perception: '👁️',
            intelligence: '🧠',
            dexterity: '⚡',
            strength: '💪',
            constitution: '🛡️'
        };

        const statNames = {
            charisma: '魅力',
            perception: '感知',
            intelligence: '智力',
            dexterity: '敏捷',
            strength: '力量',
            constitution: '體質'
        };

        return Object.entries(stats).map(([stat, value]) => `
            <div class="stat-card" data-stat="${stat}">
                <div class="stat-icon">${statIcons[stat]}</div>
                <div class="stat-name">${statNames[stat]}</div>
                <div class="stat-value">${value}</div>
                <div class="stat-breakdown">
                    ${breakdown[stat] ? breakdown[stat].map(item => `<div>${item}</div>`).join('') : ''}
                </div>
            </div>
        `).join('');
    }

    /**
     * 生成技能HTML
     */
    generateSkillsHTML(skills) {
        if (!skills || skills.length === 0) {
            return '<div class="skill-item"><div class="skill-label">暫無技能</div></div>';
        }

        return skills.map(skill => `
            <div class="skill-item">
                <div class="skill-label">
                    <span class="skill-icon">${skill.icon}</span>
                    <div>
                        <div class="skill-name">${skill.name}<span class="skill-type">(${skill.type})</span></div>
                        <div class="skill-description">${skill.description}</div>
                    </div>
                </div>
                <div class="skill-value">${skill.value}</div>
            </div>
        `).join('');
    }

    /**
     * 綁定統計卡片事件
     */
    bindStatCardEvents() {
        const statCards = document.querySelectorAll('.stat-card');
        
        statCards.forEach(card => {
            card.addEventListener('click', () => {
                const breakdown = card.querySelector('.stat-breakdown');
                const isExpanded = breakdown.style.maxHeight && breakdown.style.maxHeight !== '0px';
                
                // 收起所有其他卡片
                statCards.forEach(otherCard => {
                    if (otherCard !== card) {
                        const otherBreakdown = otherCard.querySelector('.stat-breakdown');
                        otherBreakdown.style.maxHeight = '0px';
                        otherCard.classList.remove('expanded');
                    }
                });
                
                // 切換當前卡片
                if (isExpanded) {
                    breakdown.style.maxHeight = '0px';
                    card.classList.remove('expanded');
                } else {
                    breakdown.style.maxHeight = breakdown.scrollHeight + 'px';
                    card.classList.add('expanded');
                }
            });
        });
    }

    /**
     * 獲取屬性顏色
     */
    getStatColor(value) {
        if (value >= 25) return '#4CAF50'; // 綠色
        if (value >= 20) return '#2196F3'; // 藍色
        if (value >= 15) return '#FF9800'; // 橙色
        return '#9E9E9E'; // 灰色
    }

    /**
     * 格式化數字
     */
    formatNumber(num) {
        return Math.round(num * 10) / 10;
    }

    /**
     * 滾動到元素
     */
    scrollToElement(element, offset = 0) {
        const elementPosition = element.getBoundingClientRect().top + window.pageYOffset;
        const offsetPosition = elementPosition - offset;

        window.scrollTo({
            top: offsetPosition,
            behavior: 'smooth'
        });
    }

    /**
     * 顯示提示訊息
     */
    showToast(message, type = 'info') {
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: ${type === 'error' ? '#f44336' : '#4CAF50'};
            color: white;
            padding: 15px 20px;
            border-radius: 10px;
            z-index: 1000;
            animation: slideIn 0.3s ease-out;
        `;
        toast.textContent = message;

        document.body.appendChild(toast);

        setTimeout(() => {
            toast.style.animation = 'slideOut 0.3s ease-out';
            setTimeout(() => {
                document.body.removeChild(toast);
            }, 300);
        }, 3000);
    }

    /**
     * 重置表單
     */
    resetForm() {
        const form = document.getElementById('characterForm');
        form.reset();
        
        // 清除所有錯誤
        const errorDivs = form.querySelectorAll('.field-error');
        errorDivs.forEach(div => div.remove());
        
        // 重置樣式
        const fields = form.querySelectorAll('input, select');
        fields.forEach(field => {
            field.style.borderColor = '';
            field.style.boxShadow = '';
        });
        
        // 顯示空狀態
        document.getElementById('emptyState').style.display = 'block';
        document.getElementById('characterCard').style.display = 'none';
        document.getElementById('errorMessage').style.display = 'none';
    }

    /**
     * 導出角色數據
     */
    exportCharacter(character) {
        const data = {
            timestamp: new Date().toISOString(),
            character: character
        };
        
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        
        const a = document.createElement('a');
        a.href = url;
        a.download = `${character.name}_角色卡.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        
        URL.revokeObjectURL(url);
        this.showToast('角色數據已導出');
    }

    /**
     * 分享角色
     */
    shareCharacter(character) {
        const shareText = `我在虹靈御所占星系統中生成了角色：${character.name}（${character.class.primary}）！總體評級：${character.totalScore.grade}`;
        
        if (navigator.share) {
            navigator.share({
                title: '虹靈御所占星角色',
                text: shareText,
                url: window.location.href
            });
        } else {
            // 複製到剪貼板
            navigator.clipboard.writeText(shareText).then(() => {
                this.showToast('角色信息已複製到剪貼板');
            });
        }
    }
}

// 添加CSS動畫
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    
    @keyframes slideOut {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(100%); opacity: 0; }
    }
    
    .stat-card.expanded {
        background: linear-gradient(135deg, rgba(102, 126, 234, 0.3), rgba(118, 75, 162, 0.3));
    }
    
    .stat-breakdown {
        transition: max-height 0.3s ease-out;
    }
`;
document.head.appendChild(style);

// 初始化UI控制器
document.addEventListener('DOMContentLoaded', () => {
    window.uiController = new UIController();
});

// 導出模塊
if (typeof module !== 'undefined' && module.exports) {
    module.exports = UIController;
} else if (typeof window !== 'undefined') {
    window.UIController = UIController;
}


// 虹靈御所占星系統主控制器 - Claude API版本
class MainController {
    constructor() {
        this.currentMode = 'manual'; // manual 或 auto
        this.characterSystem = null;
        this.claudeGenerator = null;
        this.init();
    }

    init() {
        console.log('[MainController] 初始化開始');
        
        // 等待DOM加載完成
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => this.setupSystem());
        } else {
            this.setupSystem();
        }
    }

    setupSystem() {
        try {
            // 初始化角色生成系統
            this.characterSystem = new WorkingCharacterSystem();
            console.log('[MainController] 角色系統已初始化');
            
            // 初始化Claude星盤生成器
            this.claudeGenerator = new ClaudeChartGenerator();
            console.log('[MainController] Claude生成器已初始化');
            
            // 綁定事件
            this.bindEvents();
            
            // 設置初始模式
            this.setMode('manual');
            
            console.log('[MainController] 系統初始化完成');
        } catch (error) {
            console.error('[MainController] 系統初始化失敗:', error);
        }
    }

    bindEvents() {
        console.log('[MainController] 開始綁定事件');
        
        // 模式切換按鈕
        const manualBtn = document.querySelector('[data-mode="manual"]');
        const autoBtn = document.querySelector('[data-mode="auto"]');
        
        if (manualBtn) {
            manualBtn.addEventListener('click', () => this.setMode('manual'));
            console.log('[MainController] 手動模式按鈕已綁定');
        }
        
        if (autoBtn) {
            autoBtn.addEventListener('click', () => this.setMode('auto'));
            console.log('[MainController] 自動模式按鈕已綁定');
        }

        // 生成角色按鈕
        const generateBtns = document.querySelectorAll('.generate-btn, .generate-button');
        generateBtns.forEach(btn => {
            btn.addEventListener('click', () => this.handleGenerate());
        });
        console.log(`[MainController] ${generateBtns.length}個生成按鈕已綁定`);

        // Claude專用按鈕
        const claudeBtn = document.getElementById('claude-generate-btn');
        if (claudeBtn) {
            claudeBtn.addEventListener('click', () => this.handleClaudeGenerate());
            console.log('[MainController] Claude按鈕已綁定');
        }

        console.log('[MainController] 事件綁定完成');
    }

    setMode(mode) {
        console.log(`[MainController] 切換到 ${mode} 模式`);
        this.currentMode = mode;
        
        // 更新按鈕狀態
        const manualBtn = document.querySelector('[data-mode="manual"]');
        const autoBtn = document.querySelector('[data-mode="auto"]');
        
        if (manualBtn && autoBtn) {
            manualBtn.classList.toggle('active', mode === 'manual');
            autoBtn.classList.toggle('active', mode === 'auto');
        }

        // 顯示/隱藏對應的輸入區域
        const manualArea = document.getElementById('manualInputArea') || document.getElementById('manualInput');
        const autoArea = document.getElementById('autoInputArea') || document.getElementById('autoInput');
        
        if (manualArea) {
            manualArea.style.display = mode === 'manual' ? 'block' : 'none';
        }
        
        if (autoArea) {
            autoArea.style.display = mode === 'auto' ? 'block' : 'none';
        }

        // 顯示通知
        this.showNotification(`已切換到${mode === 'manual' ? '手動輸入' : 'Claude自動排盤'}模式`, 'success');
    }

    async handleGenerate() {
        console.log(`[MainController] 開始生成角色 (${this.currentMode} 模式)`);

        if (this.currentMode === 'manual') {
            await this.handleManualGenerate();
        } else {
            await this.handleClaudeGenerate();
        }
    }

    async handleManualGenerate() {
        console.log('[MainController] 處理手動生成');
        
        try {
            // 收集角色名稱
            const nameInput = document.querySelector('input[placeholder*="角色名稱"]');
            const name = nameInput ? nameInput.value.trim() : '';
            
            if (!name) {
                this.showNotification('請輸入角色名稱', 'error');
                return;
            }
            
            // 收集星座配置
            const signConfig = this.collectSignConfiguration();
            
            // 驗證星座配置
            const missingPlanets = this.validateSignConfiguration(signConfig);
            if (missingPlanets.length > 0) {
                this.showNotification(`請選擇以下行星的星座：${missingPlanets.join(', ')}`, 'error');
                return;
            }
            
            // 生成角色
            const character = this.characterSystem.generateCharacter(name, signConfig);
            
            if (character) {
                this.displayCharacter(character);
                this.showNotification('角色生成成功！', 'success');
            } else {
                this.showNotification('角色生成失敗', 'error');
            }
            
        } catch (error) {
            console.error('[MainController] 手動生成失敗:', error);
            this.showNotification('角色生成失敗：' + error.message, 'error');
        }
    }

    async handleClaudeGenerate() {
        console.log('[MainController] 處理Claude自動生成');
        
        try {
            // 收集出生信息
            const birthData = this.collectBirthData();
            
            // 驗證出生信息
            const errors = this.claudeGenerator.validateBirthData(birthData);
            if (errors.length > 0) {
                this.showNotification(errors.join('、'), 'error');
                return;
            }
            
            // 使用Claude API生成完整星盤和角色
            const result = await this.claudeGenerator.generateCharacterFromBirth(birthData);
            
            // 顯示結果
            this.displayClaudeResult(result);
            this.showNotification('Claude星盤生成成功！', 'success');
            
        } catch (error) {
            console.error('[MainController] Claude生成失敗:', error);
            this.showNotification('Claude星盤生成失敗：' + error.message, 'error');
        }
    }

    collectSignConfiguration() {
        const signConfig = {};
        const planets = ['sunSign', 'moonSign', 'mercurySign', 'venusSign', 'marsSign', 'jupiterSign', 'saturnSign', 'uranusSign', 'neptuneSign', 'plutoSign'];
        
        planets.forEach(planetId => {
            const select = document.getElementById(planetId);
            if (select && select.value && select.value !== '選擇星座') {
                signConfig[planetId] = this.convertSignToKey(select.value);
            }
        });
        
        return signConfig;
    }

    validateSignConfiguration(signConfig) {
        const requiredPlanets = ['sunSign', 'moonSign', 'mercurySign', 'venusSign', 'marsSign', 'jupiterSign', 'saturnSign', 'uranusSign', 'neptuneSign', 'plutoSign'];
        const planetNames = {
            'sunSign': '太陽',
            'moonSign': '月亮',
            'mercurySign': '水星',
            'venusSign': '金星',
            'marsSign': '火星',
            'jupiterSign': '木星',
            'saturnSign': '土星',
            'uranusSign': '天王星',
            'neptuneSign': '海王星',
            'plutoSign': '冥王星'
        };
        
        const missing = [];
        requiredPlanets.forEach(planet => {
            if (!signConfig[planet]) {
                missing.push(planetNames[planet]);
            }
        });
        
        return missing;
    }

    collectBirthData() {
        return {
            name: document.querySelector('input[placeholder*="角色名稱"]')?.value?.trim() || '',
            date: document.getElementById('birthDate')?.value || '',
            time: document.getElementById('birthTime')?.value || '',
            location: document.getElementById('birthLocation')?.value || '',
            timezone: document.getElementById('timezone')?.value || 'UTC+8'
        };
    }

    convertSignToKey(chineseName) {
        const signMap = {
            '♈ 牡羊座': 'aries',
            '♉ 金牛座': 'taurus',
            '♊ 雙子座': 'gemini',
            '♋ 巨蟹座': 'cancer',
            '♌ 獅子座': 'leo',
            '♍ 處女座': 'virgo',
            '♎ 天秤座': 'libra',
            '♏ 天蠍座': 'scorpio',
            '♐ 射手座': 'sagittarius',
            '♑ 摩羯座': 'capricorn',
            '♒ 水瓶座': 'aquarius',
            '♓ 雙魚座': 'pisces'
        };
        return signMap[chineseName] || chineseName;
    }

    displayCharacter(character) {
        console.log('[MainController] 顯示角色:', character);
        
        // 使用現有的顯示系統
        if (window.EnhancedDisplaySystem) {
            const displaySystem = new EnhancedDisplaySystem();
            displaySystem.displayCharacter(character);
        }
    }

    displayClaudeResult(result) {
        console.log('[MainController] 顯示Claude結果:', result);
        
        // 創建Claude專用的結果顯示區域
        let resultArea = document.getElementById('claude-result-area');
        if (!resultArea) {
            resultArea = document.createElement('div');
            resultArea.id = 'claude-result-area';
            resultArea.className = 'claude-chart-result';
            
            // 插入到適當位置
            const container = document.querySelector('.container') || document.body;
            container.appendChild(resultArea);
        }
        
        // 格式化星盤數據
        const formattedChart = this.claudeGenerator.formatChartForDisplay(result.chart);
        
        // 生成HTML內容
        resultArea.innerHTML = this.generateClaudeResultHTML(result, formattedChart);
        
        // 滾動到結果區域
        resultArea.scrollIntoView({ behavior: 'smooth' });
    }

    generateClaudeResultHTML(result, formattedChart) {
        return `
            <div class="claude-chart-header">
                <div class="claude-chart-title">🔮 ${result.character.name} 的完整星盤</div>
                <div class="claude-chart-subtitle">由Claude AI專業計算生成</div>
            </div>
            
            <!-- 角色信息 -->
            <div class="claude-character-info">
                <h3>🎭 RPG角色信息</h3>
                <p><strong>職業：</strong>${result.character.class.name} (${result.character.class.englishName})</p>
                <p><strong>評級：</strong>${result.character.rating}</p>
                <p><strong>總分：</strong>${result.character.totalScore.toFixed(1)}分</p>
            </div>
            
            <!-- 行星配置 -->
            <div class="claude-section-title">🌟 十大行星配置</div>
            <div class="claude-planets-grid">
                ${Object.entries(formattedChart.planets).map(([planet, data]) => `
                    <div class="claude-planet-card">
                        <div class="claude-planet-header">
                            <span class="claude-planet-symbol">${data.planetSymbol}</span>
                            <span class="claude-planet-name">${this.getPlanetName(planet)}</span>
                        </div>
                        <div class="claude-planet-info">
                            <div class="claude-planet-sign">
                                <span class="claude-sign-symbol">${data.signSymbol}</span>
                                <span>${data.signName}</span>
                                <span style="margin-left: 10px;">${data.formattedDegree}</span>
                            </div>
                            <div>第${data.house}宮</div>
                            ${data.isRetrograde ? '<div style="color: #ff6b6b;">⚡ 逆行</div>' : ''}
                        </div>
                        <div class="claude-planet-description">${data.description}</div>
                    </div>
                `).join('')}
            </div>
            
            <!-- 宮位系統 -->
            <div class="claude-houses-section">
                <div class="claude-section-title">🏠 十二宮位系統</div>
                <div class="claude-houses-grid">
                    ${Object.entries(formattedChart.houses).map(([house, data]) => `
                        <div class="claude-house-card">
                            <div class="claude-house-number">第${house}宮</div>
                            <div class="claude-house-sign">
                                <span class="claude-sign-symbol">${data.signSymbol}</span>
                                <span>${data.signName} ${data.formattedDegree}</span>
                            </div>
                            <div class="claude-house-description">${data.description}</div>
                        </div>
                    `).join('')}
                </div>
            </div>
            
            <!-- 星盤總結 -->
            <div class="claude-summary-section">
                <div class="claude-section-title">📋 星盤總結</div>
                <div class="claude-summary-content">
                    <p><strong>太陽月亮上升：</strong>${formattedChart.summary.sunMoonRising || '專業分析中...'}</p>
                    <p><strong>主導元素：</strong>${formattedChart.summary.dominantElement || '計算中...'}</p>
                    <p><strong>主導性質：</strong>${formattedChart.summary.dominantQuality || '計算中...'}</p>
                    
                    ${formattedChart.summary.keyThemes ? `
                        <div>
                            <strong>關鍵主題：</strong>
                            <div class="claude-key-themes">
                                ${formattedChart.summary.keyThemes.map(theme => `
                                    <span class="claude-theme-tag">${theme}</span>
                                `).join('')}
                            </div>
                        </div>
                    ` : ''}
                </div>
            </div>
        `;
    }

    getPlanetName(planetKey) {
        const planetNames = {
            'sun': '太陽',
            'moon': '月亮',
            'mercury': '水星',
            'venus': '金星',
            'mars': '火星',
            'jupiter': '木星',
            'saturn': '土星',
            'uranus': '天王星',
            'neptune': '海王星',
            'pluto': '冥王星'
        };
        return planetNames[planetKey] || planetKey;
    }

    showNotification(message, type = 'info') {
        console.log(`[MainController] 通知: ${message} (${type})`);
        
        // 創建通知元素
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.textContent = message;
        
        // 添加樣式
        Object.assign(notification.style, {
            position: 'fixed',
            top: '20px',
            right: '20px',
            padding: '15px 20px',
            borderRadius: '10px',
            color: '#fff',
            fontWeight: '600',
            zIndex: '10000',
            animation: 'slideInRight 0.3s ease-out',
            maxWidth: '300px',
            boxShadow: '0 8px 25px rgba(0, 0, 0, 0.3)'
        });

        // 根據類型設置背景色
        switch (type) {
            case 'success':
                notification.style.background = 'linear-gradient(135deg, #4CAF50, #45a049)';
                break;
            case 'error':
                notification.style.background = 'linear-gradient(135deg, #f44336, #da190b)';
                break;
            case 'info':
            default:
                notification.style.background = 'linear-gradient(135deg, #2196F3, #0b7dda)';
                break;
        }

        // 添加到頁面
        document.body.appendChild(notification);

        // 3秒後自動移除
        setTimeout(() => {
            notification.style.animation = 'slideOutRight 0.3s ease-in';
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 300);
        }, 3000);
    }
}

// 添加動畫樣式
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOutRight {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
    
    .mode-button.active {
        background: linear-gradient(135deg, #FFD700, #FFA500) !important;
        color: #000 !important;
        box-shadow: 0 0 20px rgba(255, 215, 0, 0.4) !important;
    }
`;
document.head.appendChild(style);

// 將MainController暴露到全局
window.MainController = MainController;

// 創建全局實例
window.mainController = new MainController();

console.log('[MainController] Claude版本主控制器已加載');

